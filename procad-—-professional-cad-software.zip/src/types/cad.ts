/**
 * ProCAD - Core CAD Entity and Type Definitions
 */

export interface Point2D {
  x: number;
  y: number;
}

export interface Point3D {
  x: number;
  y: number;
  z: number;
}

export type EntityType =
  | 'LINE'
  | 'LWPOLYLINE'
  | 'CIRCLE'
  | 'ARC'
  | 'RECTANGLE'
  | 'POLYGON'
  | 'ELLIPSE'
  | 'SPLINE'
  | 'POINT'
  | 'XLINE'
  | 'RAY'
  | 'TEXT'
  | 'DIMENSION'
  | 'HATCH'
  | 'BLOCK_REF';

export type LineType = 'CONTINUOUS' | 'DASHED' | 'DOTTED' | 'DASHDOT' | 'CENTER';

export interface BaseEntity {
  id: string;
  type: EntityType;
  layer: string;
  color?: string; // Hex color or undefined for 'BYLAYER'
  lineType?: LineType;
  lineWeight?: number; // Lineweight in mm (0.13, 0.25, 0.35, etc.)
  selected?: boolean;
}

export interface LineEntity extends BaseEntity {
  type: 'LINE';
  p1: Point2D;
  p2: Point2D;
}

export interface PolylineEntity extends BaseEntity {
  type: 'LWPOLYLINE';
  points: Point2D[];
  closed: boolean;
}

export interface CircleEntity extends BaseEntity {
  type: 'CIRCLE';
  center: Point2D;
  radius: number;
}

export interface ArcEntity extends BaseEntity {
  type: 'ARC';
  center: Point2D;
  radius: number;
  startAngle: number; // in radians
  endAngle: number;   // in radians
}

export interface RectEntity extends BaseEntity {
  type: 'RECTANGLE';
  p1: Point2D; // First corner
  p2: Point2D; // Opposite corner
}

export interface PolygonEntity extends BaseEntity {
  type: 'POLYGON';
  center: Point2D;
  radius: number;
  sides: number;
}

export interface EllipseEntity extends BaseEntity {
  type: 'ELLIPSE';
  center: Point2D;
  rx: number;
  ry: number;
  rotation: number; // in radians
}

export interface SplineEntity extends BaseEntity {
  type: 'SPLINE';
  controlPoints: Point2D[];
}

export interface PointEntity extends BaseEntity {
  type: 'POINT';
  point: Point2D;
}

export interface XLineEntity extends BaseEntity {
  type: 'XLINE'; // Infinite construction line
  base: Point2D;
  dir: Point2D;
}

export interface RayEntity extends BaseEntity {
  type: 'RAY'; // Semi-infinite ray
  base: Point2D;
  dir: Point2D;
}

export interface TextEntity extends BaseEntity {
  type: 'TEXT';
  position: Point2D;
  text: string;
  height: number;
  rotation: number; // in degrees
}

export type DimensionType = 'LINEAR' | 'ALIGNED' | 'ANGULAR' | 'RADIUS' | 'DIAMETER';

export interface DimensionEntity extends BaseEntity {
  type: 'DIMENSION';
  dimType: DimensionType;
  p1: Point2D;
  p2: Point2D;
  offsetPt: Point2D;
  textOverride?: string;
  prefix?: string;
  suffix?: string;
}

export type HatchPattern = 'ANSI31' | 'SOLID' | 'CROSS' | 'DOTS' | 'BRICK';

export interface HatchEntity extends BaseEntity {
  type: 'HATCH';
  pattern: HatchPattern;
  boundary: Point2D[];
  scale: number;
  angle: number; // in degrees
}

export interface BlockRefEntity extends BaseEntity {
  type: 'BLOCK_REF';
  blockName: string;
  position: Point2D;
  scale: number;
  rotation: number; // degrees
}

export type CADEntity =
  | LineEntity
  | PolylineEntity
  | CircleEntity
  | ArcEntity
  | RectEntity
  | PolygonEntity
  | EllipseEntity
  | SplineEntity
  | PointEntity
  | XLineEntity
  | RayEntity
  | TextEntity
  | DimensionEntity
  | HatchEntity
  | BlockRefEntity;

export interface Layer {
  id: string;
  name: string;
  color: string;
  visible: boolean;
  locked: boolean;
  lineType: LineType;
  lineWeight: number;
}

export type SnapType =
  | 'endpoint'
  | 'midpoint'
  | 'center'
  | 'quadrant'
  | 'intersection'
  | 'perpendicular'
  | 'grid'
  | 'nearest';

export interface SnapPoint {
  type: SnapType;
  point: Point2D;
  entityId?: string;
  distance: number;
}

export type CADTool =
  | 'select'
  | 'pan'
  // Draw tools
  | 'line'
  | 'polyline'
  | 'circle'
  | 'arc'
  | 'rectangle'
  | 'polygon'
  | 'ellipse'
  | 'spline'
  | 'point'
  | 'xline'
  | 'ray'
  | 'text'
  | 'dimension_linear'
  | 'dimension_aligned'
  | 'dimension_radius'
  | 'dimension_angular'
  | 'hatch'
  // Modify tools
  | 'move'
  | 'copy'
  | 'rotate'
  | 'mirror'
  | 'scale'
  | 'trim'
  | 'extend'
  | 'fillet'
  | 'chamfer'
  | 'offset'
  | 'erase'
  | 'explode'
  // Measure tools
  | 'dist'
  | 'area';

export type ViewMode = '2D' | '3D' | 'LAYOUT';

export type Solid3DShape = 'BOX' | 'CYLINDER' | 'SPHERE' | 'CONE' | 'TORUS' | 'PLANE' | 'EXTRUSION';

export interface Solid3DEntity {
  id: string;
  name: string;
  shape: Solid3DShape;
  position: Point3D;
  rotation: Point3D; // radians
  scale: Point3D;
  parameters: {
    width?: number;
    height?: number;
    depth?: number;
    radius?: number;
    radiusTop?: number;
    radiusBottom?: number;
    tube?: number;
    segments?: number;
  };
  color: string;
  wireframe?: boolean;
  extrusionPath?: Point2D[];
}

export interface GripPoint {
  index: number;
  type: 'p1' | 'p2' | 'center' | 'radius' | 'vertex' | 'corner';
  point: Point2D;
  entityId: string;
}

export interface BlockDefinition {
  name: string;
  description: string;
  category: 'Architectural' | 'Mechanical' | 'Electrical' | 'General';
  entities: CADEntity[];
  basePoint: Point2D;
}
