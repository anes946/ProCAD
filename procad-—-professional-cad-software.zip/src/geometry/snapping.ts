/**
 * ProCAD - Object Snapping (OSNAP) Engine
 */

import { Point2D, CADEntity, SnapPoint, SnapType } from '../types/cad';
import { cadMath } from './cadMath';

export interface SnapSettings {
  enabled: boolean;
  endpoint: boolean;
  midpoint: boolean;
  center: boolean;
  quadrant: boolean;
  intersection: boolean;
  perpendicular: boolean;
  nearest: boolean;
  gridSnap: boolean;
}

export const defaultSnapSettings: SnapSettings = {
  enabled: true,
  endpoint: true,
  midpoint: true,
  center: true,
  quadrant: true,
  intersection: true,
  perpendicular: true,
  nearest: false,
  gridSnap: false,
};

export const snappingEngine = {
  findSnapPoint(
    cursorWorld: Point2D,
    entities: CADEntity[],
    settings: SnapSettings,
    toleranceWorld: number,
    basePoint?: Point2D,
    gridSize: number = 10
  ): SnapPoint | null {
    if (!settings.enabled) return null;

    const candidates: SnapPoint[] = [];

    // 1. Grid Snap (lowest priority)
    if (settings.gridSnap && gridSize > 0) {
      const gx = Math.round(cursorWorld.x / gridSize) * gridSize;
      const gy = Math.round(cursorWorld.y / gridSize) * gridSize;
      const gPt = { x: gx, y: gy };
      const d = cadMath.dist(cursorWorld, gPt);
      if (d <= toleranceWorld * 1.5) {
        candidates.push({ type: 'grid', point: gPt, distance: d });
      }
    }

    // Iterate visible entities
    for (const ent of entities) {
      switch (ent.type) {
        case 'LINE': {
          if (settings.endpoint) {
            candidates.push({ type: 'endpoint', point: ent.p1, entityId: ent.id, distance: cadMath.dist(cursorWorld, ent.p1) });
            candidates.push({ type: 'endpoint', point: ent.p2, entityId: ent.id, distance: cadMath.dist(cursorWorld, ent.p2) });
          }
          if (settings.midpoint) {
            const mid = cadMath.midpoint(ent.p1, ent.p2);
            candidates.push({ type: 'midpoint', point: mid, entityId: ent.id, distance: cadMath.dist(cursorWorld, mid) });
          }
          if (settings.perpendicular && basePoint) {
            const proj = cadMath.projectPointOnSegment(basePoint, ent.p1, ent.p2);
            candidates.push({ type: 'perpendicular', point: proj.point, entityId: ent.id, distance: cadMath.dist(cursorWorld, proj.point) });
          }
          if (settings.nearest) {
            const proj = cadMath.projectPointOnSegment(cursorWorld, ent.p1, ent.p2);
            candidates.push({ type: 'nearest', point: proj.point, entityId: ent.id, distance: proj.distance });
          }
          break;
        }

        case 'RECTANGLE': {
          const minX = Math.min(ent.p1.x, ent.p2.x);
          const maxX = Math.max(ent.p1.x, ent.p2.x);
          const minY = Math.min(ent.p1.y, ent.p2.y);
          const maxY = Math.max(ent.p1.y, ent.p2.y);

          const corners = [
            { x: minX, y: minY },
            { x: maxX, y: minY },
            { x: maxX, y: maxY },
            { x: minX, y: maxY },
          ];

          if (settings.endpoint) {
            corners.forEach((c) => {
              candidates.push({ type: 'endpoint', point: c, entityId: ent.id, distance: cadMath.dist(cursorWorld, c) });
            });
          }

          if (settings.midpoint) {
            const mids = [
              { x: (minX + maxX) / 2, y: minY },
              { x: maxX, y: (minY + maxY) / 2 },
              { x: (minX + maxX) / 2, y: maxY },
              { x: minX, y: (minY + maxY) / 2 },
            ];
            mids.forEach((m) => {
              candidates.push({ type: 'midpoint', point: m, entityId: ent.id, distance: cadMath.dist(cursorWorld, m) });
            });
          }

          if (settings.center) {
            const center = { x: (minX + maxX) / 2, y: (minY + maxY) / 2 };
            candidates.push({ type: 'center', point: center, entityId: ent.id, distance: cadMath.dist(cursorWorld, center) });
          }
          break;
        }

        case 'CIRCLE': {
          if (settings.center) {
            candidates.push({ type: 'center', point: ent.center, entityId: ent.id, distance: cadMath.dist(cursorWorld, ent.center) });
          }
          if (settings.quadrant) {
            const quads = [
              { x: ent.center.x + ent.radius, y: ent.center.y },
              { x: ent.center.x, y: ent.center.y + ent.radius },
              { x: ent.center.x - ent.radius, y: ent.center.y },
              { x: ent.center.x, y: ent.center.y - ent.radius },
            ];
            quads.forEach((q) => {
              candidates.push({ type: 'quadrant', point: q, entityId: ent.id, distance: cadMath.dist(cursorWorld, q) });
            });
          }
          if (settings.nearest) {
            const ang = Math.atan2(cursorWorld.y - ent.center.y, cursorWorld.x - ent.center.x);
            const np = { x: ent.center.x + ent.radius * Math.cos(ang), y: ent.center.y + ent.radius * Math.sin(ang) };
            candidates.push({ type: 'nearest', point: np, entityId: ent.id, distance: cadMath.dist(cursorWorld, np) });
          }
          break;
        }

        case 'ARC': {
          if (settings.center) {
            candidates.push({ type: 'center', point: ent.center, entityId: ent.id, distance: cadMath.dist(cursorWorld, ent.center) });
          }
          if (settings.endpoint) {
            const ep1 = {
              x: ent.center.x + ent.radius * Math.cos(ent.startAngle),
              y: ent.center.y + ent.radius * Math.sin(ent.startAngle),
            };
            const ep2 = {
              x: ent.center.x + ent.radius * Math.cos(ent.endAngle),
              y: ent.center.y + ent.radius * Math.sin(ent.endAngle),
            };
            candidates.push({ type: 'endpoint', point: ep1, entityId: ent.id, distance: cadMath.dist(cursorWorld, ep1) });
            candidates.push({ type: 'endpoint', point: ep2, entityId: ent.id, distance: cadMath.dist(cursorWorld, ep2) });
          }
          if (settings.midpoint) {
            const midAngle = (ent.startAngle + ent.endAngle) / 2;
            const mid = {
              x: ent.center.x + ent.radius * Math.cos(midAngle),
              y: ent.center.y + ent.radius * Math.sin(midAngle),
            };
            candidates.push({ type: 'midpoint', point: mid, entityId: ent.id, distance: cadMath.dist(cursorWorld, mid) });
          }
          break;
        }

        case 'LWPOLYLINE': {
          const pts = ent.points;
          for (let i = 0; i < pts.length; i++) {
            if (settings.endpoint) {
              candidates.push({ type: 'endpoint', point: pts[i], entityId: ent.id, distance: cadMath.dist(cursorWorld, pts[i]) });
            }
            if (settings.midpoint && (i < pts.length - 1 || ent.closed)) {
              const next = pts[(i + 1) % pts.length];
              const mid = cadMath.midpoint(pts[i], next);
              candidates.push({ type: 'midpoint', point: mid, entityId: ent.id, distance: cadMath.dist(cursorWorld, mid) });
            }
          }
          break;
        }

        case 'POLYGON': {
          if (settings.center) {
            candidates.push({ type: 'center', point: ent.center, entityId: ent.id, distance: cadMath.dist(cursorWorld, ent.center) });
          }
          break;
        }

        default:
          break;
      }
    }

    // Intersections between lines
    if (settings.intersection && entities.length > 1) {
      const lines: { p1: Point2D; p2: Point2D; id: string }[] = [];
      entities.forEach((e) => {
        if (e.type === 'LINE') {
          lines.push({ p1: e.p1, p2: e.p2, id: e.id });
        } else if (e.type === 'LWPOLYLINE') {
          for (let i = 0; i < e.points.length - 1; i++) {
            lines.push({ p1: e.points[i], p2: e.points[i + 1], id: e.id });
          }
        }
      });

      for (let i = 0; i < lines.length; i++) {
        for (let j = i + 1; j < lines.length; j++) {
          const inter = cadMath.lineIntersection(lines[i].p1, lines[i].p2, lines[j].p1, lines[j].p2, true);
          if (inter) {
            const d = cadMath.dist(cursorWorld, inter);
            if (d <= toleranceWorld) {
              candidates.push({ type: 'intersection', point: inter, distance: d });
            }
          }
        }
      }
    }

    // Filter within tolerance and pick closest with priority
    const priorityWeight: Record<SnapType, number> = {
      endpoint: 1,
      midpoint: 2,
      center: 3,
      intersection: 4,
      quadrant: 5,
      perpendicular: 6,
      grid: 7,
      nearest: 8,
    };

    const valid = candidates.filter((c) => c.distance <= toleranceWorld);
    if (!valid.length) return null;

    valid.sort((a, b) => {
      const prioDiff = priorityWeight[a.type] - priorityWeight[b.type];
      if (Math.abs(a.distance - b.distance) < toleranceWorld * 0.3) {
        return prioDiff;
      }
      return a.distance - b.distance;
    });

    return valid[0];
  },

  // Draw snap marker glyph on canvas context
  renderSnapGlyph(
    ctx: CanvasRenderingContext2D,
    snap: SnapPoint,
    worldToScreen: (pt: Point2D) => Point2D
  ): void {
    const screenPt = worldToScreen(snap.point);
    const size = 7; // half size in pixels

    ctx.save();
    ctx.strokeStyle = '#00ff66'; // AutoCAD snap bright green
    ctx.lineWidth = 1.75;
    ctx.fillStyle = 'rgba(0, 255, 102, 0.15)';

    const x = screenPt.x;
    const y = screenPt.y;

    switch (snap.type) {
      case 'endpoint':
        // Square
        ctx.strokeRect(x - size, y - size, size * 2, size * 2);
        ctx.fillRect(x - size, y - size, size * 2, size * 2);
        break;

      case 'midpoint':
        // Triangle
        ctx.beginPath();
        ctx.moveTo(x, y - size);
        ctx.lineTo(x + size, y + size);
        ctx.lineTo(x - size, y + size);
        ctx.closePath();
        ctx.stroke();
        ctx.fill();
        break;

      case 'center':
        // Circle
        ctx.beginPath();
        ctx.arc(x, y, size, 0, Math.PI * 2);
        ctx.stroke();
        ctx.fill();
        break;

      case 'quadrant':
        // Diamond
        ctx.beginPath();
        ctx.moveTo(x, y - size);
        ctx.lineTo(x + size, y);
        ctx.lineTo(x, y + size);
        ctx.lineTo(x - size, y);
        ctx.closePath();
        ctx.stroke();
        ctx.fill();
        break;

      case 'intersection':
        // X mark
        ctx.beginPath();
        ctx.moveTo(x - size, y - size);
        ctx.lineTo(x + size, y + size);
        ctx.moveTo(x + size, y - size);
        ctx.lineTo(x - size, y + size);
        ctx.stroke();
        break;

      case 'perpendicular':
        // Perpendicular right angle symbol
        ctx.beginPath();
        ctx.moveTo(x - size, y + size);
        ctx.lineTo(x - size, y - size);
        ctx.lineTo(x + size, y - size);
        ctx.moveTo(x - size, y);
        ctx.lineTo(x, y);
        ctx.lineTo(x, y - size);
        ctx.stroke();
        break;

      case 'grid':
        // Crosshair (+)
        ctx.beginPath();
        ctx.moveTo(x - size, y);
        ctx.lineTo(x + size, y);
        ctx.moveTo(x, y - size);
        ctx.lineTo(x, y + size);
        ctx.stroke();
        break;

      case 'nearest':
        // Hourglass
        ctx.beginPath();
        ctx.moveTo(x - size, y - size);
        ctx.lineTo(x + size, y - size);
        ctx.lineTo(x - size, y + size);
        ctx.lineTo(x + size, y + size);
        ctx.closePath();
        ctx.stroke();
        break;
    }

    // Snap tooltip label
    ctx.font = '10px monospace';
    ctx.fillStyle = '#00ff66';
    ctx.fillText(snap.type.toUpperCase(), x + size + 6, y + 4);

    ctx.restore();
  },
};
