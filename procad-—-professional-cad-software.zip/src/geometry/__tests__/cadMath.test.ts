/**
 * ProCAD - Automated Tests for Core Geometry Operations
 */

import { cadMath } from '../cadMath';
import { LineEntity } from '../../types/cad';

export function runCADGeometryTests(): { name: string; passed: boolean; message?: string }[] {
  const results: { name: string; passed: boolean; message?: string }[] = [];

  function test(name: string, fn: () => void) {
    try {
      fn();
      results.push({ name, passed: true });
    } catch (e: any) {
      results.push({ name, passed: false, message: e.message || String(e) });
    }
  }

  // 1. Distance & Midpoint
  test('Distance and Midpoint calculation', () => {
    const p1 = { x: 0, y: 0 };
    const p2 = { x: 30, y: 40 };
    const d = cadMath.dist(p1, p2);
    if (Math.abs(d - 50) > 1e-6) throw new Error(`Expected 50, got ${d}`);

    const mid = cadMath.midpoint(p1, p2);
    if (mid.x !== 15 || mid.y !== 20) throw new Error(`Midpoint error: ${JSON.stringify(mid)}`);
  });

  // 2. Line Intersection
  test('Line segment intersection', () => {
    const l1p1 = { x: 0, y: 0 };
    const l1p2 = { x: 100, y: 100 };
    const l2p1 = { x: 0, y: 100 };
    const l2p2 = { x: 100, y: 0 };

    const inter = cadMath.lineIntersection(l1p1, l1p2, l2p1, l2p2, true);
    if (!inter) throw new Error('Expected intersection, got null');
    if (Math.abs(inter.x - 50) > 1e-4 || Math.abs(inter.y - 50) > 1e-4) {
      throw new Error(`Expected (50, 50), got (${inter.x}, ${inter.y})`);
    }

    // Parallel lines test
    const parallelInter = cadMath.lineIntersection({ x: 0, y: 0 }, { x: 100, y: 0 }, { x: 0, y: 10 }, { x: 100, y: 10 });
    if (parallelInter !== null) throw new Error('Expected parallel lines to have no intersection');
  });

  // 3. Coordinate String Parsing
  test('AutoCAD Coordinate Parsing (Absolute, Relative, Polar)', () => {
    // Absolute "100,200"
    const pAbs = cadMath.parseCoordinate('100,200');
    if (!pAbs || pAbs.x !== 100 || pAbs.y !== 200) throw new Error(`Absolute coord failed: ${JSON.stringify(pAbs)}`);

    // Relative "@50,-20"
    const base = { x: 10, y: 10 };
    const pRel = cadMath.parseCoordinate('@50,-20', base);
    if (!pRel || pRel.x !== 60 || pRel.y !== -10) throw new Error(`Relative coord failed: ${JSON.stringify(pRel)}`);

    // Polar "@100<0" and "@100<90"
    const pPolar0 = cadMath.parseCoordinate('@100<0', base);
    if (!pPolar0 || Math.abs(pPolar0.x - 110) > 1e-4 || Math.abs(pPolar0.y - 10) > 1e-4) {
      throw new Error(`Polar coord failed: ${JSON.stringify(pPolar0)}`);
    }

    const pPolar90 = cadMath.parseCoordinate('@100<90', base);
    if (!pPolar90 || Math.abs(pPolar90.x - 10) > 1e-4 || Math.abs(pPolar90.y - 110) > 1e-4) {
      throw new Error(`Polar coord 90 deg failed: ${JSON.stringify(pPolar90)}`);
    }
  });

  // 4. Polygon Area (Shoelace)
  test('Polygon Area calculation (Shoelace formula)', () => {
    // 100x50 rectangle = 5000
    const rect = [
      { x: 0, y: 0 },
      { x: 100, y: 0 },
      { x: 100, y: 50 },
      { x: 0, y: 50 },
    ];
    const area = cadMath.polygonArea(rect);
    if (Math.abs(area - 5000) > 1e-4) throw new Error(`Expected area 5000, got ${area}`);
  });

  // 5. Line Offset
  test('Line Offset', () => {
    const line: LineEntity = {
      id: 'l1',
      type: 'LINE',
      layer: '0',
      p1: { x: 0, y: 0 },
      p2: { x: 100, y: 0 },
    };
    const offset = cadMath.offsetEntity(line, 20, { x: 50, y: 25 }) as LineEntity;
    if (!offset) throw new Error('Expected offset line');
    if (Math.abs(offset.p1.y - 20) > 1e-4 || Math.abs(offset.p2.y - 20) > 1e-4) {
      throw new Error(`Offset Y expected 20, got ${offset.p1.y}, ${offset.p2.y}`);
    }
  });

  // 6. Fillet calculation
  test('Fillet calculation between perpendicular lines', () => {
    const l1: LineEntity = {
      id: 'l1',
      type: 'LINE',
      layer: '0',
      p1: { x: 0, y: 0 },
      p2: { x: 100, y: 0 },
    };
    const l2: LineEntity = {
      id: 'l2',
      type: 'LINE',
      layer: '0',
      p1: { x: 100, y: 0 },
      p2: { x: 100, y: 100 },
    };

    const fillet = cadMath.filletLines(l1, l2, 10);
    if (!fillet) throw new Error('Expected fillet result, got null');
    if (Math.abs(fillet.arc.radius - 10) > 1e-4) throw new Error('Fillet radius mismatch');
  });

  return results;
}
