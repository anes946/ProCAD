/**
 * ProCAD - Geometric Calculation System & Vector Math
 */

import { Point2D, CADEntity, RectEntity, LineEntity, CircleEntity, ArcEntity, PolylineEntity } from '../types/cad';

export const cadMath = {
  // Vector & Point operations
  dist(p1: Point2D, p2: Point2D): number {
    const dx = p2.x - p1.x;
    const dy = p2.y - p1.y;
    return Math.sqrt(dx * dx + dy * dy);
  },

  angle(p1: Point2D, p2: Point2D): number {
    return Math.atan2(p2.y - p1.y, p2.x - p1.x);
  },

  angleDeg(p1: Point2D, p2: Point2D): number {
    let deg = (Math.atan2(p2.y - p1.y, p2.x - p1.x) * 180) / Math.PI;
    if (deg < 0) deg += 360;
    return deg;
  },

  add(p1: Point2D, p2: Point2D): Point2D {
    return { x: p1.x + p2.x, y: p1.y + p2.y };
  },

  sub(p1: Point2D, p2: Point2D): Point2D {
    return { x: p1.x - p2.x, y: p1.y - p2.y };
  },

  scale(p: Point2D, s: number): Point2D {
    return { x: p.x * s, y: p.y * s };
  },

  midpoint(p1: Point2D, p2: Point2D): Point2D {
    return { x: (p1.x + p2.x) / 2, y: (p1.y + p2.y) / 2 };
  },

  rotate(p: Point2D, angleRad: number, origin: Point2D = { x: 0, y: 0 }): Point2D {
    const cos = Math.cos(angleRad);
    const sin = Math.sin(angleRad);
    const dx = p.x - origin.x;
    const dy = p.y - origin.y;
    return {
      x: origin.x + dx * cos - dy * sin,
      y: origin.y + dx * sin + dy * cos,
    };
  },

  normalize(v: Point2D): Point2D {
    const len = Math.sqrt(v.x * v.x + v.y * v.y);
    if (len < 1e-9) return { x: 1, y: 0 };
    return { x: v.x / len, y: v.y / len };
  },

  dot(u: Point2D, v: Point2D): number {
    return u.x * v.x + u.y * v.y;
  },

  cross(u: Point2D, v: Point2D): number {
    return u.x * v.y - u.y * v.x;
  },

  // Project point onto line segment
  projectPointOnSegment(p: Point2D, a: Point2D, b: Point2D): { point: Point2D; t: number; distance: number } {
    const ab = cadMath.sub(b, a);
    const abLenSq = ab.x * ab.x + ab.y * ab.y;
    if (abLenSq < 1e-9) {
      return { point: a, t: 0, distance: cadMath.dist(p, a) };
    }
    const ap = cadMath.sub(p, a);
    let t = cadMath.dot(ap, ab) / abLenSq;
    const clampedT = Math.max(0, Math.min(1, t));
    const proj = cadMath.add(a, cadMath.scale(ab, clampedT));
    return {
      point: proj,
      t: clampedT,
      distance: cadMath.dist(p, proj),
    };
  },

  // Line-line intersection
  lineIntersection(
    p1: Point2D,
    p2: Point2D,
    p3: Point2D,
    p4: Point2D,
    asSegments = true
  ): Point2D | null {
    const d = (p1.x - p2.x) * (p3.y - p4.y) - (p1.y - p2.y) * (p3.x - p4.x);
    if (Math.abs(d) < 1e-9) return null; // Parallel

    const t = ((p1.x - p3.x) * (p3.y - p4.y) - (p1.y - p3.y) * (p3.x - p4.x)) / d;
    const u = -((p1.x - p2.x) * (p1.y - p3.y) - (p1.y - p2.y) * (p1.x - p3.x)) / d;

    if (asSegments) {
      if (t >= -1e-5 && t <= 1 + 1e-5 && u >= -1e-5 && u <= 1 + 1e-5) {
        return {
          x: p1.x + t * (p2.x - p1.x),
          y: p1.y + t * (p2.y - p1.y),
        };
      }
      return null;
    }

    return {
      x: p1.x + t * (p2.x - p1.x),
      y: p1.y + t * (p2.y - p1.y),
    };
  },

  // Coordinate string parser (AutoCAD format: "100,50", "@50,20", "@100<45", "100")
  parseCoordinate(
    input: string,
    currentBasePoint?: Point2D,
    cursorAngle?: number
  ): Point2D | null {
    const text = input.trim();
    if (!text) return null;

    // Relative Polar: @dist<angle or dist<angle
    const polarMatch = text.match(/^@?(-?\d*\.?\d+)<(-?\d*\.?\d+)$/);
    if (polarMatch) {
      const distance = parseFloat(polarMatch[1]);
      const angleDeg = parseFloat(polarMatch[2]);
      const angleRad = (angleDeg * Math.PI) / 180;
      const base = currentBasePoint || { x: 0, y: 0 };
      return {
        x: base.x + distance * Math.cos(angleRad),
        y: base.y + distance * Math.sin(angleRad),
      };
    }

    // Relative Cartesian: @dx,dy
    if (text.startsWith('@')) {
      const parts = text.slice(1).split(',');
      if (parts.length === 2) {
        const dx = parseFloat(parts[0]);
        const dy = parseFloat(parts[1]);
        if (!isNaN(dx) && !isNaN(dy)) {
          const base = currentBasePoint || { x: 0, y: 0 };
          return { x: base.x + dx, y: base.y + dy };
        }
      }
    }

    // Absolute Cartesian: x,y
    if (text.includes(',')) {
      const parts = text.split(',');
      if (parts.length === 2) {
        const x = parseFloat(parts[0]);
        const y = parseFloat(parts[1]);
        if (!isNaN(x) && !isNaN(y)) {
          return { x, y };
        }
      }
    }

    // Single number: direct distance entry along cursor / ortho angle
    const singleNum = parseFloat(text);
    if (!isNaN(singleNum) && currentBasePoint && cursorAngle !== undefined) {
      return {
        x: currentBasePoint.x + singleNum * Math.cos(cursorAngle),
        y: currentBasePoint.y + singleNum * Math.sin(cursorAngle),
      };
    }

    return null;
  },

  // Ortho & Polar snapping
  applyOrtho(p1: Point2D, p2: Point2D): Point2D {
    const dx = Math.abs(p2.x - p1.x);
    const dy = Math.abs(p2.y - p1.y);
    return dx >= dy ? { x: p2.x, y: p1.y } : { x: p1.x, y: p2.y };
  },

  applyPolarTracking(p1: Point2D, p2: Point2D, stepDeg: number = 45, toleranceDeg: number = 3): { point: Point2D; snapped: boolean; snapAngleDeg?: number } {
    const rawAngle = cadMath.angleDeg(p1, p2);
    const dist = cadMath.dist(p1, p2);
    const nearestStep = Math.round(rawAngle / stepDeg) * stepDeg;
    const diff = Math.abs(rawAngle - nearestStep);

    if (diff <= toleranceDeg || Math.abs(diff - 360) <= toleranceDeg) {
      const snappedRad = (nearestStep * Math.PI) / 180;
      return {
        point: {
          x: p1.x + dist * Math.cos(snappedRad),
          y: p1.y + dist * Math.sin(snappedRad),
        },
        snapped: true,
        snapAngleDeg: (nearestStep % 360 + 360) % 360,
      };
    }
    return { point: p2, snapped: false };
  },

  // Area of polygon via Shoelace formula
  polygonArea(points: Point2D[]): number {
    if (points.length < 3) return 0;
    let area = 0;
    for (let i = 0; i < points.length; i++) {
      const j = (i + 1) % points.length;
      area += points[i].x * points[j].y;
      area -= points[j].x * points[i].y;
    }
    return Math.abs(area) / 2;
  },

  // Perimeter of polygon
  polygonPerimeter(points: Point2D[], closed: boolean = true): number {
    if (points.length < 2) return 0;
    let len = 0;
    const count = closed ? points.length : points.length - 1;
    for (let i = 0; i < count; i++) {
      const next = (i + 1) % points.length;
      len += cadMath.dist(points[i], points[next]);
    }
    return len;
  },

  // Bounding box of entity
  getEntityBounds(entity: CADEntity): { minX: number; minY: number; maxX: number; maxY: number } {
    switch (entity.type) {
      case 'LINE':
        return {
          minX: Math.min(entity.p1.x, entity.p2.x),
          minY: Math.min(entity.p1.y, entity.p2.y),
          maxX: Math.max(entity.p1.x, entity.p2.x),
          maxY: Math.max(entity.p1.y, entity.p2.y),
        };
      case 'RECTANGLE':
        return {
          minX: Math.min(entity.p1.x, entity.p2.x),
          minY: Math.min(entity.p1.y, entity.p2.y),
          maxX: Math.max(entity.p1.x, entity.p2.x),
          maxY: Math.max(entity.p1.y, entity.p2.y),
        };
      case 'CIRCLE':
        return {
          minX: entity.center.x - entity.radius,
          minY: entity.center.y - entity.radius,
          maxX: entity.center.x + entity.radius,
          maxY: entity.center.y + entity.radius,
        };
      case 'ARC':
        return {
          minX: entity.center.x - entity.radius,
          minY: entity.center.y - entity.radius,
          maxX: entity.center.x + entity.radius,
          maxY: entity.center.y + entity.radius,
        };
      case 'ELLIPSE': {
        const maxR = Math.max(entity.rx, entity.ry);
        return {
          minX: entity.center.x - maxR,
          minY: entity.center.y - maxR,
          maxX: entity.center.x + maxR,
          maxY: entity.center.y + maxR,
        };
      }
      case 'LWPOLYLINE':
      case 'HATCH': {
        const pts = entity.type === 'LWPOLYLINE' ? entity.points : entity.boundary;
        if (!pts.length) return { minX: 0, minY: 0, maxX: 0, maxY: 0 };
        let minX = pts[0].x, maxX = pts[0].x, minY = pts[0].y, maxY = pts[0].y;
        for (const p of pts) {
          if (p.x < minX) minX = p.x;
          if (p.x > maxX) maxX = p.x;
          if (p.y < minY) minY = p.y;
          if (p.y > maxY) maxY = p.y;
        }
        return { minX, minY, maxX, maxY };
      }
      case 'POLYGON':
        return {
          minX: entity.center.x - entity.radius,
          minY: entity.center.y - entity.radius,
          maxX: entity.center.x + entity.radius,
          maxY: entity.center.y + entity.radius,
        };
      case 'POINT':
        return {
          minX: entity.point.x - 1,
          minY: entity.point.y - 1,
          maxX: entity.point.x + 1,
          maxY: entity.point.y + 1,
        };
      case 'TEXT':
        return {
          minX: entity.position.x,
          minY: entity.position.y - entity.height,
          maxX: entity.position.x + (entity.text.length * entity.height * 0.6),
          maxY: entity.position.y + entity.height * 0.2,
        };
      case 'DIMENSION':
        return {
          minX: Math.min(entity.p1.x, entity.p2.x, entity.offsetPt.x) - 10,
          minY: Math.min(entity.p1.y, entity.p2.y, entity.offsetPt.y) - 10,
          maxX: Math.max(entity.p1.x, entity.p2.x, entity.offsetPt.x) + 10,
          maxY: Math.max(entity.p1.y, entity.p2.y, entity.offsetPt.y) + 10,
        };
      case 'BLOCK_REF':
        return {
          minX: entity.position.x - 20 * entity.scale,
          minY: entity.position.y - 20 * entity.scale,
          maxX: entity.position.x + 20 * entity.scale,
          maxY: entity.position.y + 20 * entity.scale,
        };
      default:
        return { minX: 0, minY: 0, maxX: 0, maxY: 0 };
    }
  },

  // Hit test entity by point within tolerance (in world coordinates)
  isPointNearEntity(p: Point2D, entity: CADEntity, tol: number): boolean {
    switch (entity.type) {
      case 'LINE':
        return cadMath.projectPointOnSegment(p, entity.p1, entity.p2).distance <= tol;

      case 'RECTANGLE': {
        const { minX, maxX, minY, maxY } = cadMath.getEntityBounds(entity);
        const edges = [
          [{ x: minX, y: minY }, { x: maxX, y: minY }],
          [{ x: maxX, y: minY }, { x: maxX, y: maxY }],
          [{ x: maxX, y: maxY }, { x: minX, y: maxY }],
          [{ x: minX, y: maxY }, { x: minX, y: minY }],
        ];
        return edges.some(([a, b]) => cadMath.projectPointOnSegment(p, a, b).distance <= tol);
      }

      case 'CIRCLE': {
        const d = cadMath.dist(p, entity.center);
        return Math.abs(d - entity.radius) <= tol;
      }

      case 'ARC': {
        const d = cadMath.dist(p, entity.center);
        if (Math.abs(d - entity.radius) > tol) return false;
        let ang = Math.atan2(p.y - entity.center.y, p.x - entity.center.x);
        if (ang < 0) ang += Math.PI * 2;
        let s = entity.startAngle % (Math.PI * 2);
        let e = entity.endAngle % (Math.PI * 2);
        if (s < 0) s += Math.PI * 2;
        if (e < 0) e += Math.PI * 2;
        if (s <= e) return ang >= s && ang <= e;
        return ang >= s || ang <= e;
      }

      case 'LWPOLYLINE': {
        const pts = entity.points;
        const count = entity.closed ? pts.length : pts.length - 1;
        for (let i = 0; i < count; i++) {
          const a = pts[i];
          const b = pts[(i + 1) % pts.length];
          if (cadMath.projectPointOnSegment(p, a, b).distance <= tol) return true;
        }
        return false;
      }

      case 'POINT':
        return cadMath.dist(p, entity.point) <= tol * 2;

      case 'TEXT': {
        const b = cadMath.getEntityBounds(entity);
        return p.x >= b.minX - tol && p.x <= b.maxX + tol && p.y >= b.minY - tol && p.y <= b.maxY + tol;
      }

      case 'DIMENSION': {
        return cadMath.projectPointOnSegment(p, entity.p1, entity.offsetPt).distance <= tol ||
               cadMath.projectPointOnSegment(p, entity.p2, entity.offsetPt).distance <= tol ||
               cadMath.projectPointOnSegment(p, entity.p1, entity.p2).distance <= tol;
      }

      case 'HATCH': {
        // Test boundary
        const pts = entity.boundary;
        for (let i = 0; i < pts.length; i++) {
          const a = pts[i];
          const b = pts[(i + 1) % pts.length];
          if (cadMath.projectPointOnSegment(p, a, b).distance <= tol) return true;
        }
        return false;
      }

      default:
        return false;
    }
  },

  // Check if entity is inside or intersects rectangle
  isEntityInBox(entity: CADEntity, box: { minX: number; minY: number; maxX: number; maxY: number }, crossing: boolean): boolean {
    const eb = cadMath.getEntityBounds(entity);

    // Entirely inside box
    const fullyInside = eb.minX >= box.minX && eb.maxX <= box.maxX && eb.minY >= box.minY && eb.maxY <= box.maxY;
    if (fullyInside) return true;

    // If window selection (not crossing), entity must be fully inside
    if (!crossing) return false;

    // Crossing selection: test if bounds intersect
    const boundsOverlap = !(eb.maxX < box.minX || eb.minX > box.maxX || eb.maxY < box.minY || eb.minY > box.maxY);
    return boundsOverlap;
  },

  // Fillet two lines: computes fillet arc and trimmed lines
  filletLines(
    l1: LineEntity,
    l2: LineEntity,
    radius: number
  ): { arc: { center: Point2D; radius: number; startAngle: number; endAngle: number }; p1Trim: Point2D; p2Trim: Point2D } | null {
    // Find intersection of infinite lines
    const inter = cadMath.lineIntersection(l1.p1, l1.p2, l2.p1, l2.p2, false);
    if (!inter) return null;

    // Vectors away from intersection
    const v1 = cadMath.normalize(cadMath.dist(l1.p1, inter) > cadMath.dist(l1.p2, inter) ? cadMath.sub(l1.p1, inter) : cadMath.sub(l1.p2, inter));
    const v2 = cadMath.normalize(cadMath.dist(l2.p1, inter) > cadMath.dist(l2.p2, inter) ? cadMath.sub(l2.p1, inter) : cadMath.sub(l2.p2, inter));

    const theta = Math.acos(Math.max(-1, Math.min(1, cadMath.dot(v1, v2))));
    if (theta < 1e-4 || Math.abs(theta - Math.PI) < 1e-4) return null;

    const tanDist = radius / Math.tan(theta / 2);
    const p1Trim = cadMath.add(inter, cadMath.scale(v1, tanDist));
    const p2Trim = cadMath.add(inter, cadMath.scale(v2, tanDist));

    // Arc center
    const bisector = cadMath.normalize(cadMath.add(v1, v2));
    const distToCenter = radius / Math.sin(theta / 2);
    const center = cadMath.add(inter, cadMath.scale(bisector, distToCenter));

    let a1 = Math.atan2(p1Trim.y - center.y, p1Trim.x - center.x);
    let a2 = Math.atan2(p2Trim.y - center.y, p2Trim.x - center.x);
    if (a1 < 0) a1 += Math.PI * 2;
    if (a2 < 0) a2 += Math.PI * 2;

    return {
      arc: {
        center,
        radius,
        startAngle: Math.min(a1, a2),
        endAngle: Math.max(a1, a2),
      },
      p1Trim,
      p2Trim,
    };
  },

  // Chamfer two lines
  chamferLines(
    l1: LineEntity,
    l2: LineEntity,
    dist1: number,
    dist2: number
  ): { chamferLine: { p1: Point2D; p2: Point2D }; p1Trim: Point2D; p2Trim: Point2D } | null {
    const inter = cadMath.lineIntersection(l1.p1, l1.p2, l2.p1, l2.p2, false);
    if (!inter) return null;

    const v1 = cadMath.normalize(cadMath.dist(l1.p1, inter) > cadMath.dist(l1.p2, inter) ? cadMath.sub(l1.p1, inter) : cadMath.sub(l1.p2, inter));
    const v2 = cadMath.normalize(cadMath.dist(l2.p1, inter) > cadMath.dist(l2.p2, inter) ? cadMath.sub(l2.p1, inter) : cadMath.sub(l2.p2, inter));

    const p1Trim = cadMath.add(inter, cadMath.scale(v1, dist1));
    const p2Trim = cadMath.add(inter, cadMath.scale(v2, dist2));

    return {
      chamferLine: { p1: p1Trim, p2: p2Trim },
      p1Trim,
      p2Trim,
    };
  },

  // Offset an entity by distance
  offsetEntity(entity: CADEntity, offsetDist: number, sidePoint: Point2D): CADEntity | null {
    switch (entity.type) {
      case 'LINE': {
        const dir = cadMath.sub(entity.p2, entity.p1);
        const len = cadMath.dist(entity.p1, entity.p2);
        if (len < 1e-9) return null;
        // Two perpendicular normal options: (-dy, dx) and (dy, -dx)
        const norm1 = { x: -dir.y / len, y: dir.x / len };
        const norm2 = { x: dir.y / len, y: -dir.x / len };

        const cand1 = cadMath.add(cadMath.midpoint(entity.p1, entity.p2), cadMath.scale(norm1, offsetDist));
        const cand2 = cadMath.add(cadMath.midpoint(entity.p1, entity.p2), cadMath.scale(norm2, offsetDist));

        const chosenNorm = cadMath.dist(cand1, sidePoint) < cadMath.dist(cand2, sidePoint) ? norm1 : norm2;
        const offsetVec = cadMath.scale(chosenNorm, offsetDist);

        return {
          ...entity,
          id: `line_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
          p1: cadMath.add(entity.p1, offsetVec),
          p2: cadMath.add(entity.p2, offsetVec),
        } as LineEntity;
      }

      case 'CIRCLE': {
        const d = cadMath.dist(sidePoint, entity.center);
        const newRadius = d > entity.radius ? entity.radius + offsetDist : Math.max(1, entity.radius - offsetDist);
        return {
          ...entity,
          id: `circle_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
          radius: newRadius,
        } as CircleEntity;
      }

      case 'RECTANGLE': {
        const minX = Math.min(entity.p1.x, entity.p2.x);
        const maxX = Math.max(entity.p1.x, entity.p2.x);
        const minY = Math.min(entity.p1.y, entity.p2.y);
        const maxY = Math.max(entity.p1.y, entity.p2.y);
        const center = { x: (minX + maxX) / 2, y: (minY + maxY) / 2 };

        const isOutside = cadMath.dist(sidePoint, center) > cadMath.dist({ x: maxX, y: maxY }, center);
        const sign = isOutside ? 1 : -1;

        return {
          ...entity,
          id: `rect_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
          p1: { x: minX - sign * offsetDist, y: minY - sign * offsetDist },
          p2: { x: maxX + sign * offsetDist, y: maxY + sign * offsetDist },
        } as RectEntity;
      }

      default:
        return null;
    }
  },
};
