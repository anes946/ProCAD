/**
 * ProCAD - Sample Engineering & Architectural Drawings
 * Production-grade sample projects ready to explore, edit, and export.
 */

import { CADEntity, Layer, Solid3DEntity } from '../types/cad';

export interface SampleProject {
  id: string;
  name: string;
  description: string;
  category: 'Architecture' | 'Mechanical' | 'Electrical';
  layers: Layer[];
  entities: CADEntity[];
  solids3d?: Solid3DEntity[];
}

// 1. Architectural Floor Plan
const ARCH_LAYERS: Layer[] = [
  { id: '0', name: '0', color: '#ffffff', visible: true, locked: false, lineType: 'CONTINUOUS', lineWeight: 0.25 },
  { id: 'WALLS', name: 'A-WALL', color: '#00ffff', visible: true, locked: false, lineType: 'CONTINUOUS', lineWeight: 0.5 },
  { id: 'DOORS', name: 'A-DOOR', color: '#00ff66', visible: true, locked: false, lineType: 'CONTINUOUS', lineWeight: 0.25 },
  { id: 'WINDOWS', name: 'A-GLAZ', color: '#ffff00', visible: true, locked: false, lineType: 'CONTINUOUS', lineWeight: 0.25 },
  { id: 'FURNITURE', name: 'A-FURN', color: '#d946ef', visible: true, locked: false, lineType: 'CONTINUOUS', lineWeight: 0.18 },
  { id: 'DIMS', name: 'A-DIMS', color: '#f97316', visible: true, locked: false, lineType: 'CONTINUOUS', lineWeight: 0.18 },
  { id: 'TEXT', name: 'A-TEXT', color: '#ffffff', visible: true, locked: false, lineType: 'CONTINUOUS', lineWeight: 0.25 },
];

const ARCH_ENTITIES: CADEntity[] = [
  // Exterior Walls (Outer perimeter: 1200 x 800)
  {
    id: 'w_ext_out',
    type: 'RECTANGLE',
    layer: 'WALLS',
    p1: { x: 0, y: 0 },
    p2: { x: 1200, y: 800 },
  },
  // Exterior Walls (Inner perimeter: 20 wall thickness)
  {
    id: 'w_ext_in',
    type: 'RECTANGLE',
    layer: 'WALLS',
    p1: { x: 20, y: 20 },
    p2: { x: 1180, y: 780 },
  },
  // Interior Partition 1: Master bedroom divider
  {
    id: 'w_int_1',
    type: 'LINE',
    layer: 'WALLS',
    p1: { x: 500, y: 20 },
    p2: { x: 500, y: 500 },
  },
  {
    id: 'w_int_1b',
    type: 'LINE',
    layer: 'WALLS',
    p1: { x: 515, y: 20 },
    p2: { x: 515, y: 500 },
  },
  // Partition 2: Hallway / Living divider
  {
    id: 'w_int_2',
    type: 'LINE',
    layer: 'WALLS',
    p1: { x: 20, y: 500 },
    p2: { x: 515, y: 500 },
  },
  {
    id: 'w_int_2b',
    type: 'LINE',
    layer: 'WALLS',
    p1: { x: 20, y: 515 },
    p2: { x: 515, y: 515 },
  },
  // Partition 3: Kitchen divider
  {
    id: 'w_int_3',
    type: 'LINE',
    layer: 'WALLS',
    p1: { x: 800, y: 350 },
    p2: { x: 1180, y: 350 },
  },
  {
    id: 'w_int_3b',
    type: 'LINE',
    layer: 'WALLS',
    p1: { x: 800, y: 365 },
    p2: { x: 1180, y: 365 },
  },

  // Main Entry Door (Swing arc + leaf)
  {
    id: 'door_leaf_entry',
    type: 'LINE',
    layer: 'DOORS',
    p1: { x: 600, y: 20 },
    p2: { x: 600, y: 110 },
  },
  {
    id: 'door_arc_entry',
    type: 'ARC',
    layer: 'DOORS',
    center: { x: 600, y: 20 },
    radius: 90,
    startAngle: 0,
    endAngle: Math.PI / 2,
  },

  // Master Bedroom Door
  {
    id: 'door_leaf_bed',
    type: 'LINE',
    layer: 'DOORS',
    p1: { x: 500, y: 380 },
    p2: { x: 420, y: 380 },
  },
  {
    id: 'door_arc_bed',
    type: 'ARC',
    layer: 'DOORS',
    center: { x: 500, y: 380 },
    radius: 80,
    startAngle: Math.PI / 2,
    endAngle: Math.PI,
  },

  // Windows
  {
    id: 'win_1',
    type: 'RECTANGLE',
    layer: 'WINDOWS',
    p1: { x: 150, y: 0 },
    p2: { x: 350, y: 20 },
  },
  {
    id: 'win_2',
    type: 'RECTANGLE',
    layer: 'WINDOWS',
    p1: { x: 850, y: 0 },
    p2: { x: 1050, y: 20 },
  },
  {
    id: 'win_3',
    type: 'RECTANGLE',
    layer: 'WINDOWS',
    p1: { x: 0, y: 200 },
    p2: { x: 20, y: 360 },
  },
  {
    id: 'win_4',
    type: 'RECTANGLE',
    layer: 'WINDOWS',
    p1: { x: 1180, y: 500 },
    p2: { x: 1200, y: 680 },
  },

  // Master Bed (Queen: 200 x 180)
  {
    id: 'bed_frame',
    type: 'RECTANGLE',
    layer: 'FURNITURE',
    p1: { x: 120, y: 80 },
    p2: { x: 300, y: 280 },
  },
  {
    id: 'pillow_1',
    type: 'RECTANGLE',
    layer: 'FURNITURE',
    p1: { x: 135, y: 95 },
    p2: { x: 195, y: 145 },
  },
  {
    id: 'pillow_2',
    type: 'RECTANGLE',
    layer: 'FURNITURE',
    p1: { x: 225, y: 95 },
    p2: { x: 285, y: 145 },
  },

  // Dining Table (Round with 4 chairs)
  {
    id: 'dining_table',
    type: 'CIRCLE',
    layer: 'FURNITURE',
    center: { x: 950, y: 200 },
    radius: 60,
  },
  {
    id: 'chair_1',
    type: 'CIRCLE',
    layer: 'FURNITURE',
    center: { x: 950, y: 120 },
    radius: 18,
  },
  {
    id: 'chair_2',
    type: 'CIRCLE',
    layer: 'FURNITURE',
    center: { x: 950, y: 280 },
    radius: 18,
  },
  {
    id: 'chair_3',
    type: 'CIRCLE',
    layer: 'FURNITURE',
    center: { x: 870, y: 200 },
    radius: 18,
  },
  {
    id: 'chair_4',
    type: 'CIRCLE',
    layer: 'FURNITURE',
    center: { x: 1030, y: 200 },
    radius: 18,
  },

  // Sofa in Living Room
  {
    id: 'sofa_base',
    type: 'RECTANGLE',
    layer: 'FURNITURE',
    p1: { x: 100, y: 580 },
    p2: { x: 320, y: 680 },
  },
  {
    id: 'coffee_table',
    type: 'RECTANGLE',
    layer: 'FURNITURE',
    p1: { x: 140, y: 705 },
    p2: { x: 280, y: 745 },
  },

  // Room Labels
  {
    id: 'lbl_master',
    type: 'TEXT',
    layer: 'TEXT',
    position: { x: 150, y: 360 },
    text: 'MASTER BEDROOM',
    height: 22,
    rotation: 0,
  },
  {
    id: 'lbl_living',
    type: 'TEXT',
    layer: 'TEXT',
    position: { x: 140, y: 550 },
    text: 'LIVING ROOM',
    height: 24,
    rotation: 0,
  },
  {
    id: 'lbl_dining',
    type: 'TEXT',
    layer: 'TEXT',
    position: { x: 880, y: 100 },
    text: 'DINING AREA',
    height: 20,
    rotation: 0,
  },
  {
    id: 'lbl_kitchen',
    type: 'TEXT',
    layer: 'TEXT',
    position: { x: 920, y: 480 },
    text: 'GOURMET KITCHEN',
    height: 22,
    rotation: 0,
  },

  // Dimensions
  {
    id: 'dim_overall_width',
    type: 'DIMENSION',
    layer: 'DIMS',
    dimType: 'LINEAR',
    p1: { x: 0, y: 0 },
    p2: { x: 1200, y: 0 },
    offsetPt: { x: 600, y: -60 },
    suffix: ' mm',
  },
  {
    id: 'dim_overall_height',
    type: 'DIMENSION',
    layer: 'DIMS',
    dimType: 'LINEAR',
    p1: { x: 1200, y: 0 },
    p2: { x: 1200, y: 800 },
    offsetPt: { x: 1260, y: 400 },
    suffix: ' mm',
  },
  {
    id: 'dim_bed_width',
    type: 'DIMENSION',
    layer: 'DIMS',
    dimType: 'LINEAR',
    p1: { x: 0, y: 0 },
    p2: { x: 500, y: 0 },
    offsetPt: { x: 250, y: -30 },
    suffix: ' mm',
  },
];

// 2. Precision Mechanical Flange & Coupling Drawing
const MECH_LAYERS: Layer[] = [
  { id: '0', name: '0', color: '#ffffff', visible: true, locked: false, lineType: 'CONTINUOUS', lineWeight: 0.25 },
  { id: 'OUTLINE', name: 'OBJECT_LINES', color: '#00ffff', visible: true, locked: false, lineType: 'CONTINUOUS', lineWeight: 0.5 },
  { id: 'CENTER', name: 'CENTERLINES', color: '#ef4444', visible: true, locked: false, lineType: 'CENTER', lineWeight: 0.18 },
  { id: 'BOLTS', name: 'BOLT_HOLES', color: '#22c55e', visible: true, locked: false, lineType: 'CONTINUOUS', lineWeight: 0.35 },
  { id: 'HATCH', name: 'SECTION_HATCH', color: '#94a3b8', visible: true, locked: false, lineType: 'CONTINUOUS', lineWeight: 0.13 },
  { id: 'DIMS', name: 'DIMENSIONS', color: '#f59e0b', visible: true, locked: false, lineType: 'CONTINUOUS', lineWeight: 0.18 },
  { id: 'TEXT', name: 'NOTES', color: '#ffffff', visible: true, locked: false, lineType: 'CONTINUOUS', lineWeight: 0.25 },
];

const MECH_ENTITIES: CADEntity[] = [
  // Centerlines
  {
    id: 'c_line_h',
    type: 'LINE',
    layer: 'CENTER',
    p1: { x: 150, y: 400 },
    p2: { x: 650, y: 400 },
  },
  {
    id: 'c_line_v',
    type: 'LINE',
    layer: 'CENTER',
    p1: { x: 400, y: 150 },
    p2: { x: 400, y: 650 },
  },

  // Outer Flange Rim (Diameter 360mm -> Radius 180)
  {
    id: 'flange_outer',
    type: 'CIRCLE',
    layer: 'OUTLINE',
    center: { x: 400, y: 400 },
    radius: 180,
  },

  // Raised Hub Step (Diameter 240mm -> Radius 120)
  {
    id: 'flange_hub',
    type: 'CIRCLE',
    layer: 'OUTLINE',
    center: { x: 400, y: 400 },
    radius: 120,
  },

  // Bolt Pitch Circle (Diameter 300mm -> Radius 150)
  {
    id: 'pcd_circle',
    type: 'CIRCLE',
    layer: 'CENTER',
    center: { x: 400, y: 400 },
    radius: 150,
  },

  // 6 Bolt Holes (Diameter 24mm -> Radius 12)
  ...[0, 60, 120, 180, 240, 300].map((deg, i) => {
    const rad = (deg * Math.PI) / 180;
    return {
      id: `bolt_hole_${i}`,
      type: 'CIRCLE' as const,
      layer: 'BOLTS',
      center: {
        x: 400 + 150 * Math.cos(rad),
        y: 400 + 150 * Math.sin(rad),
      },
      radius: 12,
    };
  }),

  // Center Bore (Diameter 90mm -> Radius 45)
  {
    id: 'center_bore',
    type: 'CIRCLE',
    layer: 'OUTLINE',
    center: { x: 400, y: 400 },
    radius: 45,
  },

  // Keyway slot in bore (16mm wide x 6mm deep)
  {
    id: 'keyway',
    type: 'RECTANGLE',
    layer: 'OUTLINE',
    p1: { x: 392, y: 350 },
    p2: { x: 408, y: 365 },
  },

  // Section Hatching sample
  {
    id: 'hatch_sec1',
    type: 'HATCH',
    layer: 'HATCH',
    pattern: 'ANSI31',
    boundary: [
      { x: 445, y: 400 },
      { x: 520, y: 400 },
      { x: 520, y: 450 },
      { x: 445, y: 450 },
    ],
    scale: 8,
    angle: 45,
  },

  // Dimensions
  {
    id: 'dim_flange_dia',
    type: 'DIMENSION',
    layer: 'DIMS',
    dimType: 'LINEAR',
    p1: { x: 220, y: 400 },
    p2: { x: 580, y: 400 },
    offsetPt: { x: 400, y: 620 },
    prefix: 'Ø ',
    suffix: ' mm',
  },
  {
    id: 'dim_pcd',
    type: 'DIMENSION',
    layer: 'DIMS',
    dimType: 'LINEAR',
    p1: { x: 250, y: 400 },
    p2: { x: 550, y: 400 },
    offsetPt: { x: 400, y: 570 },
    prefix: 'PCD Ø ',
  },
  {
    id: 'dim_bore',
    type: 'DIMENSION',
    layer: 'DIMS',
    dimType: 'LINEAR',
    p1: { x: 355, y: 400 },
    p2: { x: 445, y: 400 },
    offsetPt: { x: 400, y: 330 },
    prefix: 'BORE Ø ',
  },

  // Notes
  {
    id: 'title_note',
    type: 'TEXT',
    layer: 'TEXT',
    position: { x: 220, y: 720 },
    text: 'DN150 PN16 CLASS FLANGE COUPLING',
    height: 18,
    rotation: 0,
  },
  {
    id: 'material_note',
    type: 'TEXT',
    layer: 'TEXT',
    position: { x: 220, y: 690 },
    text: 'MATERIAL: ASTM A105 FORGED CARBON STEEL',
    height: 12,
    rotation: 0,
  },
];

// Sample 3D Solids for Mechanical Project
const MECH_SOLIDS: Solid3DEntity[] = [
  {
    id: 'solid_flange_base',
    name: 'Flange Base Disc',
    shape: 'CYLINDER',
    position: { x: 0, y: 0, z: 10 },
    rotation: { x: 0, y: 0, z: 0 },
    scale: { x: 1, y: 1, z: 1 },
    parameters: {
      radiusTop: 90,
      radiusBottom: 90,
      height: 20,
      segments: 48,
    },
    color: '#38bdf8',
  },
  {
    id: 'solid_flange_hub',
    name: 'Coupling Hub',
    shape: 'CYLINDER',
    position: { x: 0, y: 0, z: 40 },
    rotation: { x: 0, y: 0, z: 0 },
    scale: { x: 1, y: 1, z: 1 },
    parameters: {
      radiusTop: 60,
      radiusBottom: 60,
      height: 40,
      segments: 48,
    },
    color: '#0284c7',
  },
  {
    id: 'solid_center_hole',
    name: 'Center Shaft Bore',
    shape: 'CYLINDER',
    position: { x: 0, y: 0, z: 30 },
    rotation: { x: 0, y: 0, z: 0 },
    scale: { x: 1, y: 1, z: 1 },
    parameters: {
      radiusTop: 22.5,
      radiusBottom: 22.5,
      height: 70,
      segments: 32,
    },
    color: '#0f172a',
    wireframe: true,
  },
];

export const sampleProjects: SampleProject[] = [
  {
    id: 'arch_sample',
    name: 'Modern 2-Bed Residence',
    description: 'Detailed architectural floor plan featuring exterior/interior walls, swing doors, glazing, furniture layout, and dimension chains.',
    category: 'Architecture',
    layers: ARCH_LAYERS,
    entities: ARCH_ENTITIES,
  },
  {
    id: 'mech_sample',
    name: 'DN150 Flange Coupling',
    description: 'Precision mechanical engineering drawing with PCD bolt circle, centerlines, bore with keyway, crosshatch, and 3D solid model.',
    category: 'Mechanical',
    layers: MECH_LAYERS,
    entities: MECH_ENTITIES,
    solids3d: MECH_SOLIDS,
  },
];
