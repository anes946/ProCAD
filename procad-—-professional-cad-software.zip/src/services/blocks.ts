/**
 * ProCAD - Reusable CAD Symbol & Block Library
 */

import { BlockDefinition, CADEntity } from '../types/cad';

export const cadBlocks: BlockDefinition[] = [
  // ARCHITECTURAL BLOCKS
  {
    name: 'Door 900mm (Swing)',
    description: 'Standard 900mm internal hinged door with 90° swing arc and frame',
    category: 'Architectural',
    basePoint: { x: 0, y: 0 },
    entities: [
      {
        id: 'b_door_jamb_l',
        type: 'RECTANGLE',
        layer: 'DOORS',
        p1: { x: -5, y: -5 },
        p2: { x: 5, y: 5 },
      },
      {
        id: 'b_door_jamb_r',
        type: 'RECTANGLE',
        layer: 'DOORS',
        p1: { x: 85, y: -5 },
        p2: { x: 95, y: 5 },
      },
      {
        id: 'b_door_leaf',
        type: 'LINE',
        layer: 'DOORS',
        p1: { x: 0, y: 0 },
        p2: { x: 0, y: 90 },
      },
      {
        id: 'b_door_arc',
        type: 'ARC',
        layer: 'DOORS',
        center: { x: 0, y: 0 },
        radius: 90,
        startAngle: 0,
        endAngle: Math.PI / 2,
      },
    ],
  },
  {
    name: 'Window 1200mm',
    description: '1200mm wide exterior double-glazed window unit',
    category: 'Architectural',
    basePoint: { x: 0, y: 0 },
    entities: [
      {
        id: 'b_win_out',
        type: 'RECTANGLE',
        layer: 'WINDOWS',
        p1: { x: 0, y: -10 },
        p2: { x: 120, y: 10 },
      },
      {
        id: 'b_win_pane1',
        type: 'LINE',
        layer: 'WINDOWS',
        p1: { x: 0, y: 0 },
        p2: { x: 120, y: 0 },
      },
      {
        id: 'b_win_divider',
        type: 'LINE',
        layer: 'WINDOWS',
        p1: { x: 60, y: -10 },
        p2: { x: 60, y: 10 },
      },
    ],
  },
  {
    name: 'Dining Set (4-Seater)',
    description: 'Circular dining table with 4 perimeter chairs',
    category: 'Architectural',
    basePoint: { x: 0, y: 0 },
    entities: [
      {
        id: 'b_table',
        type: 'CIRCLE',
        layer: 'FURNITURE',
        center: { x: 0, y: 0 },
        radius: 45,
      },
      { id: 'b_c1', type: 'CIRCLE', layer: 'FURNITURE', center: { x: 0, y: -55 }, radius: 12 },
      { id: 'b_c2', type: 'CIRCLE', layer: 'FURNITURE', center: { x: 0, y: 55 }, radius: 12 },
      { id: 'b_c3', type: 'CIRCLE', layer: 'FURNITURE', center: { x: -55, y: 0 }, radius: 12 },
      { id: 'b_c4', type: 'CIRCLE', layer: 'FURNITURE', center: { x: 55, y: 0 }, radius: 12 },
    ],
  },
  {
    name: 'Queen Bed (1600x2000)',
    description: 'Double bed with frame and twin pillows',
    category: 'Architectural',
    basePoint: { x: 0, y: 0 },
    entities: [
      {
        id: 'b_bed_frame',
        type: 'RECTANGLE',
        layer: 'FURNITURE',
        p1: { x: -80, y: 0 },
        p2: { x: 80, y: 200 },
      },
      {
        id: 'b_bed_headboard',
        type: 'RECTANGLE',
        layer: 'FURNITURE',
        p1: { x: -85, y: -10 },
        p2: { x: 85, y: 0 },
      },
      {
        id: 'b_pillow_l',
        type: 'RECTANGLE',
        layer: 'FURNITURE',
        p1: { x: -70, y: 15 },
        p2: { x: -15, y: 55 },
      },
      {
        id: 'b_pillow_r',
        type: 'RECTANGLE',
        layer: 'FURNITURE',
        p1: { x: 15, y: 15 },
        p2: { x: 70, y: 55 },
      },
    ],
  },

  // MECHANICAL BLOCKS
  {
    name: 'Hex Bolt M12 (Top View)',
    description: 'ISO standard hexagon bolt head with threaded hole',
    category: 'Mechanical',
    basePoint: { x: 0, y: 0 },
    entities: [
      {
        id: 'b_bolt_head',
        type: 'POLYGON',
        layer: 'OUTLINE',
        center: { x: 0, y: 0 },
        radius: 12,
        sides: 6,
      },
      {
        id: 'b_bolt_hole',
        type: 'CIRCLE',
        layer: 'OUTLINE',
        center: { x: 0, y: 0 },
        radius: 6,
      },
    ],
  },
  {
    name: 'Ball Bearing 6205',
    description: 'Radial deep-groove ball bearing with 8 rolling elements',
    category: 'Mechanical',
    basePoint: { x: 0, y: 0 },
    entities: [
      { id: 'b_brg_out', type: 'CIRCLE', layer: 'OUTLINE', center: { x: 0, y: 0 }, radius: 26 },
      { id: 'b_brg_in', type: 'CIRCLE', layer: 'OUTLINE', center: { x: 0, y: 0 }, radius: 12.5 },
      ...[0, 45, 90, 135, 180, 225, 270, 315].map((deg, i) => ({
        id: `b_brg_ball_${i}`,
        type: 'CIRCLE' as const,
        layer: 'OUTLINE',
        center: {
          x: 19.25 * Math.cos((deg * Math.PI) / 180),
          y: 19.25 * Math.sin((deg * Math.PI) / 180),
        },
        radius: 4,
      })),
    ],
  },

  // ELECTRICAL BLOCKS
  {
    name: 'Electric Motor Symbol',
    description: 'IEC Standard single-phase/three-phase AC motor symbol',
    category: 'Electrical',
    basePoint: { x: 0, y: 0 },
    entities: [
      { id: 'b_mot_c', type: 'CIRCLE', layer: 'OUTLINE', center: { x: 0, y: 0 }, radius: 20 },
      { id: 'b_mot_txt', type: 'TEXT', layer: 'OUTLINE', position: { x: -8, y: -8 }, text: 'M', height: 16, rotation: 0 },
      { id: 'b_mot_t1', type: 'LINE', layer: 'OUTLINE', p1: { x: 0, y: 20 }, p2: { x: 0, y: 35 } },
      { id: 'b_mot_t2', type: 'LINE', layer: 'OUTLINE', p1: { x: 0, y: -20 }, p2: { x: 0, y: -35 } },
    ],
  },
  {
    name: 'Ground / Earth Symbol',
    description: 'Chassis/Protective earth ground terminal',
    category: 'Electrical',
    basePoint: { x: 0, y: 0 },
    entities: [
      { id: 'b_gnd_stem', type: 'LINE', layer: 'OUTLINE', p1: { x: 0, y: 20 }, p2: { x: 0, y: 0 } },
      { id: 'b_gnd_bar1', type: 'LINE', layer: 'OUTLINE', p1: { x: -16, y: 0 }, p2: { x: 16, y: 0 } },
      { id: 'b_gnd_bar2', type: 'LINE', layer: 'OUTLINE', p1: { x: -10, y: -5 }, p2: { x: 10, y: -5 } },
      { id: 'b_gnd_bar3', type: 'LINE', layer: 'OUTLINE', p1: { x: -4, y: -10 }, p2: { x: 4, y: -10 } },
    ],
  },
];
