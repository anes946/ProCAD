/**
 * ProCAD - DXF, SVG, and Project Exchange Engine
 * Implements standard ASCII DXF parser/writer, SVG export/import, and native JSON projects.
 */

import { CADEntity, Layer, LineEntity, CircleEntity, ArcEntity, PolylineEntity, TextEntity, RectEntity, PointEntity } from '../types/cad';
import { cadMath } from '../geometry/cadMath';

// AutoCAD Color Index (ACI) mapping for common hex colors
const ACI_COLORS: Record<number, string> = {
  1: '#ff0000', // Red
  2: '#ffff00', // Yellow
  3: '#00ff00', // Green
  4: '#00ffff', // Cyan
  5: '#0000ff', // Blue
  6: '#ff00ff', // Magenta
  7: '#ffffff', // White/Black
  8: '#808080', // Dark Grey
  9: '#c0c0c0', // Light Grey
};

function hexToACI(hex?: string): number {
  if (!hex) return 7;
  const lower = hex.toLowerCase();
  for (const [aci, code] of Object.entries(ACI_COLORS)) {
    if (code === lower) return parseInt(aci);
  }
  return 7;
}

export const dxfService = {
  // Export to standard AutoCAD DXF (R12 / R2000 ASCII format)
  exportDXF(entities: CADEntity[], layers: Layer[]): string {
    const lines: string[] = [];

    const add = (code: number, val: string | number) => {
      lines.push(`${code}`);
      lines.push(`${val}`);
    };

    // Header
    add(0, 'SECTION');
    add(2, 'HEADER');
    add(9, '$ACADVER');
    add(1, 'AC1009'); // AutoCAD R12 ASCII compatibility
    add(9, '$INSUNITS');
    add(70, 4); // Millimeters
    add(0, 'ENDSEC');

    // Tables
    add(0, 'SECTION');
    add(2, 'TABLES');
    add(0, 'TABLE');
    add(2, 'LAYER');
    add(70, layers.length);

    layers.forEach((l) => {
      add(0, 'LAYER');
      add(2, l.name.toUpperCase().replace(/\s+/g, '_'));
      add(70, 0);
      add(62, hexToACI(l.color));
      add(6, 'CONTINUOUS');
    });

    add(0, 'ENDTAB');
    add(0, 'ENDSEC');

    // Blocks section
    add(0, 'SECTION');
    add(2, 'BLOCKS');
    add(0, 'ENDSEC');

    // Entities section
    add(0, 'SECTION');
    add(2, 'ENTITIES');

    entities.forEach((ent) => {
      const layerName = (ent.layer || '0').toUpperCase().replace(/\s+/g, '_');

      switch (ent.type) {
        case 'LINE':
          add(0, 'LINE');
          add(8, layerName);
          add(10, ent.p1.x.toFixed(4));
          add(20, ent.p1.y.toFixed(4));
          add(30, 0);
          add(11, ent.p2.x.toFixed(4));
          add(21, ent.p2.y.toFixed(4));
          add(31, 0);
          break;

        case 'CIRCLE':
          add(0, 'CIRCLE');
          add(8, layerName);
          add(10, ent.center.x.toFixed(4));
          add(20, ent.center.y.toFixed(4));
          add(30, 0);
          add(40, ent.radius.toFixed(4));
          break;

        case 'ARC': {
          add(0, 'ARC');
          add(8, layerName);
          add(10, ent.center.x.toFixed(4));
          add(20, ent.center.y.toFixed(4));
          add(30, 0);
          add(40, ent.radius.toFixed(4));
          const sDeg = (ent.startAngle * 180) / Math.PI;
          const eDeg = (ent.endAngle * 180) / Math.PI;
          add(50, sDeg.toFixed(2));
          add(51, eDeg.toFixed(2));
          break;
        }

        case 'RECTANGLE': {
          const minX = Math.min(ent.p1.x, ent.p2.x);
          const maxX = Math.max(ent.p1.x, ent.p2.x);
          const minY = Math.min(ent.p1.y, ent.p2.y);
          const maxY = Math.max(ent.p1.y, ent.p2.y);

          const pts = [
            { x: minX, y: minY },
            { x: maxX, y: minY },
            { x: maxX, y: maxY },
            { x: minX, y: maxY },
          ];

          add(0, 'POLYLINE');
          add(8, layerName);
          add(66, 1);
          add(70, 1); // Closed

          pts.forEach((pt) => {
            add(0, 'VERTEX');
            add(8, layerName);
            add(10, pt.x.toFixed(4));
            add(20, pt.y.toFixed(4));
            add(30, 0);
          });
          add(0, 'SEQEND');
          break;
        }

        case 'LWPOLYLINE':
          add(0, 'POLYLINE');
          add(8, layerName);
          add(66, 1);
          add(70, ent.closed ? 1 : 0);

          ent.points.forEach((pt) => {
            add(0, 'VERTEX');
            add(8, layerName);
            add(10, pt.x.toFixed(4));
            add(20, pt.y.toFixed(4));
            add(30, 0);
          });
          add(0, 'SEQEND');
          break;

        case 'POINT':
          add(0, 'POINT');
          add(8, layerName);
          add(10, ent.point.x.toFixed(4));
          add(20, ent.point.y.toFixed(4));
          add(30, 0);
          break;

        case 'TEXT':
          add(0, 'TEXT');
          add(8, layerName);
          add(10, ent.position.x.toFixed(4));
          add(20, ent.position.y.toFixed(4));
          add(30, 0);
          add(40, ent.height.toFixed(4));
          add(1, ent.text);
          add(50, ent.rotation.toFixed(2));
          break;

        case 'DIMENSION':
          // Represent dimension as witness lines and text for DXF export
          add(0, 'LINE');
          add(8, layerName);
          add(10, ent.p1.x.toFixed(4));
          add(20, ent.p1.y.toFixed(4));
          add(30, 0);
          add(11, ent.offsetPt.x.toFixed(4));
          add(21, ent.offsetPt.y.toFixed(4));
          add(31, 0);

          add(0, 'TEXT');
          add(8, layerName);
          add(10, ((ent.p1.x + ent.p2.x) / 2).toFixed(4));
          add(20, (ent.offsetPt.y + 4).toFixed(4));
          add(30, 0);
          add(40, 5);
          add(1, `${Math.round(cadMath.dist(ent.p1, ent.p2))}`);
          break;

        default:
          break;
      }
    });

    add(0, 'ENDSEC');
    add(0, 'EOF');

    return lines.join('\n');
  },

  // Import standard DXF text
  parseDXF(dxfContent: string): { entities: CADEntity[]; layers: Layer[] } {
    const rawLines = dxfContent.split(/\r?\n/).map((l) => l.trim());
    const entities: CADEntity[] = [];
    const layersMap: Map<string, Layer> = new Map();

    // Default layer 0
    layersMap.set('0', {
      id: '0',
      name: '0',
      color: '#ffffff',
      visible: true,
      locked: false,
      lineType: 'CONTINUOUS',
      lineWeight: 0.25,
    });

    let i = 0;
    while (i < rawLines.length - 1) {
      const code = parseInt(rawLines[i]);
      const val = rawLines[i + 1];
      i += 2;

      if (code === 0 && val === 'LAYER') {
        let layerName = 'NEW_LAYER';
        let colorAci = 7;
        while (i < rawLines.length - 1 && rawLines[i] !== '0') {
          const lCode = parseInt(rawLines[i]);
          const lVal = rawLines[i + 1];
          i += 2;
          if (lCode === 2) layerName = lVal;
          if (lCode === 62) colorAci = Math.abs(parseInt(lVal));
        }
        layersMap.set(layerName, {
          id: layerName,
          name: layerName,
          color: ACI_COLORS[colorAci] || '#ffffff',
          visible: true,
          locked: false,
          lineType: 'CONTINUOUS',
          lineWeight: 0.25,
        });
      }

      if (code === 0 && val === 'LINE') {
        let x1 = 0, y1 = 0, x2 = 0, y2 = 0;
        let layer = '0';
        while (i < rawLines.length - 1 && rawLines[i] !== '0') {
          const c = parseInt(rawLines[i]);
          const v = rawLines[i + 1];
          i += 2;
          if (c === 8) layer = v;
          if (c === 10) x1 = parseFloat(v);
          if (c === 20) y1 = parseFloat(v);
          if (c === 11) x2 = parseFloat(v);
          if (c === 21) y2 = parseFloat(v);
        }
        entities.push({
          id: `line_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
          type: 'LINE',
          layer,
          p1: { x: x1, y: y1 },
          p2: { x: x2, y: y2 },
        } as LineEntity);
      }

      if (code === 0 && val === 'CIRCLE') {
        let cx = 0, cy = 0, r = 10;
        let layer = '0';
        while (i < rawLines.length - 1 && rawLines[i] !== '0') {
          const c = parseInt(rawLines[i]);
          const v = rawLines[i + 1];
          i += 2;
          if (c === 8) layer = v;
          if (c === 10) cx = parseFloat(v);
          if (c === 20) cy = parseFloat(v);
          if (c === 40) r = parseFloat(v);
        }
        entities.push({
          id: `circ_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
          type: 'CIRCLE',
          layer,
          center: { x: cx, y: cy },
          radius: r,
        } as CircleEntity);
      }

      if (code === 0 && val === 'ARC') {
        let cx = 0, cy = 0, r = 10, startDeg = 0, endDeg = 180;
        let layer = '0';
        while (i < rawLines.length - 1 && rawLines[i] !== '0') {
          const c = parseInt(rawLines[i]);
          const v = rawLines[i + 1];
          i += 2;
          if (c === 8) layer = v;
          if (c === 10) cx = parseFloat(v);
          if (c === 20) cy = parseFloat(v);
          if (c === 40) r = parseFloat(v);
          if (c === 50) startDeg = parseFloat(v);
          if (c === 51) endDeg = parseFloat(v);
        }
        entities.push({
          id: `arc_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
          type: 'ARC',
          layer,
          center: { x: cx, y: cy },
          radius: r,
          startAngle: (startDeg * Math.PI) / 180,
          endAngle: (endDeg * Math.PI) / 180,
        } as ArcEntity);
      }

      if (code === 0 && (val === 'POLYLINE' || val === 'LWPOLYLINE')) {
        let layer = '0';
        let closed = false;
        const pts: { x: number; y: number }[] = [];

        while (i < rawLines.length - 1) {
          const c = parseInt(rawLines[i]);
          const v = rawLines[i + 1];

          if (c === 0 && (v === 'SEQEND' || v === 'ENDSEC' || v === 'LINE' || v === 'CIRCLE' || v === 'POLYLINE')) {
            break;
          }
          i += 2;
          if (c === 8) layer = v;
          if (c === 70) closed = (parseInt(v) & 1) === 1;

          if (c === 0 && v === 'VERTEX') {
            let vx = 0, vy = 0;
            while (i < rawLines.length - 1 && rawLines[i] !== '0') {
              const vc = parseInt(rawLines[i]);
              const vv = rawLines[i + 1];
              i += 2;
              if (vc === 10) vx = parseFloat(vv);
              if (vc === 20) vy = parseFloat(vv);
            }
            pts.push({ x: vx, y: vy });
          }
        }

        if (pts.length >= 2) {
          entities.push({
            id: `poly_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
            type: 'LWPOLYLINE',
            layer,
            points: pts,
            closed,
          } as PolylineEntity);
        }
      }

      if (code === 0 && val === 'TEXT') {
        let x = 0, y = 0, h = 5, rot = 0, text = '';
        let layer = '0';
        while (i < rawLines.length - 1 && rawLines[i] !== '0') {
          const c = parseInt(rawLines[i]);
          const v = rawLines[i + 1];
          i += 2;
          if (c === 8) layer = v;
          if (c === 10) x = parseFloat(v);
          if (c === 20) y = parseFloat(v);
          if (c === 40) h = parseFloat(v);
          if (c === 50) rot = parseFloat(v);
          if (c === 1) text = v;
        }
        entities.push({
          id: `text_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
          type: 'TEXT',
          layer,
          position: { x, y },
          height: h,
          rotation: rot,
          text,
        } as TextEntity);
      }
    }

    return {
      entities,
      layers: Array.from(layersMap.values()),
    };
  },

  // Export to SVG vector document
  exportSVG(entities: CADEntity[], layers: Layer[], width = 1200, height = 800): string {
    // Calculate bounding box of all entities
    let minX = 0, minY = 0, maxX = 100, maxY = 100;
    if (entities.length > 0) {
      const b0 = cadMath.getEntityBounds(entities[0]);
      minX = b0.minX;
      minY = b0.minY;
      maxX = b0.maxX;
      maxY = b0.maxY;
      entities.forEach((e) => {
        const b = cadMath.getEntityBounds(e);
        minX = Math.min(minX, b.minX);
        minY = Math.min(minY, b.minY);
        maxX = Math.max(maxX, b.maxX);
        maxY = Math.max(maxY, b.maxY);
      });
    }

    const margin = 20;
    const viewW = Math.max(50, maxX - minX + margin * 2);
    const viewH = Math.max(50, maxY - minY + margin * 2);
    const viewBoxX = minX - margin;
    const viewBoxY = minY - margin;

    const layerMap = new Map(layers.map((l) => [l.id, l]));

    let svg = `<?xml version="1.0" encoding="UTF-8"?>\n`;
    svg += `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${viewBoxX} ${viewBoxY} ${viewW} ${viewH}" width="${width}" height="${height}" style="background:#1e1e1e">\n`;
    svg += `  <style>\n`;
    svg += `    text { font-family: monospace; fill: #ffffff; }\n`;
    svg += `  </style>\n`;

    entities.forEach((ent) => {
      const layer = layerMap.get(ent.layer);
      const stroke = ent.color || layer?.color || '#ffffff';
      const strokeWidth = (ent.lineWeight || layer?.lineWeight || 0.25) * 1.5;

      switch (ent.type) {
        case 'LINE':
          svg += `  <line x1="${ent.p1.x}" y1="${ent.p1.y}" x2="${ent.p2.x}" y2="${ent.p2.y}" stroke="${stroke}" stroke-width="${strokeWidth}" />\n`;
          break;

        case 'RECTANGLE': {
          const rx = Math.min(ent.p1.x, ent.p2.x);
          const ry = Math.min(ent.p1.y, ent.p2.y);
          const rw = Math.abs(ent.p2.x - ent.p1.x);
          const rh = Math.abs(ent.p2.y - ent.p1.y);
          svg += `  <rect x="${rx}" y="${ry}" width="${rw}" height="${rh}" fill="none" stroke="${stroke}" stroke-width="${strokeWidth}" />\n`;
          break;
        }

        case 'CIRCLE':
          svg += `  <circle cx="${ent.center.x}" cy="${ent.center.y}" r="${ent.radius}" fill="none" stroke="${stroke}" stroke-width="${strokeWidth}" />\n`;
          break;

        case 'ARC': {
          const sx = ent.center.x + ent.radius * Math.cos(ent.startAngle);
          const sy = ent.center.y + ent.radius * Math.sin(ent.startAngle);
          const ex = ent.center.x + ent.radius * Math.cos(ent.endAngle);
          const ey = ent.center.y + ent.radius * Math.sin(ent.endAngle);
          let diff = ent.endAngle - ent.startAngle;
          if (diff < 0) diff += Math.PI * 2;
          const largeArc = diff > Math.PI ? 1 : 0;
          svg += `  <path d="M ${sx} ${sy} A ${ent.radius} ${ent.radius} 0 ${largeArc} 1 ${ex} ${ey}" fill="none" stroke="${stroke}" stroke-width="${strokeWidth}" />\n`;
          break;
        }

        case 'LWPOLYLINE': {
          const ptsStr = ent.points.map((p) => `${p.x},${p.y}`).join(' ');
          if (ent.closed) {
            svg += `  <polygon points="${ptsStr}" fill="none" stroke="${stroke}" stroke-width="${strokeWidth}" />\n`;
          } else {
            svg += `  <polyline points="${ptsStr}" fill="none" stroke="${stroke}" stroke-width="${strokeWidth}" />\n`;
          }
          break;
        }

        case 'TEXT':
          svg += `  <text x="${ent.position.x}" y="${ent.position.y}" font-size="${ent.height}" transform="rotate(${ent.rotation || 0} ${ent.position.x} ${ent.position.y})">${ent.text}</text>\n`;
          break;

        default:
          break;
      }
    });

    svg += `</svg>`;
    return svg;
  },

  // Parse SVG string into CAD entities
  parseSVG(svgContent: string): CADEntity[] {
    const parser = new DOMParser();
    const doc = parser.parseFromString(svgContent, 'image/svg+xml');
    const entities: CADEntity[] = [];

    // Lines
    const lines = doc.querySelectorAll('line');
    lines.forEach((line) => {
      const x1 = parseFloat(line.getAttribute('x1') || '0');
      const y1 = parseFloat(line.getAttribute('y1') || '0');
      const x2 = parseFloat(line.getAttribute('x2') || '0');
      const y2 = parseFloat(line.getAttribute('y2') || '0');
      const stroke = line.getAttribute('stroke') || undefined;
      entities.push({
        id: `line_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
        type: 'LINE',
        layer: '0',
        color: stroke,
        p1: { x: x1, y: y1 },
        p2: { x: x2, y: y2 },
      } as LineEntity);
    });

    // Rectangles
    const rects = doc.querySelectorAll('rect');
    rects.forEach((rect) => {
      const x = parseFloat(rect.getAttribute('x') || '0');
      const y = parseFloat(rect.getAttribute('y') || '0');
      const w = parseFloat(rect.getAttribute('width') || '10');
      const h = parseFloat(rect.getAttribute('height') || '10');
      const stroke = rect.getAttribute('stroke') || undefined;
      entities.push({
        id: `rect_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
        type: 'RECTANGLE',
        layer: '0',
        color: stroke,
        p1: { x, y },
        p2: { x: x + w, y: y + h },
      } as RectEntity);
    });

    // Circles
    const circles = doc.querySelectorAll('circle');
    circles.forEach((circ) => {
      const cx = parseFloat(circ.getAttribute('cx') || '0');
      const cy = parseFloat(circ.getAttribute('cy') || '0');
      const r = parseFloat(circ.getAttribute('r') || '10');
      const stroke = circ.getAttribute('stroke') || undefined;
      entities.push({
        id: `circ_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
        type: 'CIRCLE',
        layer: '0',
        color: stroke,
        center: { x: cx, y: cy },
        radius: r,
      } as CircleEntity);
    });

    return entities;
  },

  // Export native project JSON
  exportJSON(entities: CADEntity[], layers: Layer[], solids: any[] = []): string {
    const data = {
      app: 'ProCAD',
      version: '1.0.0',
      timestamp: new Date().toISOString(),
      layers,
      entities,
      solids3d: solids,
    };
    return JSON.stringify(data, null, 2);
  },

  // Import native project JSON
  parseJSON(jsonContent: string): { entities: CADEntity[]; layers: Layer[]; solids3d?: any[] } {
    const data = JSON.parse(jsonContent);
    return {
      entities: data.entities || [],
      layers: data.layers || [],
      solids3d: data.solids3d || [],
    };
  },

  // Client-side file downloader helper
  downloadFile(fileName: string, content: string, mimeType: string) {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  },
};
