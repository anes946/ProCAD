/**
 * ProCAD - Central CAD State Management & Command Dispatcher
 */

import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import {
  CADEntity,
  Layer,
  CADTool,
  ViewMode,
  Point2D,
  SnapPoint,
  Solid3DEntity,
  LineEntity,
  CircleEntity,
  RectEntity,
  ArcEntity,
  PolylineEntity,
} from '../types/cad';
import { SnapSettings, defaultSnapSettings } from '../geometry/snapping';
import { cadMath } from '../geometry/cadMath';
import { sampleProjects } from '../services/sampleDrawings';
import { dxfService } from '../services/dxfService';

export interface CADContextType {
  entities: CADEntity[];
  layers: Layer[];
  activeLayerId: string;
  activeTool: CADTool;
  selectedIds: string[];
  viewMode: ViewMode;
  solids3d: Solid3DEntity[];
  cursorPos: Point2D;
  snapSettings: SnapSettings;
  activeSnap: SnapPoint | null;
  gridSettings: { enabled: boolean; snapToGrid: boolean; size: number; majorEvery: number };
  orthoMode: boolean;
  polarTracking: boolean;
  polarAngleStep: number;
  dynamicInput: boolean;
  units: 'mm' | 'm' | 'cm' | 'inch' | 'ft';
  commandPrompt: string;
  commandHistory: string[];
  commandFeedback: string;
  commandStep: number;
  commandBasePoint: Point2D | null;

  // Actions
  setEntities: React.Dispatch<React.SetStateAction<CADEntity[]>>;
  addEntity: (entity: CADEntity) => void;
  updateEntity: (id: string, updates: Partial<CADEntity>) => void;
  deleteEntities: (ids: string[]) => void;
  undo: () => void;
  redo: () => void;
  canUndo: boolean;
  canRedo: boolean;

  setActiveTool: (tool: CADTool) => void;
  setSelectedIds: (ids: string[]) => void;
  toggleSelectEntity: (id: string, multi?: boolean) => void;
  clearSelection: () => void;

  setViewMode: (mode: ViewMode) => void;
  setCursorPos: (pos: Point2D) => void;
  setActiveSnap: (snap: SnapPoint | null) => void;

  // Layers
  setActiveLayerId: (id: string) => void;
  createLayer: (name: string, color?: string) => void;
  deleteLayer: (id: string) => void;
  toggleLayerVisibility: (id: string) => void;
  toggleLayerLock: (id: string) => void;
  updateLayer: (id: string, updates: Partial<Layer>) => void;

  // Mode toggles
  setSnapSettings: React.Dispatch<React.SetStateAction<SnapSettings>>;
  setGridSettings: React.Dispatch<React.SetStateAction<{ enabled: boolean; snapToGrid: boolean; size: number; majorEvery: number }>>;
  toggleOrtho: () => void;
  togglePolar: () => void;
  toggleGrid: () => void;
  toggleOsnap: () => void;
  setUnits: (units: 'mm' | 'm' | 'cm' | 'inch' | 'ft') => void;

  // 3D Solids
  addSolid3D: (solid: Solid3DEntity) => void;
  updateSolid3D: (id: string, updates: Partial<Solid3DEntity>) => void;
  deleteSolid3D: (id: string) => void;
  extrudeSelectedTo3D: (height?: number) => void;

  // Projects & Files
  loadSampleProject: (projectId: string) => void;
  newDrawing: () => void;
  saveProjectToJSON: () => void;
  openProjectFromJSON: (jsonString: string) => void;
  exportProjectDXF: () => void;
  exportProjectSVG: () => void;

  // Command Line
  executeCommand: (cmdInput: string) => void;
  setCommandPrompt: (prompt: string) => void;
  setCommandFeedback: (feedback: string) => void;
  cancelCurrentCommand: () => void;
  
  // UI Dialog toggles
  isLayerModalOpen: boolean;
  setIsLayerModalOpen: (open: boolean) => void;
  isBlocksModalOpen: boolean;
  setIsBlocksModalOpen: (open: boolean) => void;
  isMeasureModalOpen: boolean;
  setIsMeasureModalOpen: (open: boolean) => void;
}

const CADContext = createContext<CADContextType | null>(null);

const DEFAULT_LAYERS: Layer[] = [
  { id: '0', name: '0', color: '#ffffff', visible: true, locked: false, lineType: 'CONTINUOUS', lineWeight: 0.25 },
  { id: 'WALLS', name: 'WALLS', color: '#00ffff', visible: true, locked: false, lineType: 'CONTINUOUS', lineWeight: 0.5 },
  { id: 'DOORS', name: 'DOORS', color: '#00ff66', visible: true, locked: false, lineType: 'CONTINUOUS', lineWeight: 0.25 },
  { id: 'WINDOWS', name: 'WINDOWS', color: '#ffff00', visible: true, locked: false, lineType: 'CONTINUOUS', lineWeight: 0.25 },
  { id: 'DIMS', name: 'DIMENSIONS', color: '#f97316', visible: true, locked: false, lineType: 'CONTINUOUS', lineWeight: 0.18 },
  { id: 'TEXT', name: 'TEXT', color: '#e2e8f0', visible: true, locked: false, lineType: 'CONTINUOUS', lineWeight: 0.25 },
];

export const CADProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Initialize with the architectural floor plan sample so user immediately sees real CAD data!
  const defaultSample = sampleProjects[0];

  const [entities, setEntities] = useState<CADEntity[]>(defaultSample.entities);
  const [layers, setLayers] = useState<Layer[]>(defaultSample.layers);
  const [activeLayerId, setActiveLayerId] = useState<string>('WALLS');
  const [activeTool, setActiveTool] = useState<CADTool>('select');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [viewMode, setViewMode] = useState<ViewMode>('2D');
  const [solids3d, setSolids3d] = useState<Solid3DEntity[]>(sampleProjects[1].solids3d || []);

  const [cursorPos, setCursorPos] = useState<Point2D>({ x: 0, y: 0 });
  const [activeSnap, setActiveSnap] = useState<SnapPoint | null>(null);

  const [snapSettings, setSnapSettings] = useState<SnapSettings>(defaultSnapSettings);
  const [gridSettings, setGridSettings] = useState({
    enabled: true,
    snapToGrid: false,
    size: 20,
    majorEvery: 5,
  });

  const [orthoMode, setOrthoMode] = useState(false);
  const [polarTracking, setPolarTracking] = useState(true);
  const [polarAngleStep] = useState(45);
  const [dynamicInput] = useState(true);
  const [units, setUnits] = useState<'mm' | 'm' | 'cm' | 'inch' | 'ft'>('mm');

  // Command-line state
  const [commandPrompt, setCommandPrompt] = useState<string>('Type a command');
  const [commandHistory, setCommandHistory] = useState<string[]>([]);
  const [commandFeedback, setCommandFeedback] = useState<string>('ProCAD v1.0.0 Ready. Type a command or press F1 for help.');
  const [commandStep, setCommandStep] = useState<number>(0);
  const [commandBasePoint, setCommandBasePoint] = useState<Point2D | null>(null);

  // Undo / Redo stacks
  const [undoStack, setUndoStack] = useState<CADEntity[][]>([]);
  const [redoStack, setRedoStack] = useState<CADEntity[][]>([]);

  // Modals
  const [isLayerModalOpen, setIsLayerModalOpen] = useState(false);
  const [isBlocksModalOpen, setIsBlocksModalOpen] = useState(false);
  const [isMeasureModalOpen, setIsMeasureModalOpen] = useState(false);

  // Autosave to localStorage
  useEffect(() => {
    const timer = setInterval(() => {
      try {
        const payload = dxfService.exportJSON(entities, layers, solids3d);
        localStorage.setItem('procad_autosave', payload);
      } catch (e) {
        // ignore
      }
    }, 30000);
    return () => clearInterval(timer);
  }, [entities, layers, solids3d]);

  // Push state to undo stack
  const pushHistory = useCallback((currentEntities: CADEntity[]) => {
    setUndoStack((prev) => [...prev.slice(-30), currentEntities]);
    setRedoStack([]);
  }, []);

  const addEntity = useCallback((entity: CADEntity) => {
    setEntities((prev) => {
      pushHistory(prev);
      return [...prev, entity];
    });
  }, [pushHistory]);

  const updateEntity = useCallback((id: string, updates: Partial<CADEntity>) => {
    setEntities((prev) => {
      pushHistory(prev);
      return prev.map((e) => (e.id === id ? ({ ...e, ...updates } as CADEntity) : e));
    });
  }, [pushHistory]);

  const deleteEntities = useCallback((ids: string[]) => {
    if (!ids.length) return;
    setEntities((prev) => {
      pushHistory(prev);
      return prev.filter((e) => !ids.includes(e.id));
    });
    setSelectedIds((prev) => prev.filter((id) => !ids.includes(id)));
    setCommandFeedback(`Erased ${ids.length} object(s).`);
  }, [pushHistory]);

  const undo = useCallback(() => {
    if (!undoStack.length) return;
    const previous = undoStack[undoStack.length - 1];
    setUndoStack((prev) => prev.slice(0, prev.length - 1));
    setRedoStack((prev) => [...prev, entities]);
    setEntities(previous);
    setCommandFeedback('UNDO executed.');
  }, [undoStack, entities]);

  const redo = useCallback(() => {
    if (!redoStack.length) return;
    const next = redoStack[redoStack.length - 1];
    setRedoStack((prev) => prev.slice(0, prev.length - 1));
    setUndoStack((prev) => [...prev, entities]);
    setEntities(next);
    setCommandFeedback('REDO executed.');
  }, [redoStack, entities]);

  const toggleSelectEntity = useCallback((id: string, multi = false) => {
    if (multi) {
      setSelectedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
    } else {
      setSelectedIds([id]);
    }
  }, []);

  const clearSelection = useCallback(() => {
    setSelectedIds([]);
  }, []);

  // Layer methods
  const createLayer = useCallback((name: string, color = '#00ffff') => {
    const id = name.toUpperCase().replace(/\s+/g, '_');
    const newLayer: Layer = {
      id,
      name,
      color,
      visible: true,
      locked: false,
      lineType: 'CONTINUOUS',
      lineWeight: 0.25,
    };
    setLayers((prev) => [...prev, newLayer]);
    setActiveLayerId(id);
    setCommandFeedback(`Layer "${name}" created.`);
  }, []);

  const deleteLayer = useCallback((id: string) => {
    if (id === '0') {
      setCommandFeedback('Cannot delete layer 0.');
      return;
    }
    setLayers((prev) => prev.filter((l) => l.id !== id));
    if (activeLayerId === id) {
      setActiveLayerId('0');
    }
    setCommandFeedback(`Layer "${id}" deleted.`);
  }, [activeLayerId]);

  const toggleLayerVisibility = useCallback((id: string) => {
    setLayers((prev) =>
      prev.map((l) => (l.id === id ? { ...l, visible: !l.visible } : l))
    );
  }, []);

  const toggleLayerLock = useCallback((id: string) => {
    setLayers((prev) =>
      prev.map((l) => (l.id === id ? { ...l, locked: !l.locked } : l))
    );
  }, []);

  const updateLayer = useCallback((id: string, updates: Partial<Layer>) => {
    setLayers((prev) =>
      prev.map((l) => (l.id === id ? { ...l, ...updates } : l))
    );
  }, []);

  // Mode toggles
  const toggleOrtho = useCallback(() => {
    setOrthoMode((v) => {
      const next = !v;
      setCommandFeedback(`ORTHOMODE <${next ? 'ON' : 'OFF'}>`);
      return next;
    });
  }, []);

  const togglePolar = useCallback(() => {
    setPolarTracking((v) => {
      const next = !v;
      setCommandFeedback(`POLAR TRACKING <${next ? 'ON' : 'OFF'}>`);
      return next;
    });
  }, []);

  const toggleGrid = useCallback(() => {
    setGridSettings((v) => ({ ...v, enabled: !v.enabled }));
  }, []);

  const toggleOsnap = useCallback(() => {
    setSnapSettings((v) => ({ ...v, enabled: !v.enabled }));
  }, []);

  // 3D Solid management
  const addSolid3D = useCallback((solid: Solid3DEntity) => {
    setSolids3d((prev) => [...prev, solid]);
    setCommandFeedback(`Created 3D solid: ${solid.name}`);
  }, []);

  const updateSolid3D = useCallback((id: string, updates: Partial<Solid3DEntity>) => {
    setSolids3d((prev) => prev.map((s) => (s.id === id ? { ...s, ...updates } : s)));
  }, []);

  const deleteSolid3D = useCallback((id: string) => {
    setSolids3d((prev) => prev.filter((s) => s.id !== id));
  }, []);

  // Extrude selected 2D profiles into 3D solid
  const extrudeSelectedTo3D = useCallback((height = 50) => {
    if (!selectedIds.length) {
      setCommandFeedback('Extrude: Please select one or more 2D entities first.');
      return;
    }

    const selectedEntities = entities.filter((e) => selectedIds.includes(e.id));
    let count = 0;

    selectedEntities.forEach((ent) => {
      if (ent.type === 'CIRCLE') {
        const solid: Solid3DEntity = {
          id: `extrude_cyl_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
          name: `Extrusion of Circle (${ent.radius}r)`,
          shape: 'CYLINDER',
          position: { x: ent.center.x, y: ent.center.y, z: height / 2 },
          rotation: { x: Math.PI / 2, y: 0, z: 0 },
          scale: { x: 1, y: 1, z: 1 },
          parameters: {
            radiusTop: ent.radius,
            radiusBottom: ent.radius,
            height,
            segments: 36,
          },
          color: ent.color || '#38bdf8',
        };
        addSolid3D(solid);
        count++;
      } else if (ent.type === 'RECTANGLE') {
        const w = Math.abs(ent.p2.x - ent.p1.x);
        const d = Math.abs(ent.p2.y - ent.p1.y);
        const cx = (ent.p1.x + ent.p2.x) / 2;
        const cy = (ent.p1.y + ent.p2.y) / 2;
        const solid: Solid3DEntity = {
          id: `extrude_box_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
          name: `Extrusion of Rect (${w.toFixed(0)}x${d.toFixed(0)})`,
          shape: 'BOX',
          position: { x: cx, y: cy, z: height / 2 },
          rotation: { x: 0, y: 0, z: 0 },
          scale: { x: 1, y: 1, z: 1 },
          parameters: {
            width: w,
            depth: d,
            height,
          },
          color: ent.color || '#0ea5e9',
        };
        addSolid3D(solid);
        count++;
      }
    });

    if (count > 0) {
      setViewMode('3D');
      setCommandFeedback(`Extruded ${count} profile(s) to 3D with height ${height}mm.`);
    } else {
      setCommandFeedback('Extrude: Select a Circle or Rectangle to extrude.');
    }
  }, [selectedIds, entities, addSolid3D]);

  // Project loading & templates
  const loadSampleProject = useCallback((projectId: string) => {
    const proj = sampleProjects.find((p) => p.id === projectId);
    if (!proj) return;
    pushHistory(entities);
    setEntities(proj.entities);
    setLayers(proj.layers);
    if (proj.solids3d) {
      setSolids3d(proj.solids3d);
    }
    setActiveLayerId(proj.layers[1]?.id || '0');
    setSelectedIds([]);
    setCommandFeedback(`Loaded sample project: ${proj.name}`);
  }, [entities, pushHistory]);

  const newDrawing = useCallback(() => {
    pushHistory(entities);
    setEntities([]);
    setLayers(DEFAULT_LAYERS);
    setActiveLayerId('0');
    setSelectedIds([]);
    setSolids3d([]);
    setCommandFeedback('New drawing initialized.');
  }, [entities, pushHistory]);

  const saveProjectToJSON = useCallback(() => {
    const jsonStr = dxfService.exportJSON(entities, layers, solids3d);
    dxfService.downloadFile('drawing.procad.json', jsonStr, 'application/json');
    setCommandFeedback('Project successfully saved as JSON.');
  }, [entities, layers, solids3d]);

  const openProjectFromJSON = useCallback((jsonString: string) => {
    try {
      const parsed = dxfService.parseJSON(jsonString);
      pushHistory(entities);
      setEntities(parsed.entities);
      if (parsed.layers?.length) setLayers(parsed.layers);
      if (parsed.solids3d?.length) setSolids3d(parsed.solids3d);
      setCommandFeedback(`Project loaded with ${parsed.entities.length} entities.`);
    } catch (err: any) {
      setCommandFeedback(`Failed to open project: ${err.message}`);
    }
  }, [entities, pushHistory]);

  const exportProjectDXF = useCallback(() => {
    const dxfStr = dxfService.exportDXF(entities, layers);
    dxfService.downloadFile('drawing.dxf', dxfStr, 'application/dxf');
    setCommandFeedback('Drawing exported to standard AutoCAD DXF.');
  }, [entities, layers]);

  const exportProjectSVG = useCallback(() => {
    const svgStr = dxfService.exportSVG(entities, layers);
    dxfService.downloadFile('drawing.svg', svgStr, 'image/svg+xml');
    setCommandFeedback('Drawing exported to scalable vector SVG.');
  }, [entities, layers]);

  const cancelCurrentCommand = useCallback(() => {
    setActiveTool('select');
    setCommandPrompt('Type a command');
    setCommandFeedback('*Cancel*');
    setCommandStep(0);
    setCommandBasePoint(null);
    clearSelection();
  }, [clearSelection]);

  // AutoCAD command processor
  const executeCommand = useCallback((cmdInput: string) => {
    const raw = cmdInput.trim();
    if (!raw) return;

    setCommandHistory((prev) => [...prev, raw]);
    const upper = raw.toUpperCase();

    // Check if user is typing numeric coordinates while drawing
    if (activeTool !== 'select' && activeTool !== 'pan') {
      const parsedCoord = cadMath.parseCoordinate(raw, commandBasePoint || undefined);
      if (parsedCoord) {
        // Feed coordinate into drawing tool action
        window.dispatchEvent(new CustomEvent('cad-coordinate-input', { detail: parsedCoord }));
        setCommandFeedback(`Coordinate specified: (${parsedCoord.x.toFixed(2)}, ${parsedCoord.y.toFixed(2)})`);
        return;
      }
    }

    // Command dispatch
    switch (upper) {
      case 'L':
      case 'LINE':
        setActiveTool('line');
        setCommandPrompt('LINE Specify first point:');
        setCommandFeedback('Command: LINE');
        break;

      case 'PL':
      case 'PLINE':
        setActiveTool('polyline');
        setCommandPrompt('PLINE Specify start point:');
        setCommandFeedback('Command: PLINE');
        break;

      case 'C':
      case 'CIRCLE':
        setActiveTool('circle');
        setCommandPrompt('CIRCLE Specify center point:');
        setCommandFeedback('Command: CIRCLE');
        break;

      case 'REC':
      case 'RECTANG':
      case 'RECTANGLE':
        setActiveTool('rectangle');
        setCommandPrompt('RECTANG Specify first corner:');
        setCommandFeedback('Command: RECTANG');
        break;

      case 'A':
      case 'ARC':
        setActiveTool('arc');
        setCommandPrompt('ARC Specify start point:');
        setCommandFeedback('Command: ARC');
        break;

      case 'POL':
      case 'POLYGON':
        setActiveTool('polygon');
        setCommandPrompt('POLYGON Specify center:');
        setCommandFeedback('Command: POLYGON');
        break;

      case 'EL':
      case 'ELLIPSE':
        setActiveTool('ellipse');
        setCommandPrompt('ELLIPSE Specify center:');
        setCommandFeedback('Command: ELLIPSE');
        break;

      case 'SPL':
      case 'SPLINE':
        setActiveTool('spline');
        setCommandPrompt('SPLINE Specify points:');
        setCommandFeedback('Command: SPLINE');
        break;

      case 'PO':
      case 'POINT':
        setActiveTool('point');
        setCommandPrompt('POINT Specify a point:');
        setCommandFeedback('Command: POINT');
        break;

      case 'XL':
      case 'XLINE':
        setActiveTool('xline');
        setCommandPrompt('XLINE Specify root point:');
        setCommandFeedback('Command: XLINE');
        break;

      case 'RAY':
        setActiveTool('ray');
        setCommandPrompt('RAY Specify base point:');
        setCommandFeedback('Command: RAY');
        break;

      case 'T':
      case 'TEXT':
      case 'MTEXT':
        setActiveTool('text');
        setCommandPrompt('TEXT Specify insertion point:');
        setCommandFeedback('Command: TEXT');
        break;

      case 'DIM':
      case 'DIMLIN':
      case 'DLI':
        setActiveTool('dimension_linear');
        setCommandPrompt('DIMLIN Specify first extension line origin:');
        setCommandFeedback('Command: DIMLINEAR');
        break;

      case 'DAL':
      case 'DIMALIGNED':
        setActiveTool('dimension_aligned');
        setCommandPrompt('DIMALIGNED Specify first point:');
        setCommandFeedback('Command: DIMALIGNED');
        break;

      case 'DRA':
      case 'DIMRADIUS':
        setActiveTool('dimension_radius');
        setCommandPrompt('DIMRADIUS Select arc or circle:');
        setCommandFeedback('Command: DIMRADIUS');
        break;

      case 'H':
      case 'HATCH':
        setActiveTool('hatch');
        setCommandPrompt('HATCH Pick internal point or boundary:');
        setCommandFeedback('Command: HATCH');
        break;

      case 'M':
      case 'MOVE':
        if (!selectedIds.length) {
          setCommandFeedback('MOVE: Select objects first, or pick them now.');
        }
        setActiveTool('move');
        setCommandPrompt('MOVE Specify base point:');
        break;

      case 'CO':
      case 'CP':
      case 'COPY':
        setActiveTool('copy');
        setCommandPrompt('COPY Specify base point:');
        break;

      case 'RO':
      case 'ROTATE':
        setActiveTool('rotate');
        setCommandPrompt('ROTATE Specify base point:');
        break;

      case 'MI':
      case 'MIRROR':
        setActiveTool('mirror');
        setCommandPrompt('MIRROR Specify first point of mirror line:');
        break;

      case 'SC':
      case 'SCALE':
        setActiveTool('scale');
        setCommandPrompt('SCALE Specify base point:');
        break;

      case 'O':
      case 'OFFSET':
        setActiveTool('offset');
        setCommandPrompt('OFFSET Specify offset distance:');
        break;

      case 'TR':
      case 'TRIM':
        setActiveTool('trim');
        setCommandPrompt('TRIM Select object to trim:');
        break;

      case 'EX':
      case 'EXTEND':
        setActiveTool('extend');
        setCommandPrompt('EXTEND Select object to extend:');
        break;

      case 'F':
      case 'FILLET':
        setActiveTool('fillet');
        setCommandPrompt('FILLET Select first object:');
        break;

      case 'CHA':
      case 'CHAMFER':
        setActiveTool('chamfer');
        setCommandPrompt('CHAMFER Select first line:');
        break;

      case 'E':
      case 'DEL':
      case 'ERASE':
        if (selectedIds.length > 0) {
          deleteEntities(selectedIds);
        } else {
          setActiveTool('erase');
          setCommandPrompt('ERASE Select objects to delete:');
        }
        break;

      case 'X':
      case 'EXPLODE':
        setActiveTool('explode');
        setCommandFeedback('Select compound object to explode.');
        break;

      case 'U':
      case 'UNDO':
        undo();
        break;

      case 'REDO':
        redo();
        break;

      case 'Z':
      case 'ZOOM':
        window.dispatchEvent(new CustomEvent('cad-zoom-extents'));
        setCommandFeedback('ZOOM Extents executed.');
        break;

      case 'P':
      case 'PAN':
        setActiveTool('pan');
        setCommandPrompt('Press and drag to PAN. ESC to exit.');
        break;

      case 'LA':
      case 'LAYER':
        setIsLayerModalOpen(true);
        setCommandFeedback('Opened Layer Properties Manager.');
        break;

      case 'DI':
      case 'DIST':
        setActiveTool('dist');
        setCommandPrompt('DIST Specify first point:');
        break;

      case 'AA':
      case 'AREA':
        setActiveTool('area');
        setCommandPrompt('AREA Specify first corner point:');
        break;

      case 'EXT':
      case 'EXTRUDE':
        extrudeSelectedTo3D(50);
        break;

      case 'SAVE':
      case 'QSAVE':
        saveProjectToJSON();
        break;

      case 'EXPORT':
      case 'DXFOUT':
        exportProjectDXF();
        break;

      case 'UNITS':
        setCommandFeedback(`Current insertion units: ${units}`);
        break;

      case 'CLEAR':
      case 'NEW':
        newDrawing();
        break;

      default:
        setCommandFeedback(`Unknown command "${raw}". Type LINE, CIRCLE, RECTANG, DIST, etc.`);
        break;
    }
  }, [
    activeTool,
    commandBasePoint,
    selectedIds,
    deleteEntities,
    undo,
    redo,
    extrudeSelectedTo3D,
    saveProjectToJSON,
    exportProjectDXF,
    units,
    newDrawing,
  ]);

  return (
    <CADContext.Provider
      value={{
        entities,
        layers,
        activeLayerId,
        activeTool,
        selectedIds,
        viewMode,
        solids3d,
        cursorPos,
        snapSettings,
        activeSnap,
        gridSettings,
        orthoMode,
        polarTracking,
        polarAngleStep,
        dynamicInput,
        units,
        commandPrompt,
        commandHistory,
        commandFeedback,
        commandStep,
        commandBasePoint,

        setEntities,
        addEntity,
        updateEntity,
        deleteEntities,
        undo,
        redo,
        canUndo: undoStack.length > 0,
        canRedo: redoStack.length > 0,

        setActiveTool,
        setSelectedIds,
        toggleSelectEntity,
        clearSelection,

        setViewMode,
        setCursorPos,
        setActiveSnap,

        setActiveLayerId,
        createLayer,
        deleteLayer,
        toggleLayerVisibility,
        toggleLayerLock,
        updateLayer,

        setSnapSettings,
        setGridSettings,
        toggleOrtho,
        togglePolar,
        toggleGrid,
        toggleOsnap,
        setUnits,

        addSolid3D,
        updateSolid3D,
        deleteSolid3D,
        extrudeSelectedTo3D,

        loadSampleProject,
        newDrawing,
        saveProjectToJSON,
        openProjectFromJSON,
        exportProjectDXF,
        exportProjectSVG,

        executeCommand,
        setCommandPrompt,
        setCommandFeedback,
        cancelCurrentCommand,

        isLayerModalOpen,
        setIsLayerModalOpen,
        isBlocksModalOpen,
        setIsBlocksModalOpen,
        isMeasureModalOpen,
        setIsMeasureModalOpen,
      }}
    >
      {children}
    </CADContext.Provider>
  );
};

export const useCAD = () => {
  const context = useContext(CADContext);
  if (!context) throw new Error('useCAD must be used within a CADProvider');
  return context;
};
