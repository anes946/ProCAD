/**
 * ProCAD - Properties Inspector Panel
 * Live real-time inspection and geometric editing of selected CAD entities.
 */

import React, { useState } from 'react';
import { useCAD } from '../context/CADContext';
import { CADEntity, LineType } from '../types/cad';
import { cadMath } from '../geometry/cadMath';

export const PropertiesPanel: React.FC = () => {
  const {
    entities,
    layers,
    selectedIds,
    updateEntity,
    deleteEntities,
    units,
    activeLayerId,
  } = useCAD();

  const [collapsed, setCollapsed] = useState(false);

  // If collapsed, render slim handle
  if (collapsed) {
    return (
      <div className="w-7 bg-zinc-900 border-l border-zinc-800 flex flex-col items-center py-3 select-none">
        <button
          onClick={() => setCollapsed(false)}
          title="Expand Properties Inspector"
          className="text-zinc-400 hover:text-white p-1 rounded hover:bg-zinc-800 transition"
        >
          ◀
        </button>
        <span className="text-[10px] uppercase font-bold text-zinc-500 tracking-widest mt-6 [writing-mode:vertical-lr]">
          Properties
        </span>
      </div>
    );
  }

  const selectedEntities = entities.filter((e) => selectedIds.includes(e.id));
  const singleEntity = selectedEntities.length === 1 ? selectedEntities[0] : null;

  return (
    <div className="w-72 bg-zinc-900 border-l border-zinc-800 flex flex-col text-xs text-zinc-200 select-none overflow-y-auto">
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2 bg-zinc-950 border-b border-zinc-800">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-zinc-100">PROPERTIES</span>
          <span className="text-[10px] text-zinc-400 font-mono">
            {selectedEntities.length > 0 ? `(${selectedEntities.length} selected)` : '(No Selection)'}
          </span>
        </div>
        <button
          onClick={() => setCollapsed(true)}
          title="Collapse Panel"
          className="text-zinc-400 hover:text-white p-0.5 rounded hover:bg-zinc-800 transition"
        >
          ▶
        </button>
      </div>

      <div className="p-3 flex flex-col gap-4">
        {/* NO SELECTION: Drawing Summary */}
        {selectedEntities.length === 0 && (
          <div className="flex flex-col gap-2.5">
            <div className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">
              Drawing Overview
            </div>
            <div className="bg-zinc-950/70 p-2.5 rounded border border-zinc-800 flex flex-col gap-1.5 font-mono text-[11px]">
              <div className="flex justify-between">
                <span className="text-zinc-500">Total Entities:</span>
                <span className="text-white font-semibold">{entities.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-500">Total Layers:</span>
                <span className="text-white font-semibold">{layers.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-500">Active Layer:</span>
                <span className="text-sky-400 font-semibold">{activeLayerId}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-500">System Units:</span>
                <span className="text-emerald-400 font-semibold">{units}</span>
              </div>
            </div>
            <div className="text-zinc-500 text-[11px] leading-relaxed italic">
              Select an entity on the canvas or via window selection to inspect and modify its geometric coordinates, layer, and parameters.
            </div>
          </div>
        )}

        {/* MULTIPLE SELECTION BATCH EDIT */}
        {selectedEntities.length > 1 && (
          <div className="flex flex-col gap-3">
            <div className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">
              Batch Properties
            </div>
            <div className="flex flex-col gap-2 bg-zinc-950/70 p-2.5 rounded border border-zinc-800">
              <div>
                <label className="text-zinc-400 text-[10px] block mb-1">Set Layer for All:</label>
                <select
                  onChange={(e) => {
                    const lId = e.target.value;
                    selectedIds.forEach((id) => updateEntity(id, { layer: lId }));
                  }}
                  className="w-full bg-zinc-800 border border-zinc-700 text-zinc-200 rounded px-2 py-1 text-xs"
                >
                  <option value="">-- Change Layer --</option>
                  {layers.map((l) => (
                    <option key={l.id} value={l.id}>
                      {l.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-zinc-400 text-[10px] block mb-1">Set Color for All:</label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    onChange={(e) => {
                      const col = e.target.value;
                      selectedIds.forEach((id) => updateEntity(id, { color: col }));
                    }}
                    className="w-10 h-7 bg-transparent cursor-pointer rounded"
                  />
                  <button
                    onClick={() => {
                      selectedIds.forEach((id) => updateEntity(id, { color: undefined }));
                    }}
                    className="px-2 py-1 bg-zinc-800 hover:bg-zinc-700 text-[10px] text-zinc-300 rounded"
                  >
                    Reset to ByLayer
                  </button>
                </div>
              </div>

              <button
                onClick={() => deleteEntities(selectedIds)}
                className="mt-2 w-full py-1.5 bg-red-950 hover:bg-red-800 text-red-200 font-semibold rounded transition"
              >
                Delete Selected ({selectedEntities.length})
              </button>
            </div>
          </div>
        )}

        {/* SINGLE ENTITY PROPERTIES INSPECTOR */}
        {singleEntity && (
          <div className="flex flex-col gap-3">
            {/* General Section */}
            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-sky-400 uppercase tracking-wider">
                  {singleEntity.type}
                </span>
                <button
                  onClick={() => deleteEntities([singleEntity.id])}
                  title="Delete Entity"
                  className="text-red-400 hover:text-red-300 text-xs"
                >
                  Delete
                </button>
              </div>

              <div className="bg-zinc-950/70 p-2.5 rounded border border-zinc-800 flex flex-col gap-2 font-mono">
                {/* Layer Selector */}
                <div>
                  <span className="text-zinc-500 text-[10px] font-sans block mb-0.5">LAYER</span>
                  <select
                    value={singleEntity.layer}
                    onChange={(e) => updateEntity(singleEntity.id, { layer: e.target.value })}
                    className="w-full bg-zinc-800 border border-zinc-700 text-zinc-200 rounded px-2 py-1 text-xs"
                  >
                    {layers.map((l) => (
                      <option key={l.id} value={l.id}>
                        {l.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Color */}
                <div>
                  <span className="text-zinc-500 text-[10px] font-sans block mb-0.5">COLOR</span>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={singleEntity.color || layers.find((l) => l.id === singleEntity.layer)?.color || '#ffffff'}
                      onChange={(e) => updateEntity(singleEntity.id, { color: e.target.value })}
                      className="w-8 h-6 bg-transparent cursor-pointer rounded"
                    />
                    <button
                      onClick={() => updateEntity(singleEntity.id, { color: undefined })}
                      className="px-2 py-0.5 bg-zinc-800 hover:bg-zinc-700 text-[10px] text-zinc-400 rounded font-sans"
                    >
                      ByLayer
                    </button>
                  </div>
                </div>

                {/* Line Type */}
                <div>
                  <span className="text-zinc-500 text-[10px] font-sans block mb-0.5">LINETYPE</span>
                  <select
                    value={singleEntity.lineType || 'CONTINUOUS'}
                    onChange={(e) => updateEntity(singleEntity.id, { lineType: e.target.value as LineType })}
                    className="w-full bg-zinc-800 border border-zinc-700 text-zinc-200 rounded px-2 py-1 text-xs"
                  >
                    <option value="CONTINUOUS">Continuous</option>
                    <option value="DASHED">Dashed</option>
                    <option value="DOTTED">Dotted</option>
                    <option value="CENTER">Center</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Geometry Specific Section */}
            <div className="flex flex-col gap-2">
              <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">
                Geometry Parameters
              </span>

              <div className="bg-zinc-950/70 p-2.5 rounded border border-zinc-800 flex flex-col gap-2 font-mono text-[11px]">
                {/* LINE SPECIFIC */}
                {singleEntity.type === 'LINE' && (
                  <>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <span className="text-zinc-500 block text-[10px]">Start X:</span>
                        <input
                          type="number"
                          value={singleEntity.p1.x}
                          onChange={(e) =>
                            updateEntity(singleEntity.id, {
                              p1: { ...singleEntity.p1, x: parseFloat(e.target.value) || 0 },
                            })
                          }
                          className="w-full bg-zinc-800 border border-zinc-700 rounded px-1.5 py-0.5 text-xs text-white"
                        />
                      </div>
                      <div>
                        <span className="text-zinc-500 block text-[10px]">Start Y:</span>
                        <input
                          type="number"
                          value={singleEntity.p1.y}
                          onChange={(e) =>
                            updateEntity(singleEntity.id, {
                              p1: { ...singleEntity.p1, y: parseFloat(e.target.value) || 0 },
                            })
                          }
                          className="w-full bg-zinc-800 border border-zinc-700 rounded px-1.5 py-0.5 text-xs text-white"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <span className="text-zinc-500 block text-[10px]">End X:</span>
                        <input
                          type="number"
                          value={singleEntity.p2.x}
                          onChange={(e) =>
                            updateEntity(singleEntity.id, {
                              p2: { ...singleEntity.p2, x: parseFloat(e.target.value) || 0 },
                            })
                          }
                          className="w-full bg-zinc-800 border border-zinc-700 rounded px-1.5 py-0.5 text-xs text-white"
                        />
                      </div>
                      <div>
                        <span className="text-zinc-500 block text-[10px]">End Y:</span>
                        <input
                          type="number"
                          value={singleEntity.p2.y}
                          onChange={(e) =>
                            updateEntity(singleEntity.id, {
                              p2: { ...singleEntity.p2, y: parseFloat(e.target.value) || 0 },
                            })
                          }
                          className="w-full bg-zinc-800 border border-zinc-700 rounded px-1.5 py-0.5 text-xs text-white"
                        />
                      </div>
                    </div>

                    <div className="flex justify-between border-t border-zinc-800 pt-1 mt-1 text-zinc-400">
                      <span>Length:</span>
                      <span className="text-white font-semibold">
                        {cadMath.dist(singleEntity.p1, singleEntity.p2).toFixed(2)} {units}
                      </span>
                    </div>
                    <div className="flex justify-between text-zinc-400">
                      <span>Angle:</span>
                      <span className="text-white font-semibold">
                        {cadMath.angleDeg(singleEntity.p1, singleEntity.p2).toFixed(1)}°
                      </span>
                    </div>
                  </>
                )}

                {/* CIRCLE SPECIFIC */}
                {singleEntity.type === 'CIRCLE' && (
                  <>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <span className="text-zinc-500 block text-[10px]">Center X:</span>
                        <input
                          type="number"
                          value={singleEntity.center.x}
                          onChange={(e) =>
                            updateEntity(singleEntity.id, {
                              center: { ...singleEntity.center, x: parseFloat(e.target.value) || 0 },
                            })
                          }
                          className="w-full bg-zinc-800 border border-zinc-700 rounded px-1.5 py-0.5 text-xs text-white"
                        />
                      </div>
                      <div>
                        <span className="text-zinc-500 block text-[10px]">Center Y:</span>
                        <input
                          type="number"
                          value={singleEntity.center.y}
                          onChange={(e) =>
                            updateEntity(singleEntity.id, {
                              center: { ...singleEntity.center, y: parseFloat(e.target.value) || 0 },
                            })
                          }
                          className="w-full bg-zinc-800 border border-zinc-700 rounded px-1.5 py-0.5 text-xs text-white"
                        />
                      </div>
                    </div>

                    <div>
                      <span className="text-zinc-500 block text-[10px]">Radius:</span>
                      <input
                        type="number"
                        value={singleEntity.radius}
                        onChange={(e) =>
                          updateEntity(singleEntity.id, {
                            radius: Math.max(1, parseFloat(e.target.value) || 1),
                          })
                        }
                        className="w-full bg-zinc-800 border border-zinc-700 rounded px-1.5 py-0.5 text-xs text-white"
                      />
                    </div>

                    <div className="flex justify-between border-t border-zinc-800 pt-1 mt-1 text-zinc-400">
                      <span>Diameter:</span>
                      <span className="text-white font-semibold">
                        {(singleEntity.radius * 2).toFixed(2)} {units}
                      </span>
                    </div>
                    <div className="flex justify-between text-zinc-400">
                      <span>Area:</span>
                      <span className="text-white font-semibold">
                        {(Math.PI * singleEntity.radius * singleEntity.radius).toFixed(1)} {units}²
                      </span>
                    </div>
                  </>
                )}

                {/* RECTANGLE SPECIFIC */}
                {singleEntity.type === 'RECTANGLE' && (
                  <>
                    <div className="flex justify-between">
                      <span className="text-zinc-500">Width:</span>
                      <span className="text-white font-semibold">
                        {Math.abs(singleEntity.p2.x - singleEntity.p1.x).toFixed(2)} {units}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-zinc-500">Height:</span>
                      <span className="text-white font-semibold">
                        {Math.abs(singleEntity.p2.y - singleEntity.p1.y).toFixed(2)} {units}
                      </span>
                    </div>
                    <div className="flex justify-between border-t border-zinc-800 pt-1 text-zinc-400">
                      <span>Area:</span>
                      <span className="text-white font-semibold">
                        {(
                          Math.abs(singleEntity.p2.x - singleEntity.p1.x) *
                          Math.abs(singleEntity.p2.y - singleEntity.p1.y)
                        ).toFixed(1)}{' '}
                        {units}²
                      </span>
                    </div>
                  </>
                )}

                {/* TEXT SPECIFIC */}
                {singleEntity.type === 'TEXT' && (
                  <>
                    <div>
                      <span className="text-zinc-500 block text-[10px]">Text String:</span>
                      <input
                        type="text"
                        value={singleEntity.text}
                        onChange={(e) => updateEntity(singleEntity.id, { text: e.target.value })}
                        className="w-full bg-zinc-800 border border-zinc-700 rounded px-1.5 py-0.5 text-xs text-white"
                      />
                    </div>
                    <div>
                      <span className="text-zinc-500 block text-[10px]">Text Height:</span>
                      <input
                        type="number"
                        value={singleEntity.height}
                        onChange={(e) =>
                          updateEntity(singleEntity.id, {
                            height: Math.max(1, parseFloat(e.target.value) || 1),
                          })
                        }
                        className="w-full bg-zinc-800 border border-zinc-700 rounded px-1.5 py-0.5 text-xs text-white"
                      />
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
