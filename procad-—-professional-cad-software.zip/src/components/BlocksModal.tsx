/**
 * ProCAD - Block & Engineering Symbols Library Modal
 */

import React, { useState } from 'react';
import { useCAD } from '../context/CADContext';
import { cadBlocks } from '../services/blocks';
import { BlockDefinition, CADEntity } from '../types/cad';

export const BlocksModal: React.FC = () => {
  const {
    isBlocksModalOpen,
    setIsBlocksModalOpen,
    addEntity,
    activeLayerId,
    cursorPos,
    setCommandFeedback,
    setViewMode,
  } = useCAD();

  const [activeCategory, setActiveCategory] = useState<'All' | 'Architectural' | 'Mechanical' | 'Electrical'>('All');

  if (!isBlocksModalOpen) return null;

  const filteredBlocks = activeCategory === 'All'
    ? cadBlocks
    : cadBlocks.filter((b) => b.category === activeCategory);

  const handleInsertBlock = (block: BlockDefinition) => {
    const insertPos = cursorPos || { x: 200, y: 200 };

    // Instantiate each entity in block translated to insert position
    block.entities.forEach((ent) => {
      const cloned: CADEntity = {
        ...ent,
        id: `blk_${block.name.slice(0, 3).toLowerCase()}_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
        layer: activeLayerId,
      };

      if (cloned.type === 'LINE') {
        cloned.p1 = { x: cloned.p1.x + insertPos.x, y: cloned.p1.y + insertPos.y };
        cloned.p2 = { x: cloned.p2.x + insertPos.x, y: cloned.p2.y + insertPos.y };
      } else if (cloned.type === 'RECTANGLE') {
        cloned.p1 = { x: cloned.p1.x + insertPos.x, y: cloned.p1.y + insertPos.y };
        cloned.p2 = { x: cloned.p2.x + insertPos.x, y: cloned.p2.y + insertPos.y };
      } else if (cloned.type === 'CIRCLE' || cloned.type === 'ARC' || cloned.type === 'POLYGON') {
        cloned.center = { x: cloned.center.x + insertPos.x, y: cloned.center.y + insertPos.y };
      } else if (cloned.type === 'TEXT') {
        cloned.position = { x: cloned.position.x + insertPos.x, y: cloned.position.y + insertPos.y };
      }

      addEntity(cloned);
    });

    setViewMode('2D');
    setIsBlocksModalOpen(false);
    setCommandFeedback(`Inserted block "${block.name}" at (${insertPos.x.toFixed(1)}, ${insertPos.y.toFixed(1)}).`);
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 select-none">
      <div className="bg-zinc-900 border border-zinc-700 rounded-xl shadow-2xl w-full max-w-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-zinc-950 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <span className="text-lg">📦</span>
            <h2 className="text-sm font-bold text-zinc-100 tracking-wide">
              STANDARD CAD SYMBOLS & BLOCK LIBRARY
            </h2>
          </div>
          <button
            onClick={() => setIsBlocksModalOpen(false)}
            className="text-zinc-400 hover:text-white p-1 rounded hover:bg-zinc-800 transition"
          >
            ✕
          </button>
        </div>

        {/* Category Filter Tabs */}
        <div className="flex items-center gap-1.5 px-4 py-2 bg-zinc-950 border-b border-zinc-800 text-xs">
          {(['All', 'Architectural', 'Mechanical', 'Electrical'] as const).map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-1 rounded transition font-medium ${
                activeCategory === cat
                  ? 'bg-sky-600 text-white shadow-sm'
                  : 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Blocks Grid */}
        <div className="p-4 grid grid-cols-2 gap-3 overflow-y-auto flex-1">
          {filteredBlocks.map((blk) => (
            <div
              key={blk.name}
              className="bg-zinc-950/80 border border-zinc-800 hover:border-sky-500 rounded-lg p-3 flex flex-col justify-between transition group"
            >
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-xs text-white group-hover:text-sky-400 transition">
                    {blk.name}
                  </span>
                  <span className="text-[10px] text-zinc-500 font-mono bg-zinc-800 px-1.5 py-0.5 rounded">
                    {blk.category}
                  </span>
                </div>
                <p className="text-[11px] text-zinc-400 leading-relaxed mb-3">
                  {blk.description}
                </p>
              </div>

              <button
                onClick={() => handleInsertBlock(blk)}
                className="w-full py-1.5 bg-zinc-800 hover:bg-sky-600 text-zinc-200 hover:text-white text-xs font-semibold rounded transition"
              >
                + Insert Block into Drawing
              </button>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-4 py-2.5 bg-zinc-950 border-t border-zinc-800 text-xs text-zinc-400">
          <span>{filteredBlocks.length} block definitions available</span>
          <button
            onClick={() => setIsBlocksModalOpen(false)}
            className="px-4 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-white rounded transition text-xs font-semibold"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
