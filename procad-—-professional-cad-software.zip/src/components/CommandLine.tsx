/**
 * ProCAD - AutoCAD Command Line Console
 * Supports full command dispatch, coordinate entry, polar coordinates, history, and autocomplete.
 */

import React, { useState, useRef, useEffect } from 'react';
import { useCAD } from '../context/CADContext';

const AUTOCOMPLETE_COMMANDS = [
  { cmd: 'LINE', alias: 'L', desc: 'Create straight line segments' },
  { cmd: 'PLINE', alias: 'PL', desc: 'Create 2D polyline' },
  { cmd: 'CIRCLE', alias: 'C', desc: 'Create a circle' },
  { cmd: 'RECTANG', alias: 'REC', desc: 'Create a rectangle' },
  { cmd: 'ARC', alias: 'A', desc: 'Create an arc' },
  { cmd: 'POLYGON', alias: 'POL', desc: 'Create regular polygon' },
  { cmd: 'ELLIPSE', alias: 'EL', desc: 'Create an ellipse' },
  { cmd: 'SPLINE', alias: 'SPL', desc: 'Create a smooth spline curve' },
  { cmd: 'POINT', alias: 'PO', desc: 'Create a point object' },
  { cmd: 'XLINE', alias: 'XL', desc: 'Create infinite construction line' },
  { cmd: 'RAY', alias: 'RAY', desc: 'Create semi-infinite ray' },
  { cmd: 'TEXT', alias: 'T', desc: 'Create single or multiline text' },
  { cmd: 'HATCH', alias: 'H', desc: 'Fill enclosed area with hatch pattern' },
  { cmd: 'DIMLINEAR', alias: 'DLI', desc: 'Create linear dimension' },
  { cmd: 'DIMALIGNED', alias: 'DAL', desc: 'Create aligned dimension' },
  { cmd: 'DIMRADIUS', alias: 'DRA', desc: 'Create radius dimension' },
  { cmd: 'MOVE', alias: 'M', desc: 'Move objects' },
  { cmd: 'COPY', alias: 'CO', desc: 'Copy objects' },
  { cmd: 'ROTATE', alias: 'RO', desc: 'Rotate objects' },
  { cmd: 'MIRROR', alias: 'MI', desc: 'Mirror objects' },
  { cmd: 'SCALE', alias: 'SC', desc: 'Scale objects' },
  { cmd: 'OFFSET', alias: 'O', desc: 'Offset object by distance' },
  { cmd: 'TRIM', alias: 'TR', desc: 'Trim objects at cutting edges' },
  { cmd: 'EXTEND', alias: 'EX', desc: 'Extend objects to meet boundary' },
  { cmd: 'FILLET', alias: 'F', desc: 'Round or fillet corners' },
  { cmd: 'CHAMFER', alias: 'CHA', desc: 'Bevel edges of objects' },
  { cmd: 'ERASE', alias: 'E', desc: 'Remove objects from drawing' },
  { cmd: 'EXPLODE', alias: 'X', desc: 'Break compound object into elements' },
  { cmd: 'DIST', alias: 'DI', desc: 'Measure distance and angle' },
  { cmd: 'AREA', alias: 'AA', desc: 'Calculate area and perimeter' },
  { cmd: 'LAYER', alias: 'LA', desc: 'Manage layers and layer properties' },
  { cmd: 'ZOOM', alias: 'Z', desc: 'Zoom extents or window' },
  { cmd: 'PAN', alias: 'P', desc: 'Pan the drawing view' },
  { cmd: 'EXTRUDE', alias: 'EXT', desc: 'Extrude 2D profile into 3D solid' },
  { cmd: 'UNDO', alias: 'U', desc: 'Reverse the effect of commands' },
  { cmd: 'REDO', alias: 'REDO', desc: 'Reverse the effect of undo' },
  { cmd: 'SAVE', alias: 'QSAVE', desc: 'Save current drawing' },
  { cmd: 'EXPORT', alias: 'EXP', desc: 'Export DXF or SVG' },
];

export const CommandLine: React.FC = () => {
  const {
    commandPrompt,
    commandHistory,
    commandFeedback,
    executeCommand,
    cancelCurrentCommand,
  } = useCAD();

  const [inputVal, setInputVal] = useState('');
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const inputRef = useRef<HTMLInputElement | null>(null);

  // Suggestions based on current input
  const suggestions = inputVal.trim()
    ? AUTOCOMPLETE_COMMANDS.filter(
        (c) =>
          c.cmd.startsWith(inputVal.toUpperCase()) ||
          c.alias === inputVal.toUpperCase()
      ).slice(0, 5)
    : [];

  // Handle keypresses
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    // ESC cancels command
    if (e.key === 'Escape') {
      e.preventDefault();
      cancelCurrentCommand();
      setInputVal('');
      setShowSuggestions(false);
      return;
    }

    // ENTER executes
    if (e.key === 'Enter') {
      e.preventDefault();
      const trimmed = inputVal.trim();
      if (trimmed) {
        executeCommand(trimmed);
        setInputVal('');
        setHistoryIndex(-1);
        setShowSuggestions(false);
      }
      return;
    }

    // UP Arrow -> Previous command in history
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (!commandHistory.length) return;
      const nextIdx = historyIndex === -1 ? commandHistory.length - 1 : Math.max(0, historyIndex - 1);
      setHistoryIndex(nextIdx);
      setInputVal(commandHistory[nextIdx]);
      return;
    }

    // DOWN Arrow -> Next command in history
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIndex >= 0 && historyIndex < commandHistory.length - 1) {
        const nextIdx = historyIndex + 1;
        setHistoryIndex(nextIdx);
        setInputVal(commandHistory[nextIdx]);
      } else {
        setHistoryIndex(-1);
        setInputVal('');
      }
      return;
    }
  };

  // Keep input focused when typing anywhere in app unless another input is active
  useEffect(() => {
    const handleGlobalKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        cancelCurrentCommand();
        setInputVal('');
        setShowSuggestions(false);
        return;
      }

      // If user starts typing standard alphanumeric characters and focus is not on another input
      const activeTag = document.activeElement?.tagName.toLowerCase();
      if (activeTag !== 'input' && activeTag !== 'select' && activeTag !== 'textarea') {
        if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) {
          inputRef.current?.focus();
        }
      }
    };

    window.addEventListener('keydown', handleGlobalKey);
    return () => window.removeEventListener('keydown', handleGlobalKey);
  }, [cancelCurrentCommand]);

  return (
    <div className="relative w-full bg-zinc-950 border-t border-zinc-800 text-zinc-200 font-mono text-xs select-none shadow-inner">
      {/* Autocomplete Popup */}
      {showSuggestions && suggestions.length > 0 && (
        <div className="absolute bottom-full left-16 mb-1 bg-zinc-900 border border-zinc-700 rounded-lg shadow-2xl p-1.5 z-30 min-w-[280px]">
          <div className="text-[10px] text-zinc-500 uppercase px-2 py-0.5 font-bold">Suggested Commands</div>
          {suggestions.map((s) => (
            <button
              key={s.cmd}
              onClick={() => {
                executeCommand(s.cmd);
                setInputVal('');
                setShowSuggestions(false);
              }}
              className="w-full text-left px-2 py-1 rounded hover:bg-zinc-800 flex items-center justify-between transition text-xs"
            >
              <div className="flex items-center gap-2">
                <span className="font-bold text-sky-400">{s.cmd}</span>
                <span className="text-[10px] text-zinc-500">[{s.alias}]</span>
              </div>
              <span className="text-[10px] text-zinc-400 truncate max-w-[140px]">{s.desc}</span>
            </button>
          ))}
        </div>
      )}

      {/* Feedback log message */}
      <div className="px-3 pt-1.5 text-zinc-400 text-[11px] truncate flex items-center gap-2">
        <span className="text-zinc-600">▶</span>
        <span>{commandFeedback}</span>
      </div>

      {/* Live Command Line Input */}
      <div className="flex items-center px-3 py-1.5 gap-2">
        <span className="text-sky-400 font-semibold shrink-0">{commandPrompt}</span>
        <input
          ref={inputRef}
          type="text"
          value={inputVal}
          onChange={(e) => {
            setInputVal(e.target.value);
            setShowSuggestions(true);
          }}
          onKeyDown={handleKeyDown}
          onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
          placeholder="Type command or coordinate (e.g. LINE, 100,50, @50<45)..."
          className="flex-1 bg-transparent border-none outline-none text-white text-xs font-mono placeholder-zinc-600"
          autoComplete="off"
          spellCheck="false"
        />
        <button
          onClick={() => {
            if (inputVal.trim()) {
              executeCommand(inputVal.trim());
              setInputVal('');
            }
          }}
          className="px-2.5 py-0.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white rounded text-[11px] font-sans transition"
        >
          Enter
        </button>
      </div>
    </div>
  );
};
