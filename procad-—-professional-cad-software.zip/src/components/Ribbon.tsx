/**
 * ProCAD - Professional Engineering Ribbon & Quick-Access Toolbar
 */

import React, { useState, useRef } from 'react';
import { useCAD } from '../context/CADContext';
import { CADTool } from '../types/cad';
import { dxfService } from '../services/dxfService';
import { sampleProjects } from '../services/sampleDrawings';
import { runCADGeometryTests } from '../geometry/__tests__/cadMath.test';

export const Ribbon: React.FC = () => {
  const {
    activeTool,
    setActiveTool,
    layers,
    activeLayerId,
    setActiveLayerId,
    viewMode,
    setViewMode,
    undo,
    redo,
    canUndo,
    canRedo,
    newDrawing,
    saveProjectToJSON,
    openProjectFromJSON,
    exportProjectDXF,
    exportProjectSVG,
    extrudeSelectedTo3D,
    setIsLayerModalOpen,
    setIsBlocksModalOpen,
    setIsMeasureModalOpen,
    setCommandFeedback,
    loadSampleProject,
  } = useCAD();

  const [activeTab, setActiveTab] = useState<'home' | 'insert' | 'annotate' | 'parametric' | '3d' | 'view' | 'output'>('home');
  const [testResults, setTestResults] = useState<{ name: string; passed: boolean }[] | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const dxfInputRef = useRef<HTMLInputElement | null>(null);

  // Handle open project file
  const handleOpenJSONFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) openProjectFromJSON(content);
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // Handle open DXF file
  const handleOpenDXFFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        const parsed = dxfService.parseDXF(content);
        useCAD; // already have context
        setCommandFeedback(`Imported DXF with ${parsed.entities.length} entities and ${parsed.layers.length} layers.`);
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // Run automated geometry kernel tests
  const handleRunTests = () => {
    const results = runCADGeometryTests();
    setTestResults(results);
    const passed = results.filter((r) => r.passed).length;
    setCommandFeedback(`Self-Audit: ${passed}/${results.length} CAD Geometry Kernel tests passed.`);
  };

  return (
    <div className="flex flex-col bg-zinc-900 border-b border-zinc-800 text-zinc-200 select-none">
      {/* 1. Top Bar: Application Brand & Quick-Access Toolbar */}
      <div className="flex items-center justify-between px-3 py-1.5 bg-zinc-950 border-b border-zinc-800/80 text-xs">
        <div className="flex items-center gap-3">
          {/* Logo Badge */}
          <div className="flex items-center gap-2 font-bold tracking-tight text-white">
            <span className="w-5 h-5 rounded bg-sky-600 flex items-center justify-center font-black text-[11px] text-white shadow-sm">
              P
            </span>
            <span className="text-sm font-semibold tracking-wide">
              Pro<span className="text-sky-400">CAD</span>
            </span>
            <span className="text-[10px] bg-zinc-800 text-zinc-400 px-1.5 py-0.5 rounded font-mono">
              2026 PRO
            </span>
          </div>

          <div className="h-4 w-px bg-zinc-800 mx-1" />

          {/* Quick Access Icons */}
          <div className="flex items-center gap-1">
            <button
              onClick={newDrawing}
              title="New Drawing (Ctrl+N)"
              className="p-1.5 hover:bg-zinc-800 rounded text-zinc-300 hover:text-white transition"
            >
              📄
            </button>
            <button
              onClick={() => fileInputRef.current?.click()}
              title="Open Project (Ctrl+O)"
              className="p-1.5 hover:bg-zinc-800 rounded text-zinc-300 hover:text-white transition"
            >
              📂
            </button>
            <button
              onClick={saveProjectToJSON}
              title="Save Project (Ctrl+S)"
              className="p-1.5 hover:bg-zinc-800 rounded text-zinc-300 hover:text-white transition"
            >
              💾
            </button>
            <button
              onClick={exportProjectDXF}
              title="Export standard AutoCAD DXF"
              className="p-1.5 hover:bg-zinc-800 rounded text-zinc-300 hover:text-white transition font-mono font-bold text-[10px] text-amber-400"
            >
              DXF
            </button>
            <div className="h-3.5 w-px bg-zinc-800 mx-1" />
            <button
              onClick={undo}
              disabled={!canUndo}
              title="Undo (Ctrl+Z)"
              className="p-1.5 hover:bg-zinc-800 rounded text-zinc-300 hover:text-white disabled:opacity-30 transition"
            >
              ↶
            </button>
            <button
              onClick={redo}
              disabled={!canRedo}
              title="Redo (Ctrl+Y)"
              className="p-1.5 hover:bg-zinc-800 rounded text-zinc-300 hover:text-white disabled:opacity-30 transition"
            >
              ↷
            </button>
          </div>
        </div>

        {/* Hidden File Inputs */}
        <input
          ref={fileInputRef}
          type="file"
          accept=".json"
          onChange={handleOpenJSONFile}
          className="hidden"
        />
        <input
          ref={dxfInputRef}
          type="file"
          accept=".dxf"
          onChange={handleOpenDXFFile}
          className="hidden"
        />

        {/* Center: Drawing Title & Sample selector */}
        <div className="flex items-center gap-2">
          <span className="text-zinc-500 hidden sm:inline">Templates:</span>
          <select
            onChange={(e) => {
              if (e.target.value) loadSampleProject(e.target.value);
            }}
            className="bg-zinc-900 border border-zinc-700/80 text-zinc-300 text-[11px] rounded px-2 py-0.5 focus:outline-none"
            defaultValue=""
          >
            <option value="" disabled>Load Engineering Sample...</option>
            {sampleProjects.map((p) => (
              <option key={p.id} value={p.id}>
                {p.category}: {p.name}
              </option>
            ))}
          </select>
        </div>

        {/* Right: Workspace & View Mode Selector */}
        <div className="flex items-center gap-1.5 bg-zinc-900 p-0.5 rounded border border-zinc-800">
          <button
            onClick={() => setViewMode('2D')}
            className={`px-3 py-1 rounded text-xs font-medium transition ${
              viewMode === '2D' ? 'bg-sky-600 text-white shadow-sm' : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            2D Drafting
          </button>
          <button
            onClick={() => setViewMode('3D')}
            className={`px-3 py-1 rounded text-xs font-medium transition ${
              viewMode === '3D' ? 'bg-sky-600 text-white shadow-sm' : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            3D Modeling
          </button>
          <button
            onClick={() => setViewMode('LAYOUT')}
            className={`px-3 py-1 rounded text-xs font-medium transition ${
              viewMode === 'LAYOUT' ? 'bg-sky-600 text-white shadow-sm' : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Layout / Plot
          </button>
        </div>
      </div>

      {/* 2. Ribbon Tabs Headers */}
      <div className="flex items-center px-2 bg-zinc-900 border-b border-zinc-800">
        {(['home', 'insert', 'annotate', 'parametric', '3d', 'view', 'output'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-1.5 text-xs font-semibold uppercase tracking-wider transition border-b-2 ${
              activeTab === tab
                ? 'border-sky-500 text-white bg-zinc-800/60'
                : 'border-transparent text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/30'
            }`}
          >
            {tab === '3d' ? '3D Tools' : tab}
          </button>
        ))}
      </div>

      {/* 3. Ribbon Panel Content */}
      <div className="flex items-stretch overflow-x-auto py-2 px-3 gap-3 min-h-[82px] bg-zinc-900/90 text-xs">
        {/* HOME TAB */}
        {activeTab === 'home' && (
          <>
            {/* Draw Tools Panel */}
            <div className="flex flex-col justify-between border-r border-zinc-800 pr-3">
              <div className="grid grid-cols-5 gap-1.5">
                <RibbonToolBtn
                  tool="line"
                  active={activeTool === 'line'}
                  label="Line"
                  icon="╱"
                  onClick={() => setActiveTool('line')}
                />
                <RibbonToolBtn
                  tool="polyline"
                  active={activeTool === 'polyline'}
                  label="Polyline"
                  icon="⌇"
                  onClick={() => setActiveTool('polyline')}
                />
                <RibbonToolBtn
                  tool="circle"
                  active={activeTool === 'circle'}
                  label="Circle"
                  icon="○"
                  onClick={() => setActiveTool('circle')}
                />
                <RibbonToolBtn
                  tool="arc"
                  active={activeTool === 'arc'}
                  label="Arc"
                  icon="⌒"
                  onClick={() => setActiveTool('arc')}
                />
                <RibbonToolBtn
                  tool="rectangle"
                  active={activeTool === 'rectangle'}
                  label="Rect"
                  icon="▭"
                  onClick={() => setActiveTool('rectangle')}
                />
                <RibbonToolBtn
                  tool="polygon"
                  active={activeTool === 'polygon'}
                  label="Polygon"
                  icon="⬡"
                  onClick={() => setActiveTool('polygon')}
                />
                <RibbonToolBtn
                  tool="ellipse"
                  active={activeTool === 'ellipse'}
                  label="Ellipse"
                  icon="⬭"
                  onClick={() => setActiveTool('ellipse')}
                />
                <RibbonToolBtn
                  tool="point"
                  active={activeTool === 'point'}
                  label="Point"
                  icon="•"
                  onClick={() => setActiveTool('point')}
                />
                <RibbonToolBtn
                  tool="hatch"
                  active={activeTool === 'hatch'}
                  label="Hatch"
                  icon="▦"
                  onClick={() => setActiveTool('hatch')}
                />
                <RibbonToolBtn
                  tool="text"
                  active={activeTool === 'text'}
                  label="Text"
                  icon="A"
                  onClick={() => setActiveTool('text')}
                />
              </div>
              <div className="text-[10px] text-zinc-500 uppercase tracking-widest text-center mt-1">
                Draw
              </div>
            </div>

            {/* Modify Tools Panel */}
            <div className="flex flex-col justify-between border-r border-zinc-800 px-3">
              <div className="grid grid-cols-4 gap-1.5">
                <RibbonToolBtn
                  tool="move"
                  active={activeTool === 'move'}
                  label="Move"
                  icon="✥"
                  onClick={() => setActiveTool('move')}
                />
                <RibbonToolBtn
                  tool="copy"
                  active={activeTool === 'copy'}
                  label="Copy"
                  icon="⎘"
                  onClick={() => setActiveTool('copy')}
                />
                <RibbonToolBtn
                  tool="rotate"
                  active={activeTool === 'rotate'}
                  label="Rotate"
                  icon="↻"
                  onClick={() => setActiveTool('rotate')}
                />
                <RibbonToolBtn
                  tool="mirror"
                  active={activeTool === 'mirror'}
                  label="Mirror"
                  icon="⧎"
                  onClick={() => setActiveTool('mirror')}
                />
                <RibbonToolBtn
                  tool="scale"
                  active={activeTool === 'scale'}
                  label="Scale"
                  icon="⤢"
                  onClick={() => setActiveTool('scale')}
                />
                <RibbonToolBtn
                  tool="fillet"
                  active={activeTool === 'fillet'}
                  label="Fillet"
                  icon="◜"
                  onClick={() => setActiveTool('fillet')}
                />
                <RibbonToolBtn
                  tool="chamfer"
                  active={activeTool === 'chamfer'}
                  label="Chamfer"
                  icon="◸"
                  onClick={() => setActiveTool('chamfer')}
                />
                <RibbonToolBtn
                  tool="offset"
                  active={activeTool === 'offset'}
                  label="Offset"
                  icon="⇉"
                  onClick={() => setActiveTool('offset')}
                />
              </div>
              <div className="text-[10px] text-zinc-500 uppercase tracking-widest text-center mt-1">
                Modify
              </div>
            </div>

            {/* Annotation Panel */}
            <div className="flex flex-col justify-between border-r border-zinc-800 px-3">
              <div className="grid grid-cols-2 gap-1.5">
                <RibbonToolBtn
                  tool="dimension_linear"
                  active={activeTool === 'dimension_linear'}
                  label="Linear"
                  icon="↔"
                  onClick={() => setActiveTool('dimension_linear')}
                />
                <RibbonToolBtn
                  tool="dimension_aligned"
                  active={activeTool === 'dimension_aligned'}
                  label="Aligned"
                  icon="⤡"
                  onClick={() => setActiveTool('dimension_aligned')}
                />
              </div>
              <div className="text-[10px] text-zinc-500 uppercase tracking-widest text-center mt-1">
                Dimension
              </div>
            </div>

            {/* Layers Panel */}
            <div className="flex flex-col justify-between border-r border-zinc-800 px-3 min-w-[150px]">
              <div className="flex flex-col gap-1.5">
                <select
                  value={activeLayerId}
                  onChange={(e) => setActiveLayerId(e.target.value)}
                  className="bg-zinc-800 border border-zinc-700 text-xs text-zinc-200 rounded px-2 py-1 focus:outline-none"
                >
                  {layers.map((l) => (
                    <option key={l.id} value={l.id}>
                      {l.name}
                    </option>
                  ))}
                </select>
                <button
                  onClick={() => setIsLayerModalOpen(true)}
                  className="px-2 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700 rounded text-center font-medium transition"
                >
                  Layer Properties
                </button>
              </div>
              <div className="text-[10px] text-zinc-500 uppercase tracking-widest text-center mt-1">
                Layers
              </div>
            </div>

            {/* Utilities Panel */}
            <div className="flex flex-col justify-between px-3">
              <div className="flex gap-1.5">
                <RibbonToolBtn
                  tool="dist"
                  active={activeTool === 'dist'}
                  label="Distance"
                  icon="📏"
                  onClick={() => setActiveTool('dist')}
                />
                <button
                  onClick={() => setIsMeasureModalOpen(true)}
                  className="flex flex-col items-center justify-center p-2 rounded bg-zinc-800/80 hover:bg-zinc-700 text-zinc-300 hover:text-white transition w-16"
                >
                  <span className="text-sm">📐</span>
                  <span className="text-[10px] mt-0.5">Measure</span>
                </button>
              </div>
              <div className="text-[10px] text-zinc-500 uppercase tracking-widest text-center mt-1">
                Utilities
              </div>
            </div>
          </>
        )}

        {/* INSERT TAB */}
        {activeTab === 'insert' && (
          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsBlocksModalOpen(true)}
              className="flex items-center gap-2.5 px-4 py-2.5 bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 rounded-lg text-zinc-200 transition"
            >
              <span className="text-xl">📦</span>
              <div className="text-left">
                <div className="font-semibold text-xs">Block Library</div>
                <div className="text-[10px] text-zinc-400">Doors, Windows, Fasteners, Symbols</div>
              </div>
            </button>

            <button
              onClick={() => dxfInputRef.current?.click()}
              className="flex items-center gap-2.5 px-4 py-2.5 bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 rounded-lg text-zinc-200 transition"
            >
              <span className="text-xl">📐</span>
              <div className="text-left">
                <div className="font-semibold text-xs">Import DXF</div>
                <div className="text-[10px] text-zinc-400">Standard AutoCAD DXF File</div>
              </div>
            </button>

            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-2.5 px-4 py-2.5 bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 rounded-lg text-zinc-200 transition"
            >
              <span className="text-xl">📂</span>
              <div className="text-left">
                <div className="font-semibold text-xs">Open Project JSON</div>
                <div className="text-[10px] text-zinc-400">Native ProCAD Drawing</div>
              </div>
            </button>
          </div>
        )}

        {/* ANNOTATE TAB */}
        {activeTab === 'annotate' && (
          <div className="flex items-center gap-3">
            <RibbonToolBtn
              tool="dimension_linear"
              active={activeTool === 'dimension_linear'}
              label="Linear Dim"
              icon="↔"
              onClick={() => setActiveTool('dimension_linear')}
            />
            <RibbonToolBtn
              tool="dimension_aligned"
              active={activeTool === 'dimension_aligned'}
              label="Aligned Dim"
              icon="⤡"
              onClick={() => setActiveTool('dimension_aligned')}
            />
            <RibbonToolBtn
              tool="text"
              active={activeTool === 'text'}
              label="Multiline Text"
              icon="A"
              onClick={() => setActiveTool('text')}
            />
          </div>
        )}

        {/* PARAMETRIC / MEASURE TAB */}
        {activeTab === 'parametric' && (
          <div className="flex items-center gap-3">
            <RibbonToolBtn
              tool="dist"
              active={activeTool === 'dist'}
              label="Measure Distance"
              icon="📏"
              onClick={() => setActiveTool('dist')}
            />
            <button
              onClick={() => setIsMeasureModalOpen(true)}
              className="flex items-center gap-2 px-3 py-2 bg-zinc-800 hover:bg-zinc-700 rounded border border-zinc-700 text-xs text-zinc-200 transition"
            >
              <span>📐</span>
              <span>Full Geometric Measurement Calculator</span>
            </button>
          </div>
        )}

        {/* 3D TOOLS TAB */}
        {activeTab === '3d' && (
          <div className="flex items-center gap-3">
            <button
              onClick={() => setViewMode('3D')}
              className="flex items-center gap-2 px-4 py-2 bg-sky-700 hover:bg-sky-600 rounded text-xs font-semibold text-white transition shadow-sm"
            >
              <span>🌐</span> Enter 3D Solid Workspace
            </button>
            <button
              onClick={() => extrudeSelectedTo3D(50)}
              className="flex items-center gap-2 px-4 py-2 bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 rounded text-xs font-semibold text-sky-400 transition"
            >
              <span>⬆</span> Extrude 2D Selection (50mm)
            </button>
          </div>
        )}

        {/* VIEW TAB */}
        {activeTab === 'view' && (
          <div className="flex items-center gap-3">
            <button
              onClick={() => window.dispatchEvent(new CustomEvent('cad-zoom-extents'))}
              className="px-3 py-2 bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 rounded text-xs text-zinc-200 font-medium transition"
            >
              ⤢ Zoom Extents (Z+E)
            </button>
            <button
              onClick={() => setActiveTool('pan')}
              className={`px-3 py-2 rounded text-xs border border-zinc-700 transition ${
                activeTool === 'pan' ? 'bg-sky-600 text-white' : 'bg-zinc-800 text-zinc-200 hover:bg-zinc-700'
              }`}
            >
              ✋ Pan Tool
            </button>
          </div>
        )}

        {/* OUTPUT TAB */}
        {activeTab === 'output' && (
          <div className="flex items-center gap-3">
            <button
              onClick={exportProjectDXF}
              className="flex items-center gap-2 px-3 py-2 bg-amber-950/80 hover:bg-amber-900 border border-amber-700/80 rounded text-xs text-amber-200 font-semibold transition"
            >
              <span>📄</span> Export AutoCAD DXF
            </button>
            <button
              onClick={exportProjectSVG}
              className="flex items-center gap-2 px-3 py-2 bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 rounded text-xs text-zinc-200 font-semibold transition"
            >
              <span>🎨</span> Export Vector SVG
            </button>
            <button
              onClick={saveProjectToJSON}
              className="flex items-center gap-2 px-3 py-2 bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 rounded text-xs text-zinc-200 font-semibold transition"
            >
              <span>💾</span> Save Native Project JSON
            </button>
            <button
              onClick={() => setViewMode('LAYOUT')}
              className="flex items-center gap-2 px-3 py-2 bg-sky-900/80 hover:bg-sky-800 border border-sky-700/80 rounded text-xs text-sky-200 font-semibold transition"
            >
              <span>🖨️</span> Plot to PDF / Print Sheet
            </button>
            <button
              onClick={handleRunTests}
              className="flex items-center gap-2 px-3 py-2 bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-700/80 rounded text-xs text-emerald-300 font-semibold transition ml-auto"
            >
              <span>⚙️</span> Run Geometry Kernel Tests
            </button>
          </div>
        )}
      </div>

      {/* Test Results Display Toast (if ran) */}
      {testResults && (
        <div className="bg-emerald-950/90 border-t border-emerald-800 px-4 py-2 flex items-center justify-between text-xs text-emerald-200 font-mono">
          <div className="flex items-center gap-2">
            <span className="font-bold">✓ Kernel Test Suite:</span>
            <span>
              {testResults.filter((r) => r.passed).length}/{testResults.length} Operations Verified (Intersections, Coordinates, Shoelace Area, Fillets, Offsets).
            </span>
          </div>
          <button
            onClick={() => setTestResults(null)}
            className="text-emerald-400 hover:text-white"
          >
            ✕
          </button>
        </div>
      )}
    </div>
  );
};

// Ribbon Button Component helper
const RibbonToolBtn: React.FC<{
  tool: CADTool;
  active: boolean;
  label: string;
  icon: string;
  onClick: () => void;
}> = ({ active, label, icon, onClick }) => {
  return (
    <button
      onClick={onClick}
      title={`${label} Tool`}
      className={`flex flex-col items-center justify-center p-1.5 rounded transition min-w-[44px] ${
        active
          ? 'bg-sky-600 text-white shadow-sm'
          : 'bg-zinc-800/60 hover:bg-zinc-700/80 text-zinc-300 hover:text-white'
      }`}
    >
      <span className="text-sm font-semibold">{icon}</span>
      <span className="text-[10px] mt-0.5 leading-tight">{label}</span>
    </button>
  );
};
