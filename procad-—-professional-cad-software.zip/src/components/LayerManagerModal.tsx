/**
 * ProCAD - Layer Properties Manager Dialog
 * Full AutoCAD Layer management with color, visibility, lock, linetype, lineweight, and counts.
 */

import React, { useState } from 'react';
import { useCAD } from '../context/CADContext';
import { LineType } from '../types/cad';

export const LayerManagerModal: React.FC = () => {
  const {
    layers,
    activeLayerId,
    setActiveLayerId,
    createLayer,
    deleteLayer,
    toggleLayerVisibility,
    toggleLayerLock,
    updateLayer,
    isLayerModalOpen,
    setIsLayerModalOpen,
    entities,
  } = useCAD();

  const [newLayerName, setNewLayerName] = useState('');
  const [newLayerColor, setNewLayerColor] = useState('#00ffff');

  if (!isLayerModalOpen) return null;

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLayerName.trim()) return;
    createLayer(newLayerName.trim(), newLayerColor);
    setNewLayerName('');
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 select-none">
      <div className="bg-zinc-900 border border-zinc-700 rounded-xl shadow-2xl w-full max-w-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-zinc-950 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-sky-500" />
            <h2 className="text-sm font-bold text-zinc-100 tracking-wide">
              LAYER PROPERTIES MANAGER
            </h2>
          </div>
          <button
            onClick={() => setIsLayerModalOpen(false)}
            className="text-zinc-400 hover:text-white p-1 rounded hover:bg-zinc-800 transition"
          >
            ✕
          </button>
        </div>

        {/* Toolbar: New Layer Input */}
        <form onSubmit={handleCreate} className="flex items-center gap-2 p-3 bg-zinc-900/90 border-b border-zinc-800 text-xs">
          <input
            type="text"
            value={newLayerName}
            onChange={(e) => setNewLayerName(e.target.value)}
            placeholder="New layer name (e.g. ELEC-FIXT, HVAC)..."
            className="flex-1 bg-zinc-950 border border-zinc-700 rounded px-2.5 py-1.5 text-zinc-100 focus:outline-none focus:border-sky-500 font-mono"
          />
          <div className="flex items-center gap-1.5 bg-zinc-950 border border-zinc-700 px-2 py-1 rounded">
            <span className="text-[10px] text-zinc-400">Color:</span>
            <input
              type="color"
              value={newLayerColor}
              onChange={(e) => setNewLayerColor(e.target.value)}
              className="w-6 h-5 bg-transparent cursor-pointer rounded"
            />
          </div>
          <button
            type="submit"
            className="px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white font-medium rounded transition text-xs shadow-sm"
          >
            + New Layer
          </button>
        </form>

        {/* Layer Table */}
        <div className="overflow-y-auto flex-1 p-3">
          <table className="w-full text-left text-xs font-mono text-zinc-300 border-collapse">
            <thead>
              <tr className="border-b border-zinc-800 text-[10px] uppercase text-zinc-400 tracking-wider">
                <th className="pb-2 pl-2">Status</th>
                <th className="pb-2">Name</th>
                <th className="pb-2 text-center">Vis</th>
                <th className="pb-2 text-center">Lock</th>
                <th className="pb-2">Color</th>
                <th className="pb-2">Linetype</th>
                <th className="pb-2">Lineweight</th>
                <th className="pb-2 text-center">Objects</th>
                <th className="pb-2 text-right pr-2">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/60">
              {layers.map((l) => {
                const isCurrent = activeLayerId === l.id;
                const count = entities.filter((e) => e.layer === l.id).length;

                return (
                  <tr
                    key={l.id}
                    className={`hover:bg-zinc-800/50 transition ${
                      isCurrent ? 'bg-sky-950/30' : ''
                    }`}
                  >
                    {/* Status current icon */}
                    <td className="py-2.5 pl-2">
                      <button
                        onClick={() => setActiveLayerId(l.id)}
                        title={isCurrent ? 'Current Active Layer' : 'Set as Current Layer'}
                        className={`w-4 h-4 rounded-full flex items-center justify-center font-bold text-[9px] ${
                          isCurrent
                            ? 'bg-emerald-500 text-black'
                            : 'border border-zinc-600 text-transparent hover:border-emerald-400'
                        }`}
                      >
                        ✓
                      </button>
                    </td>

                    {/* Name */}
                    <td className="py-2.5 font-semibold text-white">
                      {l.name}
                      {isCurrent && (
                        <span className="ml-1.5 text-[9px] bg-emerald-950 border border-emerald-700/60 text-emerald-300 px-1 rounded">
                          CURRENT
                        </span>
                      )}
                    </td>

                    {/* Visibility */}
                    <td className="py-2.5 text-center">
                      <button
                        onClick={() => toggleLayerVisibility(l.id)}
                        title={l.visible ? 'Turn layer Off' : 'Turn layer On'}
                        className="p-1 hover:bg-zinc-800 rounded transition"
                      >
                        {l.visible ? '👁️' : '🕶️'}
                      </button>
                    </td>

                    {/* Lock */}
                    <td className="py-2.5 text-center">
                      <button
                        onClick={() => toggleLayerLock(l.id)}
                        title={l.locked ? 'Unlock Layer' : 'Lock Layer'}
                        className="p-1 hover:bg-zinc-800 rounded transition"
                      >
                        {l.locked ? '🔒' : '🔓'}
                      </button>
                    </td>

                    {/* Color Swatch */}
                    <td className="py-2.5">
                      <div className="flex items-center gap-1.5">
                        <input
                          type="color"
                          value={l.color}
                          onChange={(e) => updateLayer(l.id, { color: e.target.value })}
                          className="w-6 h-5 bg-transparent cursor-pointer rounded"
                        />
                        <span className="text-[10px] text-zinc-400">{l.color}</span>
                      </div>
                    </td>

                    {/* Linetype */}
                    <td className="py-2.5">
                      <select
                        value={l.lineType}
                        onChange={(e) => updateLayer(l.id, { lineType: e.target.value as LineType })}
                        className="bg-zinc-950 border border-zinc-800 rounded px-1.5 py-0.5 text-[11px] text-zinc-200"
                      >
                        <option value="CONTINUOUS">Continuous</option>
                        <option value="DASHED">Dashed</option>
                        <option value="DOTTED">Dotted</option>
                        <option value="CENTER">Center</option>
                      </select>
                    </td>

                    {/* Lineweight */}
                    <td className="py-2.5">
                      <select
                        value={l.lineWeight}
                        onChange={(e) => updateLayer(l.id, { lineWeight: parseFloat(e.target.value) })}
                        className="bg-zinc-950 border border-zinc-800 rounded px-1.5 py-0.5 text-[11px] text-zinc-200"
                      >
                        <option value="0.13">0.13 mm</option>
                        <option value="0.18">0.18 mm</option>
                        <option value="0.25">0.25 mm</option>
                        <option value="0.35">0.35 mm</option>
                        <option value="0.50">0.50 mm</option>
                        <option value="0.70">0.70 mm</option>
                      </select>
                    </td>

                    {/* Objects count */}
                    <td className="py-2.5 text-center text-zinc-400">{count}</td>

                    {/* Delete action */}
                    <td className="py-2.5 text-right pr-2">
                      {l.id !== '0' ? (
                        <button
                          onClick={() => deleteLayer(l.id)}
                          className="text-red-400 hover:text-red-300 p-1 hover:bg-zinc-800 rounded transition text-xs"
                          title="Delete Layer"
                        >
                          ✕
                        </button>
                      ) : (
                        <span className="text-zinc-600 text-[10px]">Def</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-4 py-2.5 bg-zinc-950 border-t border-zinc-800 text-xs">
          <span className="text-zinc-400">
            Total Layers: <strong className="text-white">{layers.length}</strong>
          </span>
          <button
            onClick={() => setIsLayerModalOpen(false)}
            className="px-4 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-white rounded transition text-xs font-semibold"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
