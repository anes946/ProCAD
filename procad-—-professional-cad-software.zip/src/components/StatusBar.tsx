/**
 * ProCAD - Bottom Status Bar & Mode Toggles
 * Coordinates, Ortho (F8), Polar (F10), OSNAP (F3), Grid (F7), Dynamic Input (F12), Units.
 */

import React, { useState } from 'react';
import { useCAD } from '../context/CADContext';

export const StatusBar: React.FC = () => {
  const {
    cursorPos,
    gridSettings,
    toggleGrid,
    orthoMode,
    toggleOrtho,
    polarTracking,
    togglePolar,
    snapSettings,
    setSnapSettings,
    toggleOsnap,
    units,
    setUnits,
  } = useCAD();

  const [showSnapMenu, setShowSnapMenu] = useState(false);

  return (
    <div className="relative flex items-center justify-between px-3 py-1 bg-zinc-950 border-t border-zinc-800 text-[11px] font-mono text-zinc-300 select-none z-20">
      {/* Left: Precision World Coordinates Readout */}
      <div className="flex items-center gap-3">
        <span className="text-zinc-500 font-sans uppercase font-bold text-[10px]">WCS</span>
        <span className="text-sky-400">{cursorPos.x.toFixed(2)}</span>
        <span className="text-emerald-400">{cursorPos.y.toFixed(2)}</span>
        <span className="text-zinc-500">0.00</span>
      </div>

      {/* Right: Engineering Mode Toggles */}
      <div className="flex items-center gap-1.5">
        {/* Grid Toggle (F7) */}
        <button
          onClick={toggleGrid}
          title="Display Drawing Grid (F7)"
          className={`px-2 py-0.5 rounded font-sans font-medium transition ${
            gridSettings.enabled
              ? 'bg-sky-600 text-white shadow-sm'
              : 'bg-zinc-900 text-zinc-400 hover:text-zinc-200 border border-zinc-800'
          }`}
        >
          GRID (F7)
        </button>

        {/* Ortho Mode (F8) */}
        <button
          onClick={toggleOrtho}
          title="Restrict Cursor Orthogonally (F8)"
          className={`px-2 py-0.5 rounded font-sans font-medium transition ${
            orthoMode
              ? 'bg-sky-600 text-white shadow-sm'
              : 'bg-zinc-900 text-zinc-400 hover:text-zinc-200 border border-zinc-800'
          }`}
        >
          ORTHO (F8)
        </button>

        {/* Polar Tracking (F10) */}
        <button
          onClick={togglePolar}
          title="Polar Tracking (F10)"
          className={`px-2 py-0.5 rounded font-sans font-medium transition ${
            polarTracking
              ? 'bg-sky-600 text-white shadow-sm'
              : 'bg-zinc-900 text-zinc-400 hover:text-zinc-200 border border-zinc-800'
          }`}
        >
          POLAR (F10)
        </button>

        {/* OSNAP (F3) with Flyout Settings */}
        <div className="relative">
          <div className="flex items-center">
            <button
              onClick={toggleOsnap}
              title="Object Snap (F3)"
              className={`px-2 py-0.5 rounded-l font-sans font-medium transition ${
                snapSettings.enabled
                  ? 'bg-sky-600 text-white shadow-sm'
                  : 'bg-zinc-900 text-zinc-400 hover:text-zinc-200 border border-zinc-800'
              }`}
            >
              OSNAP (F3)
            </button>
            <button
              onClick={() => setShowSnapMenu(!showSnapMenu)}
              title="OSNAP Settings"
              className="px-1 py-0.5 bg-zinc-900 border border-l-0 border-zinc-800 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded-r transition"
            >
              ▾
            </button>
          </div>

          {/* OSNAP Flyout Menu */}
          {showSnapMenu && (
            <div className="absolute bottom-full right-0 mb-1 bg-zinc-900 border border-zinc-700 rounded-lg shadow-2xl p-2.5 z-40 w-52 text-xs font-sans">
              <div className="font-bold text-zinc-200 pb-1.5 border-b border-zinc-800 mb-2 flex justify-between">
                <span>Object Snap Modes</span>
                <button
                  onClick={() => setShowSnapMenu(false)}
                  className="text-zinc-500 hover:text-zinc-300"
                >
                  ✕
                </button>
              </div>
              <div className="flex flex-col gap-1.5 text-zinc-300">
                <label className="flex items-center gap-2 cursor-pointer hover:text-white">
                  <input
                    type="checkbox"
                    checked={snapSettings.endpoint}
                    onChange={(e) => setSnapSettings((s) => ({ ...s, endpoint: e.target.checked }))}
                    className="accent-sky-500"
                  />
                  <span>Endpoint (□)</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer hover:text-white">
                  <input
                    type="checkbox"
                    checked={snapSettings.midpoint}
                    onChange={(e) => setSnapSettings((s) => ({ ...s, midpoint: e.target.checked }))}
                    className="accent-sky-500"
                  />
                  <span>Midpoint (△)</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer hover:text-white">
                  <input
                    type="checkbox"
                    checked={snapSettings.center}
                    onChange={(e) => setSnapSettings((s) => ({ ...s, center: e.target.checked }))}
                    className="accent-sky-500"
                  />
                  <span>Center (○)</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer hover:text-white">
                  <input
                    type="checkbox"
                    checked={snapSettings.intersection}
                    onChange={(e) => setSnapSettings((s) => ({ ...s, intersection: e.target.checked }))}
                    className="accent-sky-500"
                  />
                  <span>Intersection (✕)</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer hover:text-white">
                  <input
                    type="checkbox"
                    checked={snapSettings.perpendicular}
                    onChange={(e) => setSnapSettings((s) => ({ ...s, perpendicular: e.target.checked }))}
                    className="accent-sky-500"
                  />
                  <span>Perpendicular (∟)</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer hover:text-white">
                  <input
                    type="checkbox"
                    checked={snapSettings.nearest}
                    onChange={(e) => setSnapSettings((s) => ({ ...s, nearest: e.target.checked }))}
                    className="accent-sky-500"
                  />
                  <span>Nearest (⧖)</span>
                </label>
              </div>
            </div>
          )}
        </div>

        {/* Units Selector */}
        <div className="flex items-center gap-1 border-l border-zinc-800 pl-2 ml-1 font-sans">
          <span className="text-[10px] text-zinc-500">UNIT:</span>
          <select
            value={units}
            onChange={(e) => setUnits(e.target.value as any)}
            className="bg-zinc-900 border border-zinc-800 text-zinc-300 rounded px-1.5 py-0.5 text-[11px] focus:outline-none"
          >
            <option value="mm">mm</option>
            <option value="cm">cm</option>
            <option value="m">m</option>
            <option value="inch">in</option>
            <option value="ft">ft</option>
          </select>
        </div>
      </div>
    </div>
  );
};
