/**
 * ProCAD - Paper Space & Layout Management Engine
 * Engineering printable sheets (A4, A3, Letter) with ISO title blocks, viewports, and plot to PDF.
 */

import React, { useState } from 'react';
import { useCAD } from '../context/CADContext';
import { cadMath } from '../geometry/cadMath';

export const LayoutView: React.FC = () => {
  const { entities, layers, setViewMode } = useCAD();

  const [paperSize, setPaperSize] = useState<'A4' | 'A3' | 'Letter'>('A4');
  const [orientation, setOrientation] = useState<'landscape' | 'portrait'>('landscape');
  const [plotScale, setPlotScale] = useState<'1:50' | '1:100' | '1:1' | 'FIT'>('FIT');
  const [titleText, setTitleText] = useState('PROCAD RESIDENTIAL / ENGINEERING DRAWING');
  const [drawnBy, setDrawnBy] = useState('LEAD CAD ENGINEER');
  const [drawingNum, setDrawingNum] = useState('PC-2026-001');

  // Sheet dimensions in CSS pixels (roughly 96 DPI / scaled for preview)
  const paperDims = {
    A4: orientation === 'landscape' ? { w: 842, h: 595 } : { w: 595, h: 842 },
    A3: orientation === 'landscape' ? { w: 1190, h: 842 } : { w: 842, h: 1190 },
    Letter: orientation === 'landscape' ? { w: 792, h: 612 } : { w: 612, h: 792 },
  }[paperSize];

  // Calculate viewport transformation to fit entities onto sheet
  let minX = 0, minY = 0, maxX = 100, maxY = 100;
  if (entities.length > 0) {
    const b0 = cadMath.getEntityBounds(entities[0]);
    minX = b0.minX;
    minY = b0.minY;
    maxX = b0.maxX;
    maxY = b0.maxY;
    entities.forEach((e) => {
      const b = cadMath.getEntityBounds(e);
      minX = Math.min(minX, b.minX);
      minY = Math.min(minY, b.minY);
      maxX = Math.max(maxX, b.maxX);
      maxY = Math.max(maxY, b.maxY);
    });
  }

  // Margin inside title block border
  const margin = 36;
  const vpWidth = paperDims.w - margin * 2;
  const vpHeight = paperDims.h - margin * 2 - 80; // 80px space for title block at bottom

  const drawW = Math.max(10, maxX - minX);
  const drawH = Math.max(10, maxY - minY);
  const scaleFit = Math.min(vpWidth / drawW, vpHeight / drawH) * 0.9;

  const vpScale = plotScale === 'FIT' ? scaleFit : 0.45;
  const centerX = (minX + maxX) / 2;
  const centerY = (minY + maxY) / 2;

  const worldToSheet = (x: number, y: number) => {
    return {
      x: margin + vpWidth / 2 + (x - centerX) * vpScale,
      y: margin + vpHeight / 2 - (y - centerY) * vpScale,
    };
  };

  const handlePrint = () => {
    window.print();
  };

  const layerMap = new Map(layers.map((l) => [l.id, l]));

  return (
    <div className="w-full h-full bg-zinc-950 overflow-auto p-6 flex flex-col items-center select-none text-zinc-200">
      {/* Layout Control Bar */}
      <div className="w-full max-w-4xl bg-zinc-900 border border-zinc-800 p-2.5 rounded-xl mb-5 flex flex-wrap items-center justify-between gap-3 text-xs shadow-xl print:hidden">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setViewMode('2D')}
            className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-sky-400 font-semibold rounded border border-zinc-700 transition"
          >
            ← Model Space
          </button>
          <div className="h-4 w-px bg-zinc-800" />
          <div className="flex items-center gap-1.5">
            <span className="text-zinc-400">Sheet:</span>
            <select
              value={paperSize}
              onChange={(e) => setPaperSize(e.target.value as any)}
              className="bg-zinc-950 border border-zinc-700 rounded px-2 py-1 text-white"
            >
              <option value="A4">ISO A4</option>
              <option value="A3">ISO A3</option>
              <option value="Letter">ANSI Letter</option>
            </select>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-zinc-400">Orientation:</span>
            <select
              value={orientation}
              onChange={(e) => setOrientation(e.target.value as any)}
              className="bg-zinc-950 border border-zinc-700 rounded px-2 py-1 text-white"
            >
              <option value="landscape">Landscape</option>
              <option value="portrait">Portrait</option>
            </select>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-zinc-400">Scale:</span>
            <select
              value={plotScale}
              onChange={(e) => setPlotScale(e.target.value as any)}
              className="bg-zinc-950 border border-zinc-700 rounded px-2 py-1 text-white"
            >
              <option value="FIT">Scale to Fit</option>
              <option value="1:100">1:100</option>
              <option value="1:50">1:50</option>
              <option value="1:1">1:1</option>
            </select>
          </div>
        </div>

        <button
          onClick={handlePrint}
          className="px-4 py-1.5 bg-sky-600 hover:bg-sky-500 text-white font-semibold rounded shadow-md transition flex items-center gap-1.5"
        >
          <span>🖨️</span>
          <span>Plot / Print to PDF</span>
        </button>
      </div>

      {/* The Paper Space Sheet (Clean Engineering Blueprint White/Paper Look) */}
      <div
        className="bg-white text-black shadow-2xl relative transition-all duration-200 border-2 border-zinc-300"
        style={{ width: `${paperDims.w}px`, height: `${paperDims.h}px` }}
      >
        {/* Outer Border Line */}
        <div
          className="absolute border border-black"
          style={{
            top: `${margin}px`,
            left: `${margin}px`,
            right: `${margin}px`,
            bottom: `${margin}px`,
          }}
        />

        {/* Inner Border Line (Double border ISO style) */}
        <div
          className="absolute border border-black"
          style={{
            top: `${margin + 4}px`,
            left: `${margin + 4}px`,
            right: `${margin + 4}px`,
            bottom: `${margin + 4}px`,
          }}
        />

        {/* Viewport SVG drawing vector representation */}
        <svg
          className="absolute pointer-events-none"
          style={{
            top: `${margin + 6}px`,
            left: `${margin + 6}px`,
            width: `${vpWidth - 12}px`,
            height: `${vpHeight - 12}px`,
          }}
        >
          {entities.map((ent) => {
            const layer = layerMap.get(ent.layer);
            if (layer && !layer.visible) return null;
            const stroke = '#000000'; // Standard black ink plot
            const sw = (ent.lineWeight || 0.25) * 1.5;

            if (ent.type === 'LINE') {
              const s1 = worldToSheet(ent.p1.x, ent.p1.y);
              const s2 = worldToSheet(ent.p2.x, ent.p2.y);
              return (
                <line
                  key={ent.id}
                  x1={s1.x - margin - 6}
                  y1={s1.y - margin - 6}
                  x2={s2.x - margin - 6}
                  y2={s2.y - margin - 6}
                  stroke={stroke}
                  strokeWidth={sw}
                />
              );
            }

            if (ent.type === 'RECTANGLE') {
              const s1 = worldToSheet(ent.p1.x, ent.p1.y);
              const s2 = worldToSheet(ent.p2.x, ent.p2.y);
              const rx = Math.min(s1.x, s2.x) - margin - 6;
              const ry = Math.min(s1.y, s2.y) - margin - 6;
              const rw = Math.abs(s1.x - s2.x);
              const rh = Math.abs(s1.y - s2.y);
              return (
                <rect
                  key={ent.id}
                  x={rx}
                  y={ry}
                  width={rw}
                  height={rh}
                  fill="none"
                  stroke={stroke}
                  strokeWidth={sw}
                />
              );
            }

            if (ent.type === 'CIRCLE') {
              const sc = worldToSheet(ent.center.x, ent.center.y);
              const r = ent.radius * vpScale;
              return (
                <circle
                  key={ent.id}
                  cx={sc.x - margin - 6}
                  cy={sc.y - margin - 6}
                  r={Math.max(1, r)}
                  fill="none"
                  stroke={stroke}
                  strokeWidth={sw}
                />
              );
            }

            if (ent.type === 'TEXT') {
              const sp = worldToSheet(ent.position.x, ent.position.y);
              return (
                <text
                  key={ent.id}
                  x={sp.x - margin - 6}
                  y={sp.y - margin - 6}
                  fontSize={Math.max(8, ent.height * vpScale)}
                  fontFamily="monospace"
                  fill="#000000"
                >
                  {ent.text}
                </text>
              );
            }

            return null;
          })}
        </svg>

        {/* Engineering ISO Standard Title Block (Bottom-Right) */}
        <div
          className="absolute border border-black bg-white font-mono text-[9px] select-text"
          style={{
            bottom: `${margin + 6}px`,
            right: `${margin + 6}px`,
            width: '380px',
            height: '75px',
          }}
        >
          <div className="grid grid-cols-4 h-full border-collapse">
            {/* Logo / Company */}
            <div className="col-span-2 border-r border-b border-black p-1.5 flex flex-col justify-between">
              <span className="text-[10px] font-bold tracking-tight">PROCAD ENGINEERING CORP</span>
              <input
                type="text"
                value={titleText}
                onChange={(e) => setTitleText(e.target.value)}
                className="font-bold text-[10px] uppercase bg-transparent outline-none truncate"
              />
            </div>

            {/* Drawing Number */}
            <div className="col-span-2 border-b border-black p-1.5 flex flex-col justify-between">
              <span className="text-zinc-600 text-[8px]">DRAWING NUMBER</span>
              <input
                type="text"
                value={drawingNum}
                onChange={(e) => setDrawingNum(e.target.value)}
                className="font-bold text-[11px] bg-transparent outline-none"
              />
            </div>

            {/* Drawn By */}
            <div className="border-r border-black p-1">
              <span className="text-zinc-600 text-[7px] block">DRAWN BY</span>
              <input
                type="text"
                value={drawnBy}
                onChange={(e) => setDrawnBy(e.target.value)}
                className="font-semibold text-[8px] bg-transparent outline-none w-full"
              />
            </div>

            {/* Date */}
            <div className="border-r border-black p-1">
              <span className="text-zinc-600 text-[7px] block">DATE</span>
              <span className="font-semibold text-[8px]">{new Date().toISOString().slice(0, 10)}</span>
            </div>

            {/* Scale */}
            <div className="border-r border-black p-1">
              <span className="text-zinc-600 text-[7px] block">SCALE</span>
              <span className="font-semibold text-[8px]">{plotScale}</span>
            </div>

            {/* Sheet */}
            <div className="p-1">
              <span className="text-zinc-600 text-[7px] block">SHEET</span>
              <span className="font-semibold text-[8px]">1 OF 1</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
