/**
 * ProCAD - High-Precision 2D Canvas Drafting Engine
 */

import React, { useRef, useEffect, useState, useCallback } from 'react';
import { useCAD } from '../context/CADContext';
import { Point2D, CADEntity, LineEntity, CircleEntity, RectEntity, ArcEntity, PolylineEntity, DimensionEntity, TextEntity, HatchEntity } from '../types/cad';
import { cadMath } from '../geometry/cadMath';
import { snappingEngine } from '../geometry/snapping';

export const CADCanvas: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const {
    entities,
    layers,
    activeLayerId,
    activeTool,
    setActiveTool,
    selectedIds,
    setSelectedIds,
    toggleSelectEntity,
    clearSelection,
    addEntity,
    updateEntity,
    deleteEntities,
    snapSettings,
    gridSettings,
    orthoMode,
    polarTracking,
    polarAngleStep,
    dynamicInput,
    units,
    cursorPos,
    setCursorPos,
    activeSnap,
    setActiveSnap,
    setCommandPrompt,
    setCommandFeedback,
    commandStep,
  } = useCAD();

  // Viewport transformation: World coordinates <-> Screen coordinates
  // ScreenX = (WorldX * zoom) + panX
  // ScreenY = (WorldY * -zoom) + panY (Y-up in CAD world, Y-down in screen canvas)
  const [viewport, setViewport] = useState({
    panX: 200,
    panY: 500,
    zoom: 0.65,
  });

  const isPanningRef = useRef(false);
  const panStartRef = useRef<Point2D>({ x: 0, y: 0 });
  const viewportStartRef = useRef({ panX: 0, panY: 0 });
  const isSpacePressedRef = useRef(false);

  // Tool drafting multi-step state
  const [toolPoints, setToolPoints] = useState<Point2D[]>([]);
  const [hoverGrip, setHoverGrip] = useState<{ entityId: string; type: string; index: number; point: Point2D } | null>(null);
  const [activeGrip, setActiveGrip] = useState<{ entityId: string; type: string; index: number; startPoint: Point2D } | null>(null);

  // Selection window box
  const [selectionBox, setSelectionBox] = useState<{ start: Point2D; current: Point2D } | null>(null);

  // Text entry modal state
  const [textPromptPos, setTextPromptPos] = useState<Point2D | null>(null);
  const [textInputVal, setTextInputVal] = useState('NOTE');

  // Convert World coordinates to Canvas screen coordinates
  const worldToScreen = useCallback(
    (w: Point2D): Point2D => {
      return {
        x: w.x * viewport.zoom + viewport.panX,
        y: -w.y * viewport.zoom + viewport.panY,
      };
    },
    [viewport]
  );

  // Convert Canvas screen coordinates to World coordinates
  const screenToWorld = useCallback(
    (s: Point2D): Point2D => {
      return {
        x: (s.x - viewport.panX) / viewport.zoom,
        y: -(s.y - viewport.panY) / viewport.zoom,
      };
    },
    [viewport]
  );

  // Center and Zoom extents
  const zoomExtents = useCallback(() => {
    if (!entities.length || !containerRef.current) {
      setViewport({ panX: 200, panY: 500, zoom: 0.65 });
      return;
    }

    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    entities.forEach((ent) => {
      const b = cadMath.getEntityBounds(ent);
      minX = Math.min(minX, b.minX);
      minY = Math.min(minY, b.minY);
      maxX = Math.max(maxX, b.maxX);
      maxY = Math.max(maxY, b.maxY);
    });

    const rect = containerRef.current.getBoundingClientRect();
    const padding = 80;
    const drawW = Math.max(10, maxX - minX);
    const drawH = Math.max(10, maxY - minY);
    const scaleX = (rect.width - padding * 2) / drawW;
    const scaleY = (rect.height - padding * 2) / drawH;
    const newZoom = Math.min(scaleX, scaleY, 5);

    const midX = (minX + maxX) / 2;
    const midY = (minY + maxY) / 2;

    setViewport({
      zoom: Math.max(0.05, newZoom),
      panX: rect.width / 2 - midX * newZoom,
      panY: rect.height / 2 + midY * newZoom,
    });
  }, [entities]);

  // Listen to custom global events & keyboard
  useEffect(() => {
    const handleZoomExtents = () => zoomExtents();
    const handleCoordInput = (e: CustomEvent<Point2D>) => {
      handleDraftStep(e.detail);
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        const target = (e.target as HTMLElement)?.tagName?.toLowerCase();
        if (target !== 'input' && target !== 'textarea') {
          isSpacePressedRef.current = true;
        }
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        isSpacePressedRef.current = false;
      }
    };

    window.addEventListener('cad-zoom-extents', handleZoomExtents as any);
    window.addEventListener('cad-coordinate-input', handleCoordInput as any);
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('cad-zoom-extents', handleZoomExtents as any);
      window.removeEventListener('cad-coordinate-input', handleCoordInput as any);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  });

  // Calculate layer map for fast rendering lookup
  const layerMap = useRef(new Map(layers.map((l) => [l.id, l])));
  useEffect(() => {
    layerMap.current = new Map(layers.map((l) => [l.id, l]));
  }, [layers]);

  // Main Canvas Render loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Resize canvas to match display size with devicePixelRatio
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    if (canvas.width !== rect.width * dpr || canvas.height !== rect.height * dpr) {
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
    }

    ctx.save();
    ctx.scale(dpr, dpr);

    // 1. Background (Classic AutoCAD dark charcoal)
    ctx.fillStyle = '#1c1c1f';
    ctx.fillRect(0, 0, rect.width, rect.height);

    // 2. Render CAD Grid
    if (gridSettings.enabled) {
      const gridPitch = gridSettings.size * viewport.zoom;
      if (gridPitch > 8) {
        // Calculate visible world bounds
        const topLeftWorld = screenToWorld({ x: 0, y: 0 });
        const botRightWorld = screenToWorld({ x: rect.width, y: rect.height });

        const startX = Math.floor(Math.min(topLeftWorld.x, botRightWorld.x) / gridSettings.size) * gridSettings.size;
        const endX = Math.ceil(Math.max(topLeftWorld.x, botRightWorld.x) / gridSettings.size) * gridSettings.size;
        const startY = Math.floor(Math.min(topLeftWorld.y, botRightWorld.y) / gridSettings.size) * gridSettings.size;
        const endY = Math.ceil(Math.max(topLeftWorld.y, botRightWorld.y) / gridSettings.size) * gridSettings.size;

        ctx.strokeStyle = '#27272a';
        ctx.lineWidth = 0.5;

        // Minor grid lines
        ctx.beginPath();
        for (let x = startX; x <= endX; x += gridSettings.size) {
          const s = worldToScreen({ x, y: 0 });
          ctx.moveTo(s.x, 0);
          ctx.lineTo(s.x, rect.height);
        }
        for (let y = startY; y <= endY; y += gridSettings.size) {
          const s = worldToScreen({ x: 0, y });
          ctx.moveTo(0, s.y);
          ctx.lineTo(rect.width, s.y);
        }
        ctx.stroke();

        // Major grid lines
        const majorPitch = gridSettings.size * gridSettings.majorEvery;
        ctx.strokeStyle = '#383842';
        ctx.lineWidth = 1;
        ctx.beginPath();
        for (let x = Math.floor(startX / majorPitch) * majorPitch; x <= endX; x += majorPitch) {
          const s = worldToScreen({ x, y: 0 });
          ctx.moveTo(s.x, 0);
          ctx.lineTo(s.x, rect.height);
        }
        for (let y = Math.floor(startY / majorPitch) * majorPitch; y <= endY; y += majorPitch) {
          const s = worldToScreen({ x: 0, y });
          ctx.moveTo(0, s.y);
          ctx.lineTo(rect.width, s.y);
        }
        ctx.stroke();
      }
    }

    // 3. Render Coordinate Axes
    const originScreen = worldToScreen({ x: 0, y: 0 });
    // X Axis (Red)
    ctx.strokeStyle = '#ef4444';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(0, originScreen.y);
    ctx.lineTo(rect.width, originScreen.y);
    ctx.stroke();

    // Y Axis (Green)
    ctx.strokeStyle = '#22c55e';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(originScreen.x, 0);
    ctx.lineTo(originScreen.x, rect.height);
    ctx.stroke();

    // 4. Render All Visible CAD Entities
    entities.forEach((ent) => {
      const layer = layerMap.current.get(ent.layer);
      if (layer && !layer.visible) return;

      const isSelected = selectedIds.includes(ent.id);
      const strokeColor = isSelected ? '#38bdf8' : ent.color || layer?.color || '#ffffff';
      const baseWeight = (ent.lineWeight || layer?.lineWeight || 0.25) * viewport.zoom;
      const strokeWidth = isSelected ? Math.max(2, baseWeight * 1.5) : Math.max(1, baseWeight);

      ctx.save();
      ctx.strokeStyle = strokeColor;
      ctx.fillStyle = strokeColor;
      ctx.lineWidth = strokeWidth;

      // Line style (dashed, center, dotted)
      if (ent.lineType === 'DASHED' || layer?.lineType === 'DASHED') {
        ctx.setLineDash([8 * viewport.zoom, 5 * viewport.zoom]);
      } else if (ent.lineType === 'CENTER' || layer?.lineType === 'CENTER') {
        ctx.setLineDash([14 * viewport.zoom, 4 * viewport.zoom, 3 * viewport.zoom, 4 * viewport.zoom]);
      } else if (ent.lineType === 'DOTTED' || layer?.lineType === 'DOTTED') {
        ctx.setLineDash([2 * viewport.zoom, 3 * viewport.zoom]);
      } else {
        ctx.setLineDash([]);
      }

      switch (ent.type) {
        case 'LINE': {
          const s1 = worldToScreen(ent.p1);
          const s2 = worldToScreen(ent.p2);
          ctx.beginPath();
          ctx.moveTo(s1.x, s1.y);
          ctx.lineTo(s2.x, s2.y);
          ctx.stroke();
          break;
        }

        case 'RECTANGLE': {
          const s1 = worldToScreen(ent.p1);
          const s2 = worldToScreen(ent.p2);
          const rx = Math.min(s1.x, s2.x);
          const ry = Math.min(s1.y, s2.y);
          const rw = Math.abs(s1.x - s2.x);
          const rh = Math.abs(s1.y - s2.y);
          ctx.strokeRect(rx, ry, rw, rh);
          break;
        }

        case 'CIRCLE': {
          const sc = worldToScreen(ent.center);
          const sr = ent.radius * viewport.zoom;
          ctx.beginPath();
          ctx.arc(sc.x, sc.y, Math.max(1, sr), 0, Math.PI * 2);
          ctx.stroke();
          break;
        }

        case 'ARC': {
          const sc = worldToScreen(ent.center);
          const sr = ent.radius * viewport.zoom;
          // Canvas angles are clockwise with Y-down, CAD angles are counter-clockwise with Y-up
          const canvasStart = -ent.startAngle;
          const canvasEnd = -ent.endAngle;
          ctx.beginPath();
          ctx.arc(sc.x, sc.y, Math.max(1, sr), canvasStart, canvasEnd, true);
          ctx.stroke();
          break;
        }

        case 'LWPOLYLINE': {
          if (!ent.points.length) break;
          ctx.beginPath();
          const p0 = worldToScreen(ent.points[0]);
          ctx.moveTo(p0.x, p0.y);
          for (let i = 1; i < ent.points.length; i++) {
            const pi = worldToScreen(ent.points[i]);
            ctx.lineTo(pi.x, pi.y);
          }
          if (ent.closed) ctx.closePath();
          ctx.stroke();
          break;
        }

        case 'POLYGON': {
          const sc = worldToScreen(ent.center);
          const sr = ent.radius * viewport.zoom;
          ctx.beginPath();
          for (let i = 0; i < ent.sides; i++) {
            const a = (i * 2 * Math.PI) / ent.sides - Math.PI / 2;
            const px = sc.x + sr * Math.cos(a);
            const py = sc.y + sr * Math.sin(a);
            if (i === 0) ctx.moveTo(px, py);
            else ctx.lineTo(px, py);
          }
          ctx.closePath();
          ctx.stroke();
          break;
        }

        case 'ELLIPSE': {
          const sc = worldToScreen(ent.center);
          const srx = ent.rx * viewport.zoom;
          const sry = ent.ry * viewport.zoom;
          ctx.beginPath();
          ctx.ellipse(sc.x, sc.y, Math.max(1, srx), Math.max(1, sry), -ent.rotation, 0, Math.PI * 2);
          ctx.stroke();
          break;
        }

        case 'POINT': {
          const sp = worldToScreen(ent.point);
          ctx.beginPath();
          ctx.arc(sp.x, sp.y, 3, 0, Math.PI * 2);
          ctx.fill();
          // Cross mark
          ctx.beginPath();
          ctx.moveTo(sp.x - 5, sp.y);
          ctx.lineTo(sp.x + 5, sp.y);
          ctx.moveTo(sp.x, sp.y - 5);
          ctx.lineTo(sp.x, sp.y + 5);
          ctx.stroke();
          break;
        }

        case 'TEXT': {
          const sp = worldToScreen(ent.position);
          const fontPx = Math.max(8, ent.height * viewport.zoom);
          ctx.font = `${fontPx}px monospace`;
          ctx.save();
          ctx.translate(sp.x, sp.y);
          ctx.rotate((-ent.rotation * Math.PI) / 180);
          ctx.fillText(ent.text, 0, 0);
          ctx.restore();
          break;
        }

        case 'DIMENSION': {
          const s1 = worldToScreen(ent.p1);
          const s2 = worldToScreen(ent.p2);
          const soff = worldToScreen(ent.offsetPt);
          const distVal = cadMath.dist(ent.p1, ent.p2);
          const label = `${ent.prefix || ''}${Math.round(distVal)}${ent.suffix || ''}`;

          // Extension lines
          ctx.lineWidth = 1;
          ctx.setLineDash([]);
          ctx.beginPath();
          // Ext line 1
          ctx.moveTo(s1.x, s1.y);
          ctx.lineTo(s1.x, soff.y);
          // Ext line 2
          ctx.moveTo(s2.x, s2.y);
          ctx.lineTo(s2.x, soff.y);
          // Dimension line
          ctx.moveTo(s1.x, soff.y);
          ctx.lineTo(s2.x, soff.y);
          ctx.stroke();

          // Arrowheads
          const arrowLen = 8;
          ctx.beginPath();
          ctx.moveTo(s1.x, soff.y);
          ctx.lineTo(s1.x + arrowLen, soff.y - 3);
          ctx.lineTo(s1.x + arrowLen, soff.y + 3);
          ctx.closePath();
          ctx.fill();

          ctx.beginPath();
          ctx.moveTo(s2.x, soff.y);
          ctx.lineTo(s2.x - arrowLen, soff.y - 3);
          ctx.lineTo(s2.x - arrowLen, soff.y + 3);
          ctx.closePath();
          ctx.fill();

          // Text label
          ctx.font = `${Math.max(10, 11 * viewport.zoom)}px monospace`;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'bottom';
          ctx.fillText(label, (s1.x + s2.x) / 2, soff.y - 4);
          break;
        }

        case 'HATCH': {
          if (ent.boundary.length >= 3) {
            ctx.save();
            ctx.beginPath();
            const b0 = worldToScreen(ent.boundary[0]);
            ctx.moveTo(b0.x, b0.y);
            for (let i = 1; i < ent.boundary.length; i++) {
              const bi = worldToScreen(ent.boundary[i]);
              ctx.lineTo(bi.x, bi.y);
            }
            ctx.closePath();
            ctx.clip();

            // Diagonal hatch lines
            const bounds = cadMath.getEntityBounds(ent);
            const pitch = (ent.scale || 10) * viewport.zoom;
            ctx.strokeStyle = strokeColor;
            ctx.lineWidth = 0.8;
            ctx.beginPath();
            for (let d = -1000; d < 2000; d += pitch) {
              const pA = worldToScreen({ x: bounds.minX + d, y: bounds.minY - 500 });
              const pB = worldToScreen({ x: bounds.minX + d + 1000, y: bounds.minY + 500 });
              ctx.moveTo(pA.x, pA.y);
              ctx.lineTo(pB.x, pB.y);
            }
            ctx.stroke();
            ctx.restore();
          }
          break;
        }

        default:
          break;
      }

      ctx.restore();
    });

    // 5. Render Grips for Selected Objects
    selectedIds.forEach((selId) => {
      const ent = entities.find((e) => e.id === selId);
      if (!ent) return;
      const gripSize = 6;

      const drawGrip = (pt: Point2D, type: string, index: number) => {
        const sp = worldToScreen(pt);
        const isHover = hoverGrip && hoverGrip.entityId === ent.id && hoverGrip.index === index;
        const isActive = activeGrip && activeGrip.entityId === ent.id && activeGrip.index === index;

        ctx.fillStyle = isActive ? '#ef4444' : isHover ? '#f59e0b' : '#38bdf8';
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1;
        ctx.fillRect(sp.x - gripSize / 2, sp.y - gripSize / 2, gripSize, gripSize);
        ctx.strokeRect(sp.x - gripSize / 2, sp.y - gripSize / 2, gripSize, gripSize);
      };

      if (ent.type === 'LINE') {
        drawGrip(ent.p1, 'p1', 0);
        drawGrip(cadMath.midpoint(ent.p1, ent.p2), 'mid', 1);
        drawGrip(ent.p2, 'p2', 2);
      } else if (ent.type === 'CIRCLE') {
        drawGrip(ent.center, 'center', 0);
        drawGrip({ x: ent.center.x + ent.radius, y: ent.center.y }, 'quad', 1);
      } else if (ent.type === 'RECTANGLE') {
        const minX = Math.min(ent.p1.x, ent.p2.x);
        const maxX = Math.max(ent.p1.x, ent.p2.x);
        const minY = Math.min(ent.p1.y, ent.p2.y);
        const maxY = Math.max(ent.p1.y, ent.p2.y);
        drawGrip({ x: minX, y: minY }, 'c1', 0);
        drawGrip({ x: maxX, y: minY }, 'c2', 1);
        drawGrip({ x: maxX, y: maxY }, 'c3', 2);
        drawGrip({ x: minX, y: maxY }, 'c4', 3);
        drawGrip({ x: (minX + maxX) / 2, y: (minY + maxY) / 2 }, 'center', 4);
      }
    });

    // 6. Tool Live Rubber-band Previews
    if (toolPoints.length > 0) {
      ctx.save();
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 1.2;
      ctx.setLineDash([4, 4]);

      const basePt = toolPoints[0];
      const p1Screen = worldToScreen(basePt);
      const curScreen = worldToScreen(cursorPos);

      switch (activeTool) {
        case 'line':
        case 'ray':
        case 'xline': {
          ctx.beginPath();
          ctx.moveTo(p1Screen.x, p1Screen.y);
          ctx.lineTo(curScreen.x, curScreen.y);
          ctx.stroke();
          break;
        }

        case 'polyline': {
          ctx.beginPath();
          const pStart = worldToScreen(toolPoints[0]);
          ctx.moveTo(pStart.x, pStart.y);
          for (let i = 1; i < toolPoints.length; i++) {
            const p = worldToScreen(toolPoints[i]);
            ctx.lineTo(p.x, p.y);
          }
          ctx.lineTo(curScreen.x, curScreen.y);
          ctx.stroke();
          break;
        }

        case 'circle': {
          const r = cadMath.dist(basePt, cursorPos) * viewport.zoom;
          ctx.beginPath();
          ctx.arc(p1Screen.x, p1Screen.y, Math.max(1, r), 0, Math.PI * 2);
          ctx.stroke();
          break;
        }

        case 'rectangle': {
          const rx = Math.min(p1Screen.x, curScreen.x);
          const ry = Math.min(p1Screen.y, curScreen.y);
          const rw = Math.abs(p1Screen.x - curScreen.x);
          const rh = Math.abs(p1Screen.y - curScreen.y);
          ctx.strokeRect(rx, ry, rw, rh);
          break;
        }

        case 'dimension_linear':
        case 'dimension_aligned': {
          if (toolPoints.length === 1) {
            ctx.beginPath();
            ctx.moveTo(p1Screen.x, p1Screen.y);
            ctx.lineTo(curScreen.x, curScreen.y);
            ctx.stroke();
          } else if (toolPoints.length === 2) {
            const p2Screen = worldToScreen(toolPoints[1]);
            ctx.beginPath();
            ctx.moveTo(p1Screen.x, curScreen.y);
            ctx.lineTo(p2Screen.x, curScreen.y);
            ctx.stroke();
          }
          break;
        }

        case 'move':
        case 'copy': {
          const dx = cursorPos.x - basePt.x;
          const dy = cursorPos.y - basePt.y;
          ctx.beginPath();
          ctx.moveTo(p1Screen.x, p1Screen.y);
          ctx.lineTo(curScreen.x, curScreen.y);
          ctx.stroke();
          break;
        }

        default:
          break;
      }
      ctx.restore();
    }

    // 7. Render Selection Window Box (Blue window vs Green crossing)
    if (selectionBox) {
      const s1 = worldToScreen(selectionBox.start);
      const s2 = worldToScreen(selectionBox.current);
      const rx = Math.min(s1.x, s2.x);
      const ry = Math.min(s1.y, s2.y);
      const rw = Math.abs(s1.x - s2.x);
      const rh = Math.abs(s1.y - s2.y);

      const isCrossing = selectionBox.current.x < selectionBox.start.x;

      ctx.save();
      if (isCrossing) {
        // Crossing Selection (Green with dashed border)
        ctx.fillStyle = 'rgba(34, 197, 94, 0.15)';
        ctx.strokeStyle = '#22c55e';
        ctx.lineWidth = 1.2;
        ctx.setLineDash([4, 4]);
      } else {
        // Window Selection (Blue with solid border)
        ctx.fillStyle = 'rgba(56, 189, 248, 0.15)';
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 1.2;
        ctx.setLineDash([]);
      }
      ctx.fillRect(rx, ry, rw, rh);
      ctx.strokeRect(rx, ry, rw, rh);
      ctx.restore();
    }

    // 8. Snap Glyph
    if (activeSnap) {
      snappingEngine.renderSnapGlyph(ctx, activeSnap, worldToScreen);
    }

    // 9. Full AutoCAD Crosshairs + Pickbox
    const curScreen = worldToScreen(cursorPos);
    const pickboxSize = 7; // half size in px
    ctx.save();
    ctx.strokeStyle = '#a1a1aa';
    ctx.lineWidth = 1;

    // Center Pickbox square
    ctx.strokeRect(
      curScreen.x - pickboxSize,
      curScreen.y - pickboxSize,
      pickboxSize * 2,
      pickboxSize * 2
    );

    // Crosshair lines
    ctx.beginPath();
    ctx.moveTo(0, curScreen.y);
    ctx.lineTo(curScreen.x - pickboxSize, curScreen.y);
    ctx.moveTo(curScreen.x + pickboxSize, curScreen.y);
    ctx.lineTo(rect.width, curScreen.y);

    ctx.moveTo(curScreen.x, 0);
    ctx.lineTo(curScreen.x, curScreen.y - pickboxSize);
    ctx.moveTo(curScreen.x, curScreen.y + pickboxSize);
    ctx.lineTo(curScreen.x, rect.height);
    ctx.stroke();

    // 10. Dynamic Input HUD next to cursor
    if (dynamicInput && toolPoints.length > 0) {
      const base = toolPoints[toolPoints.length - 1];
      const d = cadMath.dist(base, cursorPos);
      const a = cadMath.angleDeg(base, cursorPos);

      const hudX = curScreen.x + 18;
      const hudY = curScreen.y + 18;
      const hudText = `L: ${d.toFixed(1)} ${units}  < ${a.toFixed(1)}°`;

      ctx.fillStyle = 'rgba(24, 24, 27, 0.88)';
      ctx.strokeStyle = '#52525b';
      ctx.lineWidth = 1;
      const textWidth = ctx.measureText(hudText).width + 16;
      ctx.fillRect(hudX, hudY - 14, textWidth, 22);
      ctx.strokeRect(hudX, hudY - 14, textWidth, 22);

      ctx.fillStyle = '#38bdf8';
      ctx.font = '11px monospace';
      ctx.fillText(hudText, hudX + 8, hudY + 2);
    }

    // 11. UCS Icon in bottom-left corner
    const ucsX = 36;
    const ucsY = rect.height - 36;
    ctx.strokeStyle = '#ef4444';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(ucsX, ucsY);
    ctx.lineTo(ucsX + 24, ucsY);
    ctx.stroke();

    ctx.strokeStyle = '#22c55e';
    ctx.beginPath();
    ctx.moveTo(ucsX, ucsY);
    ctx.lineTo(ucsX, ucsY - 24);
    ctx.stroke();

    ctx.fillStyle = '#ffffff';
    ctx.font = '10px monospace';
    ctx.fillText('X', ucsX + 28, ucsY + 4);
    ctx.fillText('Y', ucsX - 3, ucsY - 28);
    ctx.fillText('WCS', ucsX - 10, ucsY + 16);

    ctx.restore();
  }, [
    viewport,
    entities,
    layers,
    selectedIds,
    activeTool,
    toolPoints,
    cursorPos,
    activeSnap,
    gridSettings,
    selectionBox,
    hoverGrip,
    activeGrip,
    dynamicInput,
    units,
    worldToScreen,
    screenToWorld,
  ]);

  // Handle pointer movements for crosshairs, snapping, ortho, and polar tracking
  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const mouseScreen = { x: e.clientX - rect.left, y: e.clientY - rect.top };

    // Pan viewport if dragging with middle mouse button or in pan mode
    if (isPanningRef.current) {
      const dx = mouseScreen.x - panStartRef.current.x;
      const dy = mouseScreen.y - panStartRef.current.y;
      setViewport({
        zoom: viewport.zoom,
        panX: viewportStartRef.current.panX + dx,
        panY: viewportStartRef.current.panY + dy,
      });
      return;
    }

    let worldPt = screenToWorld(mouseScreen);

    // Check Snapping
    const toleranceScreen = 14;
    const toleranceWorld = toleranceScreen / viewport.zoom;
    const basePt = toolPoints.length > 0 ? toolPoints[toolPoints.length - 1] : undefined;

    const snap = snappingEngine.findSnapPoint(
      worldPt,
      entities,
      snapSettings,
      toleranceWorld,
      basePt,
      gridSettings.size
    );

    setActiveSnap(snap);

    if (snap) {
      worldPt = snap.point;
    } else if (basePt) {
      // Ortho mode (F8)
      if (orthoMode) {
        worldPt = cadMath.applyOrtho(basePt, worldPt);
      }
      // Polar tracking (F10)
      else if (polarTracking) {
        const polarResult = cadMath.applyPolarTracking(basePt, worldPt, polarAngleStep);
        if (polarResult.snapped) {
          worldPt = polarResult.point;
        }
      }
    }

    setCursorPos(worldPt);

    // Update selection box if active
    if (selectionBox) {
      setSelectionBox({ start: selectionBox.start, current: worldPt });
    }
  };

  // Pointer Down (clicks & drags)
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const mouseScreen = { x: e.clientX - rect.left, y: e.clientY - rect.top };

    // Middle click OR Pan tool OR Spacebar = Pan
    if (e.button === 1 || activeTool === 'pan' || isSpacePressedRef.current) {
      isPanningRef.current = true;
      panStartRef.current = mouseScreen;
      viewportStartRef.current = { panX: viewport.panX, panY: viewport.panY };
      return;
    }

    if (e.button !== 0) return; // Only primary click for drafting

    const clickWorld = activeSnap ? activeSnap.point : cursorPos;

    // If active tool is 'select'
    if (activeTool === 'select') {
      // Test if clicking an existing entity
      const tolWorld = 6 / viewport.zoom;
      const hitEntity = entities.find((ent) => cadMath.isPointNearEntity(clickWorld, ent, tolWorld));

      if (hitEntity) {
        toggleSelectEntity(hitEntity.id, e.shiftKey);
        setCommandFeedback(`Selected: ${hitEntity.type} [${hitEntity.id}]`);
      } else {
        // Start window selection box
        setSelectionBox({ start: clickWorld, current: clickWorld });
      }
      return;
    }

    // Drafting Tool execution
    handleDraftStep(clickWorld);
  };

  // Step-by-step drafting dispatcher
  const handleDraftStep = (pt: Point2D) => {
    const newPoints = [...toolPoints, pt];

    switch (activeTool) {
      case 'line': {
        if (newPoints.length === 1) {
          setToolPoints(newPoints);
          setCommandPrompt('LINE Specify next point:');
        } else if (newPoints.length === 2) {
          const line: LineEntity = {
            id: `line_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
            type: 'LINE',
            layer: activeLayerId,
            p1: newPoints[0],
            p2: newPoints[1],
          };
          addEntity(line);
          // Auto-chain for AutoCAD continuous line workflow!
          setToolPoints([newPoints[1]]);
          setCommandPrompt('LINE Specify next point or press ESC to finish:');
        }
        break;
      }

      case 'polyline': {
        setToolPoints(newPoints);
        setCommandPrompt(`PLINE Specify next point (${newPoints.length} points) or double click:`);
        break;
      }

      case 'circle': {
        if (newPoints.length === 1) {
          setToolPoints(newPoints);
          setCommandPrompt('CIRCLE Specify radius of circle:');
        } else if (newPoints.length === 2) {
          const r = cadMath.dist(newPoints[0], newPoints[1]);
          const circle: CircleEntity = {
            id: `circle_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
            type: 'CIRCLE',
            layer: activeLayerId,
            center: newPoints[0],
            radius: Math.max(1, r),
          };
          addEntity(circle);
          setToolPoints([]);
          setCommandPrompt('Command:');
          setActiveTool('select');
        }
        break;
      }

      case 'rectangle': {
        if (newPoints.length === 1) {
          setToolPoints(newPoints);
          setCommandPrompt('RECTANG Specify other corner:');
        } else if (newPoints.length === 2) {
          const rect: RectEntity = {
            id: `rect_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
            type: 'RECTANGLE',
            layer: activeLayerId,
            p1: newPoints[0],
            p2: newPoints[1],
          };
          addEntity(rect);
          setToolPoints([]);
          setCommandPrompt('Command:');
          setActiveTool('select');
        }
        break;
      }

      case 'arc': {
        if (newPoints.length < 3) {
          setToolPoints(newPoints);
          setCommandPrompt(`ARC Specify ${newPoints.length === 1 ? 'second point' : 'end point'}:`);
        } else {
          // 3-point arc calculation
          const [p1, p2, p3] = newPoints;
          const mid1 = cadMath.midpoint(p1, p2);
          const mid2 = cadMath.midpoint(p2, p3);
          const d1 = cadMath.sub(p2, p1);
          const d2 = cadMath.sub(p3, p2);
          const center = cadMath.lineIntersection(
            mid1,
            { x: mid1.x - d1.y, y: mid1.y + d1.x },
            mid2,
            { x: mid2.x - d2.y, y: mid2.y + d2.x },
            false
          );
          if (center) {
            const r = cadMath.dist(center, p1);
            let a1 = Math.atan2(p1.y - center.y, p1.x - center.x);
            let a3 = Math.atan2(p3.y - center.y, p3.x - center.x);
            if (a1 < 0) a1 += Math.PI * 2;
            if (a3 < 0) a3 += Math.PI * 2;
            const arc: ArcEntity = {
              id: `arc_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
              type: 'ARC',
              layer: activeLayerId,
              center,
              radius: r,
              startAngle: a1,
              endAngle: a3,
            };
            addEntity(arc);
          }
          setToolPoints([]);
          setCommandPrompt('Command:');
          setActiveTool('select');
        }
        break;
      }

      case 'point': {
        addEntity({
          id: `pt_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
          type: 'POINT',
          layer: activeLayerId,
          point: pt,
        });
        setCommandFeedback(`Point placed at (${pt.x.toFixed(1)}, ${pt.y.toFixed(1)})`);
        break;
      }

      case 'text': {
        setTextPromptPos(pt);
        break;
      }

      case 'dimension_linear':
      case 'dimension_aligned': {
        if (newPoints.length === 1) {
          setToolPoints(newPoints);
          setCommandPrompt('DIMLIN Specify second extension line origin:');
        } else if (newPoints.length === 2) {
          setToolPoints(newPoints);
          setCommandPrompt('DIMLIN Specify dimension line location:');
        } else if (newPoints.length === 3) {
          const dim: DimensionEntity = {
            id: `dim_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
            type: 'DIMENSION',
            layer: activeLayerId,
            dimType: activeTool === 'dimension_linear' ? 'LINEAR' : 'ALIGNED',
            p1: newPoints[0],
            p2: newPoints[1],
            offsetPt: newPoints[2],
            suffix: ` ${units}`,
          };
          addEntity(dim);
          setToolPoints([]);
          setCommandPrompt('Command:');
          setActiveTool('select');
        }
        break;
      }

      case 'move':
      case 'copy': {
        if (newPoints.length === 1) {
          setToolPoints(newPoints);
          setCommandPrompt(`${activeTool.toUpperCase()} Specify second point:`);
        } else if (newPoints.length === 2) {
          const dx = newPoints[1].x - newPoints[0].x;
          const dy = newPoints[1].y - newPoints[0].y;
          const isCopy = activeTool === 'copy';

          selectedIds.forEach((id) => {
            const ent = entities.find((e) => e.id === id);
            if (!ent) return;
            if (ent.type === 'LINE') {
              const updated = {
                ...ent,
                id: isCopy ? `line_${Date.now()}_${Math.random().toString(36).substr(2, 4)}` : ent.id,
                p1: { x: ent.p1.x + dx, y: ent.p1.y + dy },
                p2: { x: ent.p2.x + dx, y: ent.p2.y + dy },
              };
              if (isCopy) addEntity(updated);
              else updateEntity(ent.id, updated);
            } else if (ent.type === 'CIRCLE' || ent.type === 'ARC') {
              const updated = {
                ...ent,
                id: isCopy ? `circ_${Date.now()}_${Math.random().toString(36).substr(2, 4)}` : ent.id,
                center: { x: ent.center.x + dx, y: ent.center.y + dy },
              };
              if (isCopy) addEntity(updated);
              else updateEntity(ent.id, updated);
            } else if (ent.type === 'RECTANGLE') {
              const updated = {
                ...ent,
                id: isCopy ? `rect_${Date.now()}_${Math.random().toString(36).substr(2, 4)}` : ent.id,
                p1: { x: ent.p1.x + dx, y: ent.p1.y + dy },
                p2: { x: ent.p2.x + dx, y: ent.p2.y + dy },
              };
              if (isCopy) addEntity(updated);
              else updateEntity(ent.id, updated);
            }
          });

          setToolPoints([]);
          setCommandPrompt('Command:');
          setActiveTool('select');
          setCommandFeedback(`${activeTool.toUpperCase()} completed.`);
        }
        break;
      }

      case 'dist': {
        if (newPoints.length === 1) {
          setToolPoints(newPoints);
          setCommandPrompt('DIST Specify second point:');
        } else if (newPoints.length === 2) {
          const d = cadMath.dist(newPoints[0], newPoints[1]);
          const dx = Math.abs(newPoints[1].x - newPoints[0].x);
          const dy = Math.abs(newPoints[1].y - newPoints[0].y);
          const ang = cadMath.angleDeg(newPoints[0], newPoints[1]);
          setCommandFeedback(`Distance = ${d.toFixed(2)}${units}, Delta X = ${dx.toFixed(2)}, Delta Y = ${dy.toFixed(2)}, Angle = ${ang.toFixed(2)}°`);
          setToolPoints([]);
          setActiveTool('select');
        }
        break;
      }

      default:
        break;
    }
  };

  // Pointer Up (finish panning, finish selection window)
  const handlePointerUp = () => {
    isPanningRef.current = false;

    // Finish window selection
    if (selectionBox) {
      const minX = Math.min(selectionBox.start.x, selectionBox.current.x);
      const maxX = Math.max(selectionBox.start.x, selectionBox.current.x);
      const minY = Math.min(selectionBox.start.y, selectionBox.current.y);
      const maxY = Math.max(selectionBox.start.y, selectionBox.current.y);
      const isCrossing = selectionBox.current.x < selectionBox.start.x;

      const hitIds: string[] = [];
      entities.forEach((ent) => {
        if (cadMath.isEntityInBox(ent, { minX, minY, maxX, maxY }, isCrossing)) {
          hitIds.push(ent.id);
        }
      });

      setSelectedIds(hitIds);
      setCommandFeedback(hitIds.length ? `Selected ${hitIds.length} object(s).` : 'No objects selected.');
      setSelectionBox(null);
    }
  };

  // Mouse wheel zoom around pointer
  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const mouseScreen = { x: e.clientX - rect.left, y: e.clientY - rect.top };

    const zoomFactor = e.deltaY < 0 ? 1.15 : 0.87;
    const newZoom = Math.max(0.02, Math.min(50, viewport.zoom * zoomFactor));

    // Keep world coordinate under cursor static while zooming
    const mouseWorldBefore = screenToWorld(mouseScreen);
    const newPanX = mouseScreen.x - mouseWorldBefore.x * newZoom;
    const newPanY = mouseScreen.y + mouseWorldBefore.y * newZoom;

    setViewport({
      zoom: newZoom,
      panX: newPanX,
      panY: newPanY,
    });
  };

  // Double click finishes polyline
  const handleDoubleClick = () => {
    if (activeTool === 'polyline' && toolPoints.length >= 2) {
      const poly: PolylineEntity = {
        id: `poly_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
        type: 'LWPOLYLINE',
        layer: activeLayerId,
        points: toolPoints,
        closed: false,
      };
      addEntity(poly);
      setToolPoints([]);
      setActiveTool('select');
      setCommandPrompt('Command:');
      setCommandFeedback('PLINE finished.');
    }
  };

  return (
    <div ref={containerRef} className="relative w-full h-full overflow-hidden select-none bg-zinc-950">
      <canvas
        ref={canvasRef}
        className="w-full h-full block cursor-none"
        onPointerMove={handlePointerMove}
        onPointerDown={handlePointerDown}
        onPointerUp={handlePointerUp}
        onWheel={handleWheel}
        onDoubleClick={handleDoubleClick}
      />

      {/* Floating Canvas Quick Viewport Controls */}
      <div className="absolute top-4 right-4 flex flex-col gap-1.5 bg-zinc-900/90 border border-zinc-700/70 p-1.5 rounded-lg shadow-2xl backdrop-blur-sm z-10">
        <button
          onClick={zoomExtents}
          title="Zoom Extents (Z + E)"
          className="p-2 text-zinc-300 hover:text-white hover:bg-zinc-800 rounded transition"
        >
          <span className="text-xs font-semibold">⤢ Extents</span>
        </button>
        <button
          onClick={() => setViewport((v) => ({ ...v, zoom: v.zoom * 1.3 }))}
          title="Zoom In"
          className="p-1.5 text-zinc-300 hover:text-white hover:bg-zinc-800 rounded text-center font-bold"
        >
          +
        </button>
        <button
          onClick={() => setViewport((v) => ({ ...v, zoom: v.zoom * 0.77 }))}
          title="Zoom Out"
          className="p-1.5 text-zinc-300 hover:text-white hover:bg-zinc-800 rounded text-center font-bold"
        >
          −
        </button>
      </div>

      {/* Coordinate & Status Overlay Display in Canvas */}
      <div className="absolute bottom-3 left-3 bg-zinc-900/80 border border-zinc-800 px-3 py-1.5 rounded text-xs font-mono text-zinc-300 backdrop-blur-sm pointer-events-none flex items-center gap-3">
        <span className="text-sky-400 font-semibold">X: {cursorPos.x.toFixed(2)}</span>
        <span className="text-emerald-400 font-semibold">Y: {cursorPos.y.toFixed(2)}</span>
        <span className="text-zinc-500">Z: 0.00</span>
        <span className="text-zinc-400 border-l border-zinc-700 pl-2">Zoom: {(viewport.zoom * 100).toFixed(0)}%</span>
      </div>

      {/* Text creation input popup */}
      {textPromptPos && (
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-zinc-900 border border-zinc-700 p-4 rounded-lg shadow-2xl z-30 w-80">
          <h3 className="text-sm font-semibold text-zinc-100 mb-2">Create CAD Text Annotation</h3>
          <input
            type="text"
            value={textInputVal}
            onChange={(e) => setTextInputVal(e.target.value)}
            className="w-full bg-zinc-950 border border-zinc-700 rounded px-2.5 py-1.5 text-sm text-zinc-100 mb-3 focus:outline-none focus:border-sky-500 font-mono"
            placeholder="Enter text..."
            autoFocus
          />
          <div className="flex justify-end gap-2">
            <button
              onClick={() => setTextPromptPos(null)}
              className="px-3 py-1 text-xs text-zinc-400 hover:text-zinc-200"
            >
              Cancel
            </button>
            <button
              onClick={() => {
                if (textInputVal.trim()) {
                  addEntity({
                    id: `text_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
                    type: 'TEXT',
                    layer: activeLayerId,
                    position: textPromptPos,
                    text: textInputVal,
                    height: 20,
                    rotation: 0,
                  });
                  setCommandFeedback(`Created text: "${textInputVal}"`);
                }
                setTextPromptPos(null);
                setActiveTool('select');
              }}
              className="px-3 py-1 bg-sky-600 hover:bg-sky-500 text-xs font-medium text-white rounded"
            >
              Place Text
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
