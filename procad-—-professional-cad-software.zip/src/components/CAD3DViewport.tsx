/**
 * ProCAD - 3D Solid Modeling Workspace (Three.js)
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { useCAD } from '../context/CADContext';
import { Solid3DEntity, Solid3DShape } from '../types/cad';

export const CAD3DViewport: React.FC = () => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasMountRef = useRef<HTMLDivElement | null>(null);

  const { solids3d, addSolid3D, updateSolid3D, deleteSolid3D, setViewMode } = useCAD();

  const [selectedSolidId, setSelectedSolidId] = useState<string | null>(null);
  const [shadingMode, setShadingMode] = useState<'shaded' | 'wireframe' | 'shaded_edges'>('shaded_edges');
  const [cameraType, setCameraType] = useState<'perspective' | 'orthographic'>('perspective');

  // Three.js internal references
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const perspCameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const orthoCameraRef = useRef<THREE.OrthographicCamera | null>(null);
  const activeCameraRef = useRef<THREE.Camera | null>(null);
  const meshGroupRef = useRef<THREE.Group | null>(null);
  const edgesGroupRef = useRef<THREE.Group | null>(null);

  // Orbit state
  const orbitStateRef = useRef({
    isOrbiting: false,
    isPanning: false,
    prevMouse: { x: 0, y: 0 },
    radius: 350,
    theta: Math.PI / 4,
    phi: Math.PI / 3,
    target: new THREE.Vector3(0, 0, 0),
  });

  const updateCameraPosition = useCallback(() => {
    const { radius, theta, phi, target } = orbitStateRef.current;
    const x = target.x + radius * Math.sin(phi) * Math.sin(theta);
    const y = target.y + radius * Math.cos(phi);
    const z = target.z + radius * Math.sin(phi) * Math.cos(theta);

    if (perspCameraRef.current) {
      perspCameraRef.current.position.set(x, y, z);
      perspCameraRef.current.lookAt(target);
    }

    if (orthoCameraRef.current) {
      orthoCameraRef.current.position.set(x, y, z);
      orthoCameraRef.current.lookAt(target);
    }
  }, []);

  // Set predefined camera viewpoint (AutoCAD style: Top, Front, Right, Iso)
  const setPresetView = (view: 'top' | 'front' | 'right' | 'left' | 'iso') => {
    const orbit = orbitStateRef.current;
    switch (view) {
      case 'top':
        orbit.theta = 0;
        orbit.phi = 0.001; // Avoid exact gimbal lock
        break;
      case 'front':
        orbit.theta = 0;
        orbit.phi = Math.PI / 2;
        break;
      case 'right':
        orbit.theta = Math.PI / 2;
        orbit.phi = Math.PI / 2;
        break;
      case 'left':
        orbit.theta = -Math.PI / 2;
        orbit.phi = Math.PI / 2;
        break;
      case 'iso':
        orbit.theta = Math.PI / 4;
        orbit.phi = Math.PI / 3;
        break;
    }
    updateCameraPosition();
  };

  // Initialize Three.js scene once
  useEffect(() => {
    const container = containerRef.current;
    const mount = canvasMountRef.current;
    if (!container || !mount) return;

    const width = container.clientWidth;
    const height = container.clientHeight;

    // Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x18181b); // Dark CAD engineering charcoal
    sceneRef.current = scene;

    // Perspective Camera
    const perspCamera = new THREE.PerspectiveCamera(45, width / height, 0.1, 5000);
    perspCameraRef.current = perspCamera;

    // Orthographic Camera
    const aspect = width / height;
    const orthoFrustum = 300;
    const orthoCamera = new THREE.OrthographicCamera(
      (-orthoFrustum * aspect) / 2,
      (orthoFrustum * aspect) / 2,
      orthoFrustum / 2,
      -orthoFrustum / 2,
      0.1,
      5000
    );
    orthoCameraRef.current = orthoCamera;

    activeCameraRef.current = cameraType === 'perspective' ? perspCamera : orthoCamera;
    updateCameraPosition();

    // WebGL Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    rendererRef.current = renderer;

    mount.appendChild(renderer.domElement);

    // Studio Lighting Rig
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.85);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xffffff, 1.4);
    keyLight.position.set(200, 300, 250);
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0x93c5fd, 0.7);
    fillLight.position.set(-200, 150, -200);
    scene.add(fillLight);

    // 3D Grid Floor
    const gridHelper = new THREE.GridHelper(500, 50, 0x52525b, 0x27272a);
    gridHelper.position.y = 0;
    scene.add(gridHelper);

    // Axes Helper (Red=X, Green=Y, Blue=Z)
    const axesHelper = new THREE.AxesHelper(80);
    scene.add(axesHelper);

    // Mesh group & Edges group
    const meshGroup = new THREE.Group();
    meshGroupRef.current = meshGroup;
    scene.add(meshGroup);

    const edgesGroup = new THREE.Group();
    edgesGroupRef.current = edgesGroup;
    scene.add(edgesGroup);

    // Render loop
    let animId: number;
    const animate = () => {
      animId = requestAnimationFrame(animate);
      if (rendererRef.current && sceneRef.current && activeCameraRef.current) {
        rendererRef.current.render(sceneRef.current, activeCameraRef.current);
      }
    };
    animate();

    // Resize handler
    const handleResize = () => {
      if (!container || !rendererRef.current) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      const newAspect = w / h;

      if (perspCameraRef.current) {
        perspCameraRef.current.aspect = newAspect;
        perspCameraRef.current.updateProjectionMatrix();
      }

      if (orthoCameraRef.current) {
        orthoCameraRef.current.left = (-orthoFrustum * newAspect) / 2;
        orthoCameraRef.current.right = (orthoFrustum * newAspect) / 2;
        orthoCameraRef.current.top = orthoFrustum / 2;
        orthoCameraRef.current.bottom = -orthoFrustum / 2;
        orthoCameraRef.current.updateProjectionMatrix();
      }

      rendererRef.current.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      if (mount && renderer.domElement) {
        mount.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, []);

  // Update active camera on cameraType state change
  useEffect(() => {
    activeCameraRef.current = cameraType === 'perspective' ? perspCameraRef.current : orthoCameraRef.current;
    updateCameraPosition();
  }, [cameraType, updateCameraPosition]);

  // Re-build 3D Meshes whenever solids3d or shadingMode changes
  useEffect(() => {
    const meshGroup = meshGroupRef.current;
    const edgesGroup = edgesGroupRef.current;
    if (!meshGroup || !edgesGroup) return;

    // Clear existing meshes and geometries
    while (meshGroup.children.length > 0) {
      const obj = meshGroup.children[0] as THREE.Mesh;
      if (obj.geometry) obj.geometry.dispose();
      meshGroup.remove(obj);
    }
    while (edgesGroup.children.length > 0) {
      const obj = edgesGroup.children[0] as THREE.LineSegments;
      if (obj.geometry) obj.geometry.dispose();
      edgesGroup.remove(obj);
    }

    solids3d.forEach((solid) => {
      let geom: THREE.BufferGeometry;

      switch (solid.shape) {
        case 'BOX':
          geom = new THREE.BoxGeometry(
            solid.parameters.width || 60,
            solid.parameters.height || 60,
            solid.parameters.depth || 60
          );
          break;

        case 'CYLINDER':
          geom = new THREE.CylinderGeometry(
            solid.parameters.radiusTop || 30,
            solid.parameters.radiusBottom || 30,
            solid.parameters.height || 60,
            solid.parameters.segments || 32
          );
          break;

        case 'SPHERE':
          geom = new THREE.SphereGeometry(
            solid.parameters.radius || 35,
            solid.parameters.segments || 32,
            solid.parameters.segments || 24
          );
          break;

        case 'CONE':
          geom = new THREE.ConeGeometry(
            solid.parameters.radiusBottom || 30,
            solid.parameters.height || 60,
            solid.parameters.segments || 32
          );
          break;

        case 'TORUS':
          geom = new THREE.TorusGeometry(
            solid.parameters.radius || 40,
            solid.parameters.tube || 12,
            16,
            48
          );
          break;

        default:
          geom = new THREE.BoxGeometry(40, 40, 40);
          break;
      }

      // Material based on shadingMode
      const isWire = shadingMode === 'wireframe' || solid.wireframe;
      const isSelected = solid.id === selectedSolidId;

      const mat = new THREE.MeshStandardMaterial({
        color: new THREE.Color(isSelected ? 0x38bdf8 : solid.color || 0x0284c7),
        roughness: 0.35,
        metalness: 0.6,
        wireframe: isWire,
      });

      const mesh = new THREE.Mesh(geom, mat);
      mesh.position.set(solid.position.x, solid.position.z, solid.position.y); // Convert CAD Y-up to Three.js
      mesh.rotation.set(solid.rotation.x, solid.rotation.y, solid.rotation.z);
      mesh.scale.set(solid.scale.x, solid.scale.y, solid.scale.z);
      mesh.name = solid.id;

      meshGroup.add(mesh);

      // Add CAD sharp edge outlines if shaded_edges
      if (shadingMode === 'shaded_edges' && !isWire) {
        const edgeGeom = new THREE.EdgesGeometry(geom, 25);
        const edgeMat = new THREE.LineBasicMaterial({
          color: isSelected ? 0xffffff : 0x0f172a,
          linewidth: 1.5,
        });
        const edgeLine = new THREE.LineSegments(edgeGeom, edgeMat);
        edgeLine.position.copy(mesh.position);
        edgeLine.rotation.copy(mesh.rotation);
        edgeLine.scale.copy(mesh.scale);
        edgesGroup.add(edgeLine);
      }
    });
  }, [solids3d, shadingMode, selectedSolidId]);

  // Pointer interactions for Orbit and Pan
  const handlePointerDown = (e: React.PointerEvent) => {
    const orbit = orbitStateRef.current;
    orbit.prevMouse = { x: e.clientX, y: e.clientY };

    if (e.button === 0) {
      orbit.isOrbiting = true;
    } else if (e.button === 1 || e.button === 2) {
      orbit.isPanning = true;
    }
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    const orbit = orbitStateRef.current;
    const dx = e.clientX - orbit.prevMouse.x;
    const dy = e.clientY - orbit.prevMouse.y;
    orbit.prevMouse = { x: e.clientX, y: e.clientY };

    if (orbit.isOrbiting) {
      orbit.theta -= dx * 0.008;
      orbit.phi = Math.max(0.01, Math.min(Math.PI - 0.01, orbit.phi - dy * 0.008));
      updateCameraPosition();
    } else if (orbit.isPanning) {
      const panSpeed = orbit.radius * 0.0015;
      const right = new THREE.Vector3();
      if (activeCameraRef.current) {
        activeCameraRef.current.getWorldDirection(right);
        right.cross(new THREE.Vector3(0, 1, 0)).normalize();
      }
      orbit.target.addScaledVector(right, -dx * panSpeed);
      orbit.target.y += dy * panSpeed;
      updateCameraPosition();
    }
  };

  const handlePointerUp = () => {
    orbitStateRef.current.isOrbiting = false;
    orbitStateRef.current.isPanning = false;
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const orbit = orbitStateRef.current;
    const zoomDelta = e.deltaY * 0.4;
    orbit.radius = Math.max(20, Math.min(2500, orbit.radius + zoomDelta));
    updateCameraPosition();
  };

  // Add 3D Primitive helper
  const handleAddPrimitive = (shape: Solid3DShape) => {
    const solid: Solid3DEntity = {
      id: `solid_${shape.toLowerCase()}_${Date.now()}`,
      name: `3D ${shape}`,
      shape,
      position: { x: 0, y: 0, z: 25 },
      rotation: { x: 0, y: 0, z: 0 },
      scale: { x: 1, y: 1, z: 1 },
      parameters: {
        width: 50,
        height: 50,
        depth: 50,
        radius: 30,
        radiusTop: 25,
        radiusBottom: 25,
        tube: 10,
        segments: 32,
      },
      color: '#0284c7',
    };
    addSolid3D(solid);
    setSelectedSolidId(solid.id);
  };

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full overflow-hidden bg-zinc-950 select-none"
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onWheel={handleWheel}
      onContextMenu={(e) => e.preventDefault()}
    >
      {/* Three.js Canvas Mount */}
      <div ref={canvasMountRef} className="w-full h-full block cursor-grab active:cursor-grabbing" />

      {/* AutoCAD Style 3D ViewCube (Top-Right) */}
      <div className="absolute top-4 right-4 bg-zinc-900/90 border border-zinc-700/80 p-2 rounded-lg shadow-2xl backdrop-blur-sm z-20 flex flex-col items-center gap-1.5">
        <span className="text-[10px] uppercase font-bold text-zinc-400 tracking-wider">ViewCube</span>
        <div className="grid grid-cols-3 gap-1">
          <button
            onClick={() => setPresetView('top')}
            className="px-2 py-1 bg-zinc-800 hover:bg-sky-600 text-[11px] font-mono font-semibold text-zinc-200 rounded transition"
          >
            TOP
          </button>
          <button
            onClick={() => setPresetView('front')}
            className="px-2 py-1 bg-zinc-800 hover:bg-sky-600 text-[11px] font-mono font-semibold text-zinc-200 rounded transition"
          >
            FRONT
          </button>
          <button
            onClick={() => setPresetView('right')}
            className="px-2 py-1 bg-zinc-800 hover:bg-sky-600 text-[11px] font-mono font-semibold text-zinc-200 rounded transition"
          >
            RIGHT
          </button>
          <button
            onClick={() => setPresetView('left')}
            className="px-2 py-1 bg-zinc-800 hover:bg-sky-600 text-[11px] font-mono font-semibold text-zinc-200 rounded transition"
          >
            LEFT
          </button>
          <button
            onClick={() => setPresetView('iso')}
            className="col-span-2 px-2 py-1 bg-sky-700 hover:bg-sky-600 text-[11px] font-mono font-semibold text-white rounded transition"
          >
            ISOMETRIC (NE)
          </button>
        </div>
      </div>

      {/* 3D Top-Left View Controls Bar */}
      <div className="absolute top-4 left-4 flex items-center gap-2 bg-zinc-900/90 border border-zinc-800 p-1.5 rounded-lg shadow-xl backdrop-blur-sm z-20">
        <span className="text-xs font-semibold text-zinc-400 pl-2">Shading:</span>
        <select
          value={shadingMode}
          onChange={(e) => setShadingMode(e.target.value as any)}
          className="bg-zinc-800 border border-zinc-700 text-xs text-zinc-200 rounded px-2 py-1 focus:outline-none"
        >
          <option value="shaded_edges">Shaded with Edges</option>
          <option value="shaded">Shaded Realistic</option>
          <option value="wireframe">Wireframe</option>
        </select>

        <span className="text-xs font-semibold text-zinc-400 border-l border-zinc-700 pl-2">Camera:</span>
        <select
          value={cameraType}
          onChange={(e) => setCameraType(e.target.value as any)}
          className="bg-zinc-800 border border-zinc-700 text-xs text-zinc-200 rounded px-2 py-1 focus:outline-none"
        >
          <option value="perspective">Perspective</option>
          <option value="orthographic">Orthographic</option>
        </select>

        <button
          onClick={() => setViewMode('2D')}
          className="ml-2 px-3 py-1 bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-sky-400 rounded border border-zinc-700 transition"
        >
          ← Return to 2D
        </button>
      </div>

      {/* 3D Solid Primitives Creation Dock (Bottom Center) */}
      <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 flex items-center gap-2 bg-zinc-900/95 border border-zinc-700/80 p-2 rounded-xl shadow-2xl backdrop-blur-md z-20">
        <span className="text-xs font-bold text-zinc-400 px-2 uppercase tracking-wide">3D Solids:</span>
        <button
          onClick={() => handleAddPrimitive('BOX')}
          className="px-3 py-1.5 bg-zinc-800 hover:bg-sky-600 hover:text-white text-xs font-medium text-zinc-200 rounded transition flex items-center gap-1.5"
        >
          <span>📦</span> Box
        </button>
        <button
          onClick={() => handleAddPrimitive('CYLINDER')}
          className="px-3 py-1.5 bg-zinc-800 hover:bg-sky-600 hover:text-white text-xs font-medium text-zinc-200 rounded transition flex items-center gap-1.5"
        >
          <span>🛢️</span> Cylinder
        </button>
        <button
          onClick={() => handleAddPrimitive('SPHERE')}
          className="px-3 py-1.5 bg-zinc-800 hover:bg-sky-600 hover:text-white text-xs font-medium text-zinc-200 rounded transition flex items-center gap-1.5"
        >
          <span>🌐</span> Sphere
        </button>
        <button
          onClick={() => handleAddPrimitive('CONE')}
          className="px-3 py-1.5 bg-zinc-800 hover:bg-sky-600 hover:text-white text-xs font-medium text-zinc-200 rounded transition flex items-center gap-1.5"
        >
          <span>▲</span> Cone
        </button>
        <button
          onClick={() => handleAddPrimitive('TORUS')}
          className="px-3 py-1.5 bg-zinc-800 hover:bg-sky-600 hover:text-white text-xs font-medium text-zinc-200 rounded transition flex items-center gap-1.5"
        >
          <span>⭕</span> Torus
        </button>
      </div>

      {/* Selected 3D Object Inspector (if selected) */}
      {selectedSolidId && (
        <div className="absolute top-16 left-4 bg-zinc-900/95 border border-zinc-700 p-3 rounded-lg shadow-2xl z-20 w-64 text-xs font-mono">
          <div className="flex justify-between items-center mb-2">
            <span className="font-bold text-sky-400">3D Solid Properties</span>
            <button
              onClick={() => setSelectedSolidId(null)}
              className="text-zinc-500 hover:text-white"
            >
              ✕
            </button>
          </div>
          {(() => {
            const solid = solids3d.find((s) => s.id === selectedSolidId);
            if (!solid) return null;
            return (
              <div className="flex flex-col gap-2">
                <div>
                  <span className="text-zinc-400">Name:</span> {solid.name}
                </div>
                <div>
                  <span className="text-zinc-400">Shape:</span> {solid.shape}
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-zinc-400">Color:</span>
                  <input
                    type="color"
                    value={solid.color}
                    onChange={(e) => updateSolid3D(solid.id, { color: e.target.value })}
                    className="w-8 h-5 bg-transparent cursor-pointer rounded"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-zinc-400">Wireframe:</span>
                  <input
                    type="checkbox"
                    checked={!!solid.wireframe}
                    onChange={(e) => updateSolid3D(solid.id, { wireframe: e.target.checked })}
                    className="accent-sky-500"
                  />
                </div>
                <button
                  onClick={() => {
                    deleteSolid3D(solid.id);
                    setSelectedSolidId(null);
                  }}
                  className="mt-2 w-full py-1 bg-red-950 hover:bg-red-800 text-red-200 text-center rounded transition"
                >
                  Delete Solid
                </button>
              </div>
            );
          })()}
        </div>
      )}
    </div>
  );
};
