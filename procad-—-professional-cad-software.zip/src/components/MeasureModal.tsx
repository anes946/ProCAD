/**
 * ProCAD - Geometric Measurement & Engineering Calculation Tool
 */

import React, { useState } from 'react';
import { useCAD } from '../context/CADContext';
import { cadMath } from '../geometry/cadMath';

export const MeasureModal: React.FC = () => {
  const {
    isMeasureModalOpen,
    setIsMeasureModalOpen,
    units,
    selectedIds,
    entities,
  } = useCAD();

  const [p1x, setP1x] = useState('0');
  const [p1y, setP1y] = useState('0');
  const [p2x, setP2x] = useState('100');
  const [p2y, setP2y] = useState('100');

  if (!isMeasureModalOpen) return null;

  const pt1 = { x: parseFloat(p1x) || 0, y: parseFloat(p1y) || 0 };
  const pt2 = { x: parseFloat(p2x) || 0, y: parseFloat(p2y) || 0 };

  const distance = cadMath.dist(pt1, pt2);
  const deltaX = Math.abs(pt2.x - pt1.x);
  const deltaY = Math.abs(pt2.y - pt1.y);
  const angleDeg = cadMath.angleDeg(pt1, pt2);

  // Selected object metrics
  const selectedEnts = entities.filter((e) => selectedIds.includes(e.id));

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 select-none">
      <div className="bg-zinc-900 border border-zinc-700 rounded-xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col text-xs font-mono">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-zinc-950 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <span className="text-base">📐</span>
            <h2 className="text-sm font-bold text-zinc-100 tracking-wide font-sans">
              GEOMETRIC MEASURE & CALCULATION
            </h2>
          </div>
          <button
            onClick={() => setIsMeasureModalOpen(false)}
            className="text-zinc-400 hover:text-white p-1 rounded hover:bg-zinc-800 transition"
          >
            ✕
          </button>
        </div>

        <div className="p-4 flex flex-col gap-4 text-zinc-300">
          {/* Two-point measurement */}
          <div className="flex flex-col gap-2">
            <span className="text-[11px] font-bold text-sky-400 uppercase tracking-wider font-sans">
              Two-Point Vector Distance & Angle
            </span>
            <div className="grid grid-cols-2 gap-3 bg-zinc-950 p-3 rounded border border-zinc-800">
              <div>
                <span className="text-[10px] text-zinc-500 font-sans block mb-1">Point 1 (X, Y):</span>
                <div className="flex gap-1.5">
                  <input
                    type="number"
                    value={p1x}
                    onChange={(e) => setP1x(e.target.value)}
                    className="w-1/2 bg-zinc-800 border border-zinc-700 rounded px-1.5 py-1 text-white text-xs"
                    placeholder="X"
                  />
                  <input
                    type="number"
                    value={p1y}
                    onChange={(e) => setP1y(e.target.value)}
                    className="w-1/2 bg-zinc-800 border border-zinc-700 rounded px-1.5 py-1 text-white text-xs"
                    placeholder="Y"
                  />
                </div>
              </div>
              <div>
                <span className="text-[10px] text-zinc-500 font-sans block mb-1">Point 2 (X, Y):</span>
                <div className="flex gap-1.5">
                  <input
                    type="number"
                    value={p2x}
                    onChange={(e) => setP2x(e.target.value)}
                    className="w-1/2 bg-zinc-800 border border-zinc-700 rounded px-1.5 py-1 text-white text-xs"
                    placeholder="X"
                  />
                  <input
                    type="number"
                    value={p2y}
                    onChange={(e) => setP2y(e.target.value)}
                    className="w-1/2 bg-zinc-800 border border-zinc-700 rounded px-1.5 py-1 text-white text-xs"
                    placeholder="Y"
                  />
                </div>
              </div>
            </div>

            <div className="bg-zinc-950 p-3 rounded border border-zinc-800 flex flex-col gap-1.5">
              <div className="flex justify-between">
                <span className="text-zinc-400">Direct Distance:</span>
                <span className="text-white font-bold">{distance.toFixed(4)} {units}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">Angle in XY Plane:</span>
                <span className="text-white font-bold">{angleDeg.toFixed(2)}° ({(angleDeg * Math.PI / 180).toFixed(4)} rad)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">Delta X:</span>
                <span className="text-white font-bold">{deltaX.toFixed(4)} {units}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">Delta Y:</span>
                <span className="text-white font-bold">{deltaY.toFixed(4)} {units}</span>
              </div>
            </div>
          </div>

          {/* Selected Objects Geometry Analysis */}
          {selectedEnts.length > 0 && (
            <div className="flex flex-col gap-2">
              <span className="text-[11px] font-bold text-amber-400 uppercase tracking-wider font-sans">
                Selected Geometry Analysis ({selectedEnts.length} items)
              </span>
              <div className="bg-zinc-950 p-3 rounded border border-zinc-800 flex flex-col gap-1.5">
                {selectedEnts.map((e) => {
                  if (e.type === 'CIRCLE') {
                    return (
                      <div key={e.id} className="border-b border-zinc-800 pb-1">
                        Circle: Radius {e.radius.toFixed(2)}, Circumference {(2 * Math.PI * e.radius).toFixed(2)}, Area {(Math.PI * e.radius * e.radius).toFixed(2)} {units}²
                      </div>
                    );
                  }
                  if (e.type === 'RECTANGLE') {
                    const w = Math.abs(e.p2.x - e.p1.x);
                    const h = Math.abs(e.p2.y - e.p1.y);
                    return (
                      <div key={e.id} className="border-b border-zinc-800 pb-1">
                        Rect: {w.toFixed(1)} x {h.toFixed(1)} {units}, Area {(w * h).toFixed(2)} {units}², Perimeter {(2 * (w + h)).toFixed(2)} {units}
                      </div>
                    );
                  }
                  if (e.type === 'LINE') {
                    return (
                      <div key={e.id} className="border-b border-zinc-800 pb-1">
                        Line: Length {cadMath.dist(e.p1, e.p2).toFixed(2)} {units}, Angle {cadMath.angleDeg(e.p1, e.p2).toFixed(1)}°
                      </div>
                    );
                  }
                  return null;
                })}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex justify-end p-3 bg-zinc-950 border-t border-zinc-800 font-sans">
          <button
            onClick={() => setIsMeasureModalOpen(false)}
            className="px-4 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-white rounded transition text-xs font-semibold"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
