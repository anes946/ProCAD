/**
 * ProCAD - Main Application Entry
 * Assembles the full professional CAD software interface with Ribbon, 2D/3D Viewports,
 * Command Line, Properties Inspector, Status Bar, and Modals.
 */

import React, { useEffect } from 'react';
import { CADProvider, useCAD } from './context/CADContext';
import { Ribbon } from './components/Ribbon';
import { CADCanvas } from './components/CADCanvas';
import { CAD3DViewport } from './components/CAD3DViewport';
import { LayoutView } from './components/LayoutView';
import { PropertiesPanel } from './components/PropertiesPanel';
import { CommandLine } from './components/CommandLine';
import { StatusBar } from './components/StatusBar';
import { LayerManagerModal } from './components/LayerManagerModal';
import { BlocksModal } from './components/BlocksModal';
import { MeasureModal } from './components/MeasureModal';

const CADAppInner: React.FC = () => {
  const {
    viewMode,
    undo,
    redo,
    saveProjectToJSON,
    toggleOrtho,
    togglePolar,
    toggleGrid,
    toggleOsnap,
    deleteEntities,
    selectedIds,
  } = useCAD();

  // Keyboard shortcut listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept if focus is inside text input
      const targetTag = (e.target as HTMLElement)?.tagName?.toLowerCase();
      const isInput = targetTag === 'input' || targetTag === 'textarea';

      // Function keys
      if (e.key === 'F3') {
        e.preventDefault();
        toggleOsnap();
      } else if (e.key === 'F7') {
        e.preventDefault();
        toggleGrid();
      } else if (e.key === 'F8') {
        e.preventDefault();
        toggleOrtho();
      } else if (e.key === 'F10') {
        e.preventDefault();
        togglePolar();
      }

      // Ctrl shortcuts
      if ((e.ctrlKey || e.metaKey) && !isInput) {
        if (e.key.toLowerCase() === 'z') {
          e.preventDefault();
          if (e.shiftKey) redo();
          else undo();
        } else if (e.key.toLowerCase() === 'y') {
          e.preventDefault();
          redo();
        } else if (e.key.toLowerCase() === 's') {
          e.preventDefault();
          saveProjectToJSON();
        }
      }

      // Delete key
      if ((e.key === 'Delete' || e.key === 'Backspace') && !isInput) {
        if (selectedIds.length > 0) {
          e.preventDefault();
          deleteEntities(selectedIds);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    undo,
    redo,
    saveProjectToJSON,
    toggleOrtho,
    togglePolar,
    toggleGrid,
    toggleOsnap,
    deleteEntities,
    selectedIds,
  ]);

  return (
    <div className="flex flex-col w-screen h-screen overflow-hidden bg-zinc-950 font-sans text-zinc-100 antialiased">
      {/* Top Engineering Ribbon & Quick-Access Bar */}
      <Ribbon />

      {/* Main Workspace (2D Drafting / 3D Solid / Paper Space Layout) */}
      <div className="flex flex-1 overflow-hidden relative">
        <main className="flex-1 relative overflow-hidden">
          {viewMode === '2D' && <CADCanvas />}
          {viewMode === '3D' && <CAD3DViewport />}
          {viewMode === 'LAYOUT' && <LayoutView />}
        </main>

        {/* Right Collapsible Properties Inspector (visible in 2D mode) */}
        {viewMode === '2D' && <PropertiesPanel />}
      </div>

      {/* Bottom AutoCAD Command Line Console */}
      <CommandLine />

      {/* Very Bottom Status Bar with Coordinate readout & Mode toggles */}
      <StatusBar />

      {/* Modals & Dialogs */}
      <LayerManagerModal />
      <BlocksModal />
      <MeasureModal />
    </div>
  );
};

export default function App() {
  return (
    <CADProvider>
      <CADAppInner />
    </CADProvider>
  );
}
