# ProCAD — Professional CAD Software

**ProCAD** is a high-precision, desktop-grade Computer-Aided Design (CAD) application running in the browser. Inspired by Autodesk AutoCAD, it provides actual geometric drafting operations, an interactive command-line console, object snapping (OSNAP), layer management, dimensions, reusable blocks, DXF/SVG/JSON file compatibility, paper space printing, and a 3D solid modeling workspace powered by Three.js.

---

## 🛠 Features Overview

### 1. 2D Drafting & Geometric Construction
- **Drawing Tools**: Line (`LINE`), Polyline (`PLINE`), Circle (`CIRCLE`), Arc (`ARC`), Rectangle (`RECTANG`), Polygon (`POLYGON`), Ellipse (`ELLIPSE`), Spline (`SPLINE`), Point (`POINT`), Construction Line (`XLINE`), Ray (`RAY`), Text Annotation (`TEXT`), Hatch Patterns (`HATCH`), and Linear/Aligned Dimensions (`DIMLIN`, `DAL`).
- **Editing Tools**: Move (`MOVE`), Copy (`COPY`), Rotate (`ROTATE`), Mirror (`MIRROR`), Scale (`SCALE`), Fillet (`FILLET`), Chamfer (`CHAMFER`), Offset (`OFFSET`), Erase (`ERASE`), Explode (`EXPLODE`).
- **Snapping Engine (OSNAP)**: Endpoint (□), Midpoint (△), Center (○), Quadrant (◇), Intersection (✕), Perpendicular (∟), Nearest (⧖), and Grid Snap.
- **Precision Modes**:
  - **ORTHO (F8)**: Restricts movement to horizontal and vertical axes.
  - **POLAR (F10)**: Dynamic angular snapping at 15°, 30°, 45°, 90° intervals.
  - **Dynamic Input (F12)**: Live length and angle HUD displayed next to the crosshair cursor.
  - **Pickbox & Infinite Crosshairs**: AutoCAD-style crosshairs and pickbox.
  - **Window Selection**: Left-to-right (blue window, pure enclose) vs. Right-to-left (green crossing, touch or enclose).

### 2. AutoCAD-Inspired Command Line
- Direct typing of standard AutoCAD commands and aliases (`L`, `PL`, `C`, `REC`, `A`, `M`, `CO`, `RO`, `MI`, `SC`, `O`, `TR`, `EX`, `F`, `CHA`, `E`, `U`, `REDO`, `Z`, `P`, `LA`, `DI`, `AA`, `EXT`).
- **Coordinate Entry**:
  - Absolute: `100,50`
  - Relative Cartesian: `@50,20`
  - Relative Polar: `@100<45`
  - Direct distance entry along current angle
- History cycling with Up/Down arrow keys.
- Command auto-completion suggestion popup.
- Cancellation via `ESC`.

### 3. Layer Properties Manager
- Create, rename, and delete layers.
- Color assignment (ACI and hex values).
- Visibility toggle (On/Off).
- Lock/Unlock layer.
- Linetype assignment: `CONTINUOUS`, `DASHED`, `DOTTED`, `CENTER`.
- Lineweight assignment: `0.13mm` to `0.70mm`.
- Real-time entity counts per layer.

### 4. 3D Solid Modeling Workspace (Three.js)
- Primitives: Box, Cylinder, Sphere, Cone, Torus.
- **2D-to-3D Extrusion**: Select any 2D closed circle or rectangle and extrude it into a 3D solid with customizable extrusion height.
- Orbit, pan, and zoom camera controls.
- Interactive AutoCAD-style **ViewCube** (Top, Front, Right, Left, Isometric NE).
- Shading display modes: *Shaded with Edges*, *Shaded Realistic PBR*, *Wireframe*.
- Camera switching: *Perspective* vs *Orthographic*.

### 5. Layout Space & Engineering Plotting
- Paper space presentation for standard ISO A4, A3, and ANSI Letter sizes.
- Portrait and Landscape orientations.
- Standard ISO/ANSI Title Block (Project Title, Drawing Number, Drawn By, Date, Scale, Sheet No).
- Vector SVG preview scaled to sheet margins.
- One-click **Plot / Print to PDF**.

### 6. File Compatibility & Project Exchange
- **Export DXF**: Generates standard AutoCAD ASCII DXF (R12 / R2000 compatible) with HEADER, TABLES, LAYERS, and ENTITIES (`LINE`, `CIRCLE`, `ARC`, `POLYLINE`, `TEXT`).
- **Import DXF**: Reads standard DXF line pairs and reconstructs layers and entities.
- **Export SVG**: Scalable vector graphics export with styles and layer groups.
- **Import SVG**: Parses basic SVG geometric elements into CAD entities.
- **Native JSON Project**: Complete drawing state persistence with auto-save to `localStorage`.

---

## ⌨ Keyboard Shortcuts

| Shortcut | Action |
| :--- | :--- |
| **F3** | Toggle Object Snap (OSNAP) |
| **F7** | Toggle Drawing Grid |
| **F8** | Toggle Orthogonal Mode (ORTHO) |
| **F10** | Toggle Polar Tracking |
| **ESC** | Cancel current command / Clear selection |
| **Delete / Backspace** | Erase selected entities |
| **Ctrl + Z** | Undo last operation |
| **Ctrl + Y / Ctrl+Shift+Z** | Redo last operation |
| **Ctrl + S** | Save native project file |
| **Middle Mouse Drag** | Pan drawing viewport |
| **Mouse Wheel** | Zoom in / out centered at cursor position |

---

## 📁 Project Structure

```
├── index.html                   # HTML entry point with ProCAD metadata
├── metadata.json                # AI Studio application metadata
├── package.json                 # Dependencies and build scripts
├── src/
│   ├── App.tsx                  # Main application UI layout
│   ├── main.tsx                 # React entry point
│   ├── index.css                # Global Tailwind CSS imports
│   ├── context/
│   │   └── CADContext.tsx       # Global CAD state, undo/redo, command parser
│   ├── types/
│   │   └── cad.ts               # Type definitions for entities, layers, 3D solids
│   ├── geometry/
│   │   ├── cadMath.ts           # Vector math, intersections, fillets, chamfers, offsets
│   │   ├── snapping.ts          # Object snapping engine (endpoints, centers, etc.)
│   │   └── __tests__/
│   │       └── cadMath.test.ts  # Automated geometry kernel tests
│   ├── services/
│   │   ├── dxfService.ts        # DXF ASCII parser & writer, SVG & JSON export
│   │   ├── sampleDrawings.ts    # Pre-built architectural & mechanical drawings
│   │   └── blocks.ts            # Architectural, mechanical, & electrical symbols
│   └── components/
│       ├── Ribbon.tsx           # AutoCAD ribbon interface & quick access bar
│       ├── CADCanvas.tsx        # High-precision 2D Canvas drafting engine
│       ├── CAD3DViewport.tsx    # Three.js 3D solid modeling workspace
│       ├── CommandLine.tsx      # Command line console with auto-completion
│       ├── PropertiesPanel.tsx  # Live properties inspector & geometry editor
│       ├── StatusBar.tsx        # Bottom status bar with mode toggles & coordinates
│       ├── LayerManagerModal.tsx# Layer properties dialog
│       ├── BlocksModal.tsx      # Symbol & block insertion dialog
│       ├── MeasureModal.tsx     # Full geometric measurement calculator
│       └── LayoutView.tsx       # Printable paper space layout with title block
```

---

## 🚀 Development & Build

### Install Dependencies
```bash
npm install
```

### Run Development Server
```bash
npm run dev
```

### Build for Production
```bash
npm run build
```

---

## ⚙ Geometric Kernel Verification
ProCAD includes a built-in automated test suite verifying:
- Two-point vector distances & midpoints.
- Segment-segment geometric intersections and parallel conditions.
- Coordinate parsing (Absolute `X,Y`, Relative `@dX,dY`, Polar `@dist<angle`).
- Shoelace formula polygon area & perimeter calculation.
- Line offset generation.
- Perpendicular line fillet radius & tangent trimming.

Click **Run Geometry Kernel Tests** in the **Output** tab at any time to verify the engine.
